import subprocess
import threading
import time

def launch_ssh():
    print("[BOOT] → Tunnel SSH : Initialisation...")
    subprocess.Popen(["python3", "ssh_tunnel_launcher.py"])

def launch_sse():
    time.sleep(2)
    print("[BOOT] → Stream SSE : Initialisation...")
    subprocess.Popen(["python3", "gda_session_launcher.py"])

def launch_monitor():
    time.sleep(3)
    print("[BOOT] → Monitor Supabase : Initialisation...")
    subprocess.Popen(["python3", "supabase_callback_validator.py"])

if __name__ == "__main__":
    threading.Thread(target=launch_ssh).start()
    threading.Thread(target=launch_sse).start()
    threading.Thread(target=launch_monitor).start()