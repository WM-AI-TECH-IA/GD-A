#!/bin/bash

API_URL="http://localhost:5000/hooks"
TOKEN="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
TARGET_URL="https://webhook.site/35b23aa6-ec58-4b4f-bbfc-4cd1dc2ffde1"

read -r -d '' PAYLOAD << EOM
{
  "provider": "test-provider",
  "target_url": "$TARGET_URL",
  "events": ["test_event"],
  "ttl": 1800
}
EOM

curl -X POST "$API_URL" \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d "$PAYLOAD"