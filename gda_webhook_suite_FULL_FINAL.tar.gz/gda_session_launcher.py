import asyncio
import os
from GDAWebHookClient import GDAWebHookClient

if __name__ == "__main__":
    base_url = "http://localhost:5000"
    token = os.getenv("WM_TOKEN")
    tenant_id = os.getenv("WM_TENANT_ID")
    supabase_url = os.getenv("SUPABASE_URL")
    supabase_key = os.getenv("SUPABASE_ANON_KEY")

    client = GDAWebHookClient(
        base_url=base_url,
        token=token,
        supabase_url=supabase_url,
        supabase_key=supabase_key
    )

    print(f"[GDA-LAUNCH] Écoute du tenant_id : {tenant_id} ...")
    asyncio.run(client.listen_stream(tenant_id))