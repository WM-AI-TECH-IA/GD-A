# GD-AURORAPERO — Webhook + Supabase Monitoring Suite

## 🌐 Objectif
Suite modulaire de gestion d'événements pour GD-AURORAPERO via Webhook + Stream + Log Supabase.

## 📦 Fichiers inclus
- GDAWebHookClient.py
- gda_session_launcher.py
- ssh_tunnel_launcher.py
- curl_hook_test.sh
- supabase_callback_validator.py
- bootstrap_all.py
- install_bootstrap_service.sh
- README.md

## 🔧 Lancement rapide
1. Crée un tunnel :
```bash
python3 ssh_tunnel_launcher.py
```
2. Écoute SSE :
```bash
python3 gda_session_launcher.py
```
3. Tester un webhook :
```bash
./curl_hook_test.sh
```
4. Monitor en continu :
```bash
python3 supabase_callback_validator.py
```

## 🧠 Auteur
William Michaud — WM-AI-TECH