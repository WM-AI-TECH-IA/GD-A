import subprocess
import os

def launch_ssh_tunnel():
    ssh_user = "srv-d0caota4d50c73bv4ij0"
    ssh_host = "ssh.virginia.render.com"
    local_port = 5000
    remote_port = 5000

    tunnel_cmd = [
        "ssh",
        "-o", "StrictHostKeyChecking=no",
        "-L", f"{local_port}:localhost:{remote_port}",
        f"{ssh_user}@{ssh_host}"
    ]

    print(f"[TUNNEL] Initialisation du tunnel SSH sur le port {local_port}...")
    subprocess.run(tunnel_cmd)

if __name__ == "__main__":
    launch_ssh_tunnel()