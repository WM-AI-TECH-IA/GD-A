#!/bin/bash

SERVICE_NAME="gda-bootstrap.service"
SCRIPT_PATH="$(pwd)/bootstrap_all.py"
PYTHON_PATH="$(which python3)"

cat <<EOF | sudo tee /etc/systemd/system/$SERVICE_NAME
[Unit]
Description=GD-AURORAPERO Bootstrap Webhook & Supabase Monitor
After=network.target

[Service]
ExecStart=$PYTHON_PATH $SCRIPT_PATH
WorkingDirectory=$(pwd)
Restart=always
RestartSec=5
StandardOutput=journal
StandardError=journal
Environment=SUPABASE_URL=https://aphkwfkkpvtddwmfasii.supabase.co
Environment=SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...

[Install]
WantedBy=multi-user.target
EOF

sudo systemctl daemon-reexec
sudo systemctl daemon-reload
sudo systemctl enable $SERVICE_NAME
sudo systemctl start $SERVICE_NAME

echo "✔︎ Service $SERVICE_NAME installé et lancé automatiquement."