import requests
import aiohttp
import asyncio
import logging
import json
from typing import List, Optional
from datetime import datetime

class GDAWebHookClient:
    def __init__(self, base_url: str, token: str, supabase_url: Optional[str] = None, supabase_key: Optional[str] = None):
        self.base_url = base_url.rstrip("/")
        self.headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }
        self.supabase_url = supabase_url
        self.supabase_key = supabase_key

    def create_webhook(self, provider: str, target_url: str, events: List[str], ttl: Optional[int] = None):
        payload = {
            "provider": provider,
            "target_url": target_url,
            "events": events
        }
        if ttl:
            payload["ttl"] = ttl
        response = requests.post(f"{self.base_url}/hooks", json=payload, headers=self.headers)
        return response.json()

    def update_webhook(self, tenant_id: str, hook_id: str, ttl: Optional[int] = None, events: Optional[List[str]] = None):
        payload = {}
        if ttl:
            payload["ttl"] = ttl
        if events:
            payload["events"] = events
        response = requests.patch(f"{self.base_url}/hooks/{tenant_id}/{hook_id}", json=payload, headers=self.headers)
        return response.json()

    def delete_webhook(self, tenant_id: str, hook_id: str):
        response = requests.delete(f"{self.base_url}/hooks/{tenant_id}/{hook_id}", headers=self.headers)
        return response.status_code

    def get_webhook(self, tenant_id: str, hook_id: str):
        response = requests.get(f"{self.base_url}/hooks/{tenant_id}/{hook_id}", headers=self.headers)
        return response.json()

    async def listen_stream(self, tenant_id: str):
        url = f"{self.base_url}/stream/{tenant_id}"
        async with aiohttp.ClientSession(headers=self.headers) as session:
            async with session.get(url) as response:
                async for line in response.content:
                    if line:
                        decoded_line = line.decode('utf-8').strip()
                        if decoded_line.startswith("data:"):
                            data = decoded_line[5:].strip()
                            logging.info(f"[SSE] Callback Data: {data}")
                            self.log_to_supabase(hook_id="stream", payload=json.loads(data))

    def log_to_supabase(self, hook_id: str, payload: dict):
        if not self.supabase_url or not self.supabase_key:
            return
        headers = {
            "apikey": self.supabase_key,
            "Authorization": f"Bearer {self.supabase_key}",
            "Content-Type": "application/json"
        }
        log_entry = {
            "hook_id": hook_id,
            "received_at": datetime.utcnow().isoformat() + "Z",
            "payload": payload
        }
        try:
            response = requests.post(f"{self.supabase_url}/rest/v1/webhook_logs", headers=headers, data=json.dumps(log_entry))
            if response.status_code >= 400:
                logging.warning(f"Failed to log callback: {response.text}")
        except Exception as e:
            logging.error(f"Supabase logging error: {str(e)}")