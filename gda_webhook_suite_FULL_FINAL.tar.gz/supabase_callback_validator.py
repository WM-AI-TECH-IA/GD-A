import requests
import os
import time

SUPABASE_URL = os.getenv("SUPABASE_URL", "https://aphkwfkkpvtddwmfasii.supabase.co")
SUPABASE_KEY = os.getenv("SUPABASE_ANON_KEY", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...")
TABLE_NAME = "webhook_logs"
INTERVAL = 10  # secondes

headers = {
    "apikey": SUPABASE_KEY,
    "Authorization": f"Bearer {SUPABASE_KEY}"
}

def fetch_logs():
    query_url = f"{SUPABASE_URL}/rest/v1/{TABLE_NAME}?select=*&order=received_at.desc&limit=5"
    response = requests.get(query_url, headers=headers)
    if response.status_code == 200:
        print("\n✔︎ Derniers logs de callbacks enregistrés :\n")
        for entry in response.json():
            print(f"Hook: {entry['hook_id']} | Reçu à: {entry['received_at']}\nPayload: {entry['payload']}\n")
    else:
        print(f"✖︎ Échec de lecture : {response.status_code}\n{response.text}")

if __name__ == "__main__":
    print("[MONITORING] Démarrage de la surveillance des callbacks Supabase...")
    while True:
        fetch_logs()
        time.sleep(INTERVAL)