import React, { useState, useEffect } from 'react';
import { Archive, Folder, File, Code, GitBranch, GitCommit, RefreshCw, Search, Download, Upload, Trash, Plus, Check, AlertCircle, Lock } from 'lucide-react';
import { encryptData, decryptData } from '../utils/security';

type RepositoryProps = {
  securityLevel: 'standard' | 'high' | 'extreme';
};

interface Project {
  id: string;
  name: string;
  description: string;
  language: string;
  lastUpdated: Date;
  size: number;
  author: string;
  private: boolean;
  stars: number;
}

interface Branch {
  name: string;
  isDefault: boolean;
  lastCommit: string;
  lastCommitDate: Date;
  protected: boolean;
}

interface Commit {
  id: string;
  message: string;
  author: string;
  date: Date;
  branch: string;
}

interface File {
  name: string;
  type: 'file' | 'directory';
  size?: number;
  lastModified?: Date;
}

export const Repository: React.FC<RepositoryProps> = ({ securityLevel }) => {
  const [projects, setProjects] = useState<Project[]>([
    {
      id: 'project-1',
      name: 'WM-Terminal-Frontend',
      description: 'Interface utilisateur pour WM Terminal',
      language: 'TypeScript',
      lastUpdated: new Date(Date.now() - 3600000 * 24),
      size: 12800,
      author: 'WM Technologies',
      private: true,
      stars: 15
    },
    {
      id: 'project-2',
      name: 'WM-Terminal-API',
      description: 'Backend API pour WM Terminal',
      language: 'Python',
      lastUpdated: new Date(Date.now() - 3600000 * 24 * 3),
      size: 8400,
      author: 'WM Technologies',
      private: true,
      stars: 7
    },
    {
      id: 'project-3',
      name: 'WM-Terminal-CLI',
      description: 'Interface ligne de commande pour WM Terminal',
      language: 'Go',
      lastUpdated: new Date(Date.now() - 3600000 * 24 * 7),
      size: 4200,
      author: 'WM Technologies',
      private: true,
      stars: 12
    },
    {
      id: 'project-4',
      name: 'WM-Terminal-Docs',
      description: 'Documentation pour WM Terminal',
      language: 'Markdown',
      lastUpdated: new Date(Date.now() - 3600000 * 24 * 2),
      size: 3100,
      author: 'WM Technologies',
      private: false,
      stars: 5
    }
  ]);
  
  const [branches, setBranches] = useState<Branch[]>([
    {
      name: 'main',
      isDefault: true,
      lastCommit: 'feat: add authentication system',
      lastCommitDate: new Date(Date.now() - 3600000 * 3),
      protected: true
    },
    {
      name: 'develop',
      isDefault: false,
      lastCommit: 'fix: resolve API integration issues',
      lastCommitDate: new Date(Date.now() - 3600000),
      protected: false
    },
    {
      name: 'feature/new-terminal',
      isDefault: false,
      lastCommit: 'wip: implement new terminal UI',
      lastCommitDate: new Date(Date.now() - 3600000 * 12),
      protected: false
    }
  ]);
  
  const [commits, setCommits] = useState<Commit[]>([
    {
      id: 'c1',
      message: 'feat: add authentication system',
      author: 'dev@wmtech.com',
      date: new Date(Date.now() - 3600000 * 3),
      branch: 'main'
    },
    {
      id: 'c2',
      message: 'fix: resolve API integration issues',
      author: 'dev@wmtech.com',
      date: new Date(Date.now() - 3600000),
      branch: 'develop'
    },
    {
      id: 'c3',
      message: 'chore: update dependencies',
      author: 'dev@wmtech.com',
      date: new Date(Date.now() - 3600000 * 24),
      branch: 'main'
    },
    {
      id: 'c4',
      message: 'refactor: improve code organization',
      author: 'dev@wmtech.com',
      date: new Date(Date.now() - 3600000 * 24 * 2),
      branch: 'main'
    },
    {
      id: 'c5',
      message: 'wip: implement new terminal UI',
      author: 'dev@wmtech.com',
      date: new Date(Date.now() - 3600000 * 12),
      branch: 'feature/new-terminal'
    }
  ]);
  
  const [files, setFiles] = useState<File[]>([
    { name: 'src', type: 'directory' },
    { name: 'public', type: 'directory' },
    { name: 'package.json', type: 'file', size: 2500, lastModified: new Date(Date.now() - 3600000 * 24) },
    { name: 'README.md', type: 'file', size: 4200, lastModified: new Date(Date.now() - 3600000 * 24 * 7) },
    { name: 'tsconfig.json', type: 'file', size: 450, lastModified: new Date(Date.now() - 3600000 * 24 * 10) },
    { name: '.env.example', type: 'file', size: 120, lastModified: new Date(Date.now() - 3600000 * 24 * 12) }
  ]);
  
  const [activeProject, setActiveProject] = useState<Project | null>(null);
  const [activeBranch, setActiveBranch] = useState<string>('main');
  const [activeTab, setActiveTab] = useState<'code' | 'commits' | 'branches'>('code');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [fileContent, setFileContent] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  
  const handleProjectSelect = (project: Project) => {
    setIsLoading(true);
    
    // Simulate loading
    setTimeout(() => {
      setActiveProject(project);
      setActiveBranch('main');
      setActiveTab('code');
      setSelectedFile(null);
      setFileContent(null);
      setIsLoading(false);
    }, 500);
  };
  
  const handleFileSelect = (file: File) => {
    if (file.type === 'directory') {
      // In a real app, would load directory contents
      return;
    }
    
    setIsLoading(true);
    setSelectedFile(file.name);
    
    // Simulate loading file content
    setTimeout(() => {
      // Generate some dummy content based on the file name
      let content = '';
      
      if (file.name.endsWith('.json')) {
        content = `{
  "name": "wm-terminal",
  "version": "1.0.0",
  "private": true,
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "typescript": "^4.9.5"
  },
  "scripts": {
    "start": "react-scripts start",
    "build": "react-scripts build"
  }
}`;
      } else if (file.name.endsWith('.md')) {
        content = `# WM Terminal

A secure terminal interface for cloud operations.

## Features

- High security encryption
- Cloud integration
- API management
- Code repository

## Installation

\`\`\`bash
npm install
npm start
\`\`\``;
      } else if (file.name.endsWith('.ts') || file.name.endsWith('.tsx')) {
        content = `import React from 'react';

interface Props {
  securityLevel: 'standard' | 'high' | 'extreme';
}

export const Terminal: React.FC<Props> = ({ securityLevel }) => {
  return (
    <div className="terminal">
      <h2>WM Terminal - {securityLevel}</h2>
      <div className="terminal-content">
        // Terminal content here
      </div>
    </div>
  );
};`;
      } else {
        content = `# Configuration file
SECURITY_LEVEL=high
API_ENDPOINT=https://api.wmterminal.com
MAX_CONNECTIONS=100
ENABLE_LOGGING=true`;
      }
      
      // In a real app, would fetch actual content from repository
      setFileContent(content);
      setIsLoading(false);
    }, 800);
  };
  
  const handleBranchChange = (branch: string) => {
    setActiveBranch(branch);
    setSelectedFile(null);
    setFileContent(null);
  };
  
  const formatFileSize = (bytes: number): string => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };
  
  const formatDate = (date: Date): string => {
    // If today, show time only
    const today = new Date();
    if (date.toDateString() === today.toDateString()) {
      return `aujourd'hui à ${date.toLocaleTimeString()}`;
    }
    
    // If yesterday, show "yesterday"
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    if (date.toDateString() === yesterday.toDateString()) {
      return `hier à ${date.toLocaleTimeString()}`;
    }
    
    // Otherwise show full date
    return date.toLocaleString();
  };
  
  const getLanguageColor = (language: string): string => {
    const colors: {[key: string]: string} = {
      'TypeScript': 'bg-blue-900 text-blue-300',
      'JavaScript': 'bg-yellow-900 text-yellow-300',
      'Python': 'bg-green-900 text-green-300',
      'Go': 'bg-purple-900 text-purple-300',
      'Markdown': 'bg-gray-700 text-gray-300'
    };
    
    return colors[language] || 'bg-gray-700 text-gray-300';
  };
  
  const filteredProjects = projects.filter(project => 
    project.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    project.description.toLowerCase().includes(searchQuery.toLowerCase())
  );
  
  return (
    <div className="flex-1 overflow-hidden flex bg-gray-900">
      <div className="w-64 bg-gray-800 border-r border-violet-900 overflow-y-auto">
        <div className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-violet-100 flex items-center">
              <Archive size={20} className="mr-2 text-violet-400" />
              Dépôt de Projets
            </h2>
            <button className="p-1 text-gray-400 hover:text-violet-400">
              <RefreshCw size={16} />
            </button>
          </div>
          
          <div className="relative mb-4">
            <input
              type="text"
              placeholder="Rechercher des projets..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 pl-9 pr-3 text-white focus:border-violet-500 focus:ring focus:ring-violet-500 focus:ring-opacity-50"
            />
            <Search size={16} className="absolute left-3 top-3 text-gray-400" />
          </div>
          
          <div className="space-y-2">
            {filteredProjects.map(project => (
              <button
                key={project.id}
                onClick={() => handleProjectSelect(project)}
                className={`w-full text-left p-3 rounded-md ${
                  activeProject?.id === project.id
                    ? 'bg-violet-900/50 text-white' 
                    : 'text-gray-300 hover:bg-violet-900/30 hover:text-white'
                }`}
              >
                <div className="flex items-center mb-1">
                  <Code size={16} className="mr-2 text-violet-400" />
                  <span className="font-medium">{project.name}</span>
                </div>
                <p className="text-xs text-gray-400 truncate">{project.description}</p>
                <div className="flex items-center mt-2 text-xs">
                  <span className={`px-2 py-0.5 rounded-full ${getLanguageColor(project.language)}`}>
                    {project.language}
                  </span>
                  {project.private && (
                    <span className="ml-2 flex items-center text-gray-400">
                      <Lock size={12} className="mr-1" />
                      Privé
                    </span>
                  )}
                </div>
              </button>
            ))}
          </div>
          
          <div className="mt-4 pt-4 border-t border-gray-700">
            <button className="w-full flex items-center justify-center p-2 bg-violet-600 hover:bg-violet-700 text-white rounded-md">
              <Plus size={16} className="mr-2" />
              Nouveau Projet
            </button>
          </div>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto">
        {isLoading ? (
          <div className="flex items-center justify-center h-full">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-violet-500"></div>
          </div>
        ) : !activeProject ? (
          <div className="flex flex-col items-center justify-center h-full text-center p-4">
            <Archive size={64} className="text-violet-500/50 mb-4" />
            <h3 className="text-xl font-semibold mb-2 text-violet-100">Dépôt de Projets</h3>
            <p className="text-gray-400 mb-4 max-w-md">
              Stockez, gérez et collaborez sur votre code source dans un environnement sécurisé.
            </p>
            <p className="text-gray-400 max-w-md">
              Sélectionnez un projet dans la liste à gauche pour commencer.
            </p>
          </div>
        ) : (
          <div className="flex flex-col h-full">
            <div className="bg-gray-800 p-4 border-b border-violet-900">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h2 className="text-xl font-semibold text-violet-100">{activeProject.name}</h2>
                  <p className="text-gray-400">{activeProject.description}</p>
                </div>
                
                <div className="flex items-center space-x-2">
                  <span className="text-gray-400 text-sm flex items-center">
                    <GitBranch size={16} className="mr-1" />
                    {branches.length} branches
                  </span>
                  <span className="text-gray-400 text-sm flex items-center">
                    <GitCommit size={16} className="mr-1" />
                    {commits.length} commits
                  </span>
                </div>
              </div>
              
              <div className="flex items-center space-x-4">
                <div className="relative flex-grow">
                  <select
                    value={activeBranch}
                    onChange={(e) => handleBranchChange(e.target.value)}
                    className="w-full appearance-none bg-gray-700 border border-gray-600 rounded-md py-2 pl-10 pr-8 text-white focus:border-violet-500 focus:ring focus:ring-violet-500 focus:ring-opacity-50"
                  >
                    {branches.map(branch => (
                      <option key={branch.name} value={branch.name}>
                        {branch.name}{branch.isDefault ? ' (default)' : ''}
                      </option>
                    ))}
                  </select>
                  <GitBranch size={16} className="absolute left-3 top-3 text-gray-400" />
                </div>
                
                <button className="p-2 bg-gray-700 rounded-md text-gray-300 hover:bg-gray-600 hover:text-white">
                  <Download size={18} />
                </button>
                
                <button className="p-2 bg-violet-600 rounded-md text-white hover:bg-violet-700">
                  <Plus size={18} />
                </button>
              </div>
            </div>
            
            <div className="flex border-b border-gray-700">
              <button
                onClick={() => setActiveTab('code')}
                className={`px-4 py-2 font-medium ${
                  activeTab === 'code' 
                    ? 'text-violet-400 border-b-2 border-violet-400' 
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                Code
              </button>
              <button
                onClick={() => setActiveTab('commits')}
                className={`px-4 py-2 font-medium ${
                  activeTab === 'commits' 
                    ? 'text-violet-400 border-b-2 border-violet-400' 
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                Commits
              </button>
              <button
                onClick={() => setActiveTab('branches')}
                className={`px-4 py-2 font-medium ${
                  activeTab === 'branches' 
                    ? 'text-violet-400 border-b-2 border-violet-400' 
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                Branches
              </button>
            </div>
            
            {activeTab === 'code' && (
              <div className="flex-1 overflow-hidden flex">
                <div className="w-1/3 border-r border-gray-700 overflow-y-auto">
                  {files.map(file => (
                    <button
                      key={file.name}
                      onClick={() => handleFileSelect(file)}
                      className={`w-full flex items-center justify-between p-3 text-left border-b border-gray-700 hover:bg-gray-800 ${
                        selectedFile === file.name ? 'bg-gray-800' : ''
                      }`}
                    >
                      <div className="flex items-center">
                        {file.type === 'directory' ? (
                          <Folder size={16} className="mr-2 text-yellow-400" />
                        ) : (
                          <File size={16} className="mr-2 text-gray-400" />
                        )}
                        <span className="text-white">{file.name}</span>
                      </div>
                      {file.type === 'file' && file.size && (
                        <span className="text-xs text-gray-400">{formatFileSize(file.size)}</span>
                      )}
                    </button>
                  ))}
                </div>
                
                <div className="flex-1 overflow-y-auto p-4">
                  {fileContent ? (
                    <div className="bg-gray-800 rounded-md overflow-hidden">
                      <div className="bg-gray-700 p-2 border-b border-gray-600 flex items-center justify-between">
                        <span className="font-mono text-sm text-white">{selectedFile}</span>
                        <div className="flex items-center space-x-2">
                          <button className="p-1 text-gray-400 hover:text-violet-400">
                            <Download size={14} />
                          </button>
                          <button className="p-1 text-gray-400 hover:text-violet-400">
                            <Copy size={14} />
                          </button>
                        </div>
                      </div>
                      <pre className="p-4 text-white font-mono text-sm overflow-x-auto">
                        {fileContent}
                      </pre>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center h-full text-center p-4">
                      <File size={48} className="text-gray-600 mb-4" />
                      <p className="text-gray-400">
                        Sélectionnez un fichier pour voir son contenu
                      </p>
                    </div>
                  )}
                </div>
              </div>
            )}
            
            {activeTab === 'commits' && (
              <div className="flex-1 overflow-y-auto p-4">
                <div className="bg-gray-800 rounded-lg overflow-hidden border border-violet-900/50">
                  <div className="p-4 border-b border-gray-700">
                    <h3 className="text-lg font-semibold text-violet-100">Commits</h3>
                    <p className="text-sm text-gray-400">Historique des commits pour la branche {activeBranch}</p>
                  </div>
                  
                  <div className="divide-y divide-gray-700">
                    {commits
                      .filter(commit => commit.branch === activeBranch)
                      .map(commit => (
                        <div key={commit.id} className="p-4 hover:bg-gray-700">
                          <div className="flex items-start">
                            <GitCommit size={18} className="mt-1 mr-3 text-violet-400" />
                            <div className="flex-1">
                              <div className="text-white font-medium mb-1">{commit.message}</div>
                              <div className="flex items-center justify-between">
                                <div className="text-sm text-gray-400">
                                  {commit.author} a committée {formatDate(commit.date)}
                                </div>
                                <div className="text-xs text-gray-500 font-mono">
                                  {commit.id.substring(0, 7)}
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
            
            {activeTab === 'branches' && (
              <div className="flex-1 overflow-y-auto p-4">
                <div className="bg-gray-800 rounded-lg overflow-hidden border border-violet-900/50">
                  <div className="p-4 border-b border-gray-700">
                    <h3 className="text-lg font-semibold text-violet-100">Branches</h3>
                    <p className="text-sm text-gray-400">Gérez les branches du projet</p>
                  </div>
                  
                  <div className="divide-y divide-gray-700">
                    {branches.map(branch => (
                      <div key={branch.name} className="p-4 hover:bg-gray-700">
                        <div className="flex items-start">
                          <GitBranch size={18} className="mt-1 mr-3 text-violet-400" />
                          <div className="flex-1">
                            <div className="flex items-center mb-1">
                              <span className="text-white font-medium mr-2">{branch.name}</span>
                              {branch.isDefault && (
                                <span className="px-2 py-0.5 bg-violet-900/50 text-violet-300 rounded-full text-xs">
                                  Par défaut
                                </span>
                              )}
                              {branch.protected && (
                                <span className="ml-2 px-2 py-0.5 bg-red-900/50 text-red-300 rounded-full text-xs flex items-center">
                                  <Lock size={10} className="mr-1" />
                                  Protégée
                                </span>
                              )}
                            </div>
                            <div className="text-sm text-gray-400 mb-2">
                              Dernier commit: {branch.lastCommit}
                            </div>
                            <div className="text-xs text-gray-500">
                              Mise à jour {formatDate(branch.lastCommitDate)}
                            </div>
                          </div>
                          {!branch.isDefault && (
                            <button className="p-1 text-red-500 hover:text-red-400">
                              <Trash size={16} />
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};