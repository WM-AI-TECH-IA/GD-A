import React, { useState, useEffect } from 'react';
import { Database, Save, Download, Clock, CheckCircle, AlertTriangle, Trash, RefreshCw, ArrowDownToLine, FileText } from 'lucide-react';
import { supabase } from '../utils/supabaseClient';
import { encryptData, decryptData } from '../utils/security';
import { addLogEntry, LogLevel } from '../utils/logger';

type BackupManagerProps = {
  securityLevel: 'standard' | 'high' | 'extreme';
};

type Backup = {
  id: string;
  created_at: string;
  name: string;
  size: number;
  tables: string[];
  status: 'complete' | 'in_progress' | 'error';
  notes?: string;
};

export const BackupManager: React.FC<BackupManagerProps> = ({ securityLevel }) => {
  const [backups, setBackups] = useState<Backup[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [currentOperation, setCurrentOperation] = useState<string | null>(null);
  const [progress, setProgress] = useState<number>(0);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [selectedBackup, setSelectedBackup] = useState<string | null>(null);
  const [autoBackupEnabled, setAutoBackupEnabled] = useState<boolean>(true);
  const [autoBackupInterval, setAutoBackupInterval] = useState<string>('daily');
  const [backupNote, setBackupNote] = useState<string>('');

  useEffect(() => {
    loadBackups();

    // Set up auto-refresh of backups list
    const interval = setInterval(() => {
      if (!currentOperation) {
        loadBackups(false);
      }
    }, 60000); // Refresh every minute

    return () => clearInterval(interval);
  }, []);

  const loadBackups = async (showLoading = true) => {
    if (showLoading) setLoading(true);
    setError(null);

    try {
      // In a real application, this would fetch from the database
      // Simulating API call for demo purposes
      await new Promise(resolve => setTimeout(resolve, 800));

      // Sample backup data
      const sampleBackups: Backup[] = [
        {
          id: 'bak_1',
          created_at: new Date(Date.now() - 86400000).toISOString(), // Yesterday
          name: 'Sauvegarde Quotidienne',
          size: 15600000, // ~15 MB
          tables: ['api_gateway_settings', 'api_keys', 'api_routes', 'user_profiles'],
          status: 'complete'
        },
        {
          id: 'bak_2',
          created_at: new Date(Date.now() - 86400000 * 7).toISOString(), // 7 days ago
          name: 'Sauvegarde Hebdomadaire',
          size: 14800000,
          tables: ['api_gateway_settings', 'api_keys', 'api_routes', 'user_profiles'],
          status: 'complete'
        },
        {
          id: 'bak_3',
          created_at: new Date(Date.now() - 86400000 * 30).toISOString(), // 30 days ago
          name: 'Sauvegarde Mensuelle',
          size: 13200000,
          tables: ['api_gateway_settings', 'api_keys', 'api_routes'],
          status: 'complete'
        }
      ];

      setBackups(sampleBackups);
      addLogEntry(LogLevel.INFO, 'Backups loaded successfully', { count: sampleBackups.length });
    } catch (error) {
      console.error("Error loading backups:", error);
      setError("Impossible de charger les sauvegardes. Veuillez réessayer plus tard.");
      addLogEntry(LogLevel.ERROR, 'Failed to load backups', { error: String(error) });
    } finally {
      if (showLoading) setLoading(false);
    }
  };

  const createBackup = async () => {
    setCurrentOperation('backup');
    setProgress(0);
    setError(null);
    setSuccess(null);

    try {
      // Log the start of the backup
      addLogEntry(LogLevel.INFO, 'Starting database backup');

      // Simulate backup progress
      let currentProgress = 0;
      const interval = setInterval(() => {
        currentProgress += 5;
        if (currentProgress > 95) {
          clearInterval(interval);
        }
        setProgress(currentProgress);
      }, 300);

      // In a real application, this would create a backup via Supabase API
      // For demo purposes, we're simulating the process
      await new Promise(resolve => setTimeout(resolve, 6000));
      clearInterval(interval);
      setProgress(100);

      // Create a new backup object to add to our state
      const newBackup: Backup = {
        id: 'bak_' + Date.now(),
        created_at: new Date().toISOString(),
        name: backupNote || 'Sauvegarde Manuelle',
        size: Math.floor(Math.random() * 5000000) + 12000000, // Random size between 12-17MB
        tables: ['api_gateway_settings', 'api_keys', 'api_routes', 'user_profiles'],
        status: 'complete',
        notes: backupNote
      };

      // Update the state with the new backup
      setBackups(prev => [newBackup, ...prev]);
      setSuccess("Sauvegarde créée avec succès!");
      setBackupNote('');
      
      // Log successful backup
      addLogEntry(LogLevel.SUCCESS, 'Database backup completed successfully', {
        backupId: newBackup.id,
        size: newBackup.size
      });
    } catch (error) {
      console.error("Error creating backup:", error);
      setError("Impossible de créer la sauvegarde. Veuillez réessayer plus tard.");
      addLogEntry(LogLevel.ERROR, 'Failed to create backup', { error: String(error) });
    } finally {
      setTimeout(() => {
        setCurrentOperation(null);
        setProgress(0);
      }, 1000);
    }
  };

  const restoreBackup = async (backupId: string) => {
    if (!window.confirm("Êtes-vous sûr de vouloir restaurer cette sauvegarde? Cette opération remplacera toutes les données actuelles.")) {
      return;
    }

    setCurrentOperation('restore');
    setProgress(0);
    setError(null);
    setSuccess(null);

    try {
      // Get the backup to restore
      const backupToRestore = backups.find(b => b.id === backupId);
      if (!backupToRestore) {
        throw new Error("Sauvegarde introuvable");
      }

      // Log the start of the restore
      addLogEntry(LogLevel.WARNING, 'Starting database restore', { 
        backupId, 
        backupDate: backupToRestore.created_at 
      });

      // Simulate restore progress
      let currentProgress = 0;
      const interval = setInterval(() => {
        currentProgress += 4;
        if (currentProgress > 95) {
          clearInterval(interval);
        }
        setProgress(currentProgress);
      }, 250);

      // In a real application, this would restore from a backup via Supabase API
      // For demo purposes, we're simulating the process
      await new Promise(resolve => setTimeout(resolve, 7000));
      clearInterval(interval);
      setProgress(100);

      setSuccess(`Restauration de la sauvegarde du ${new Date(backupToRestore.created_at).toLocaleString()} terminée avec succès!`);
      addLogEntry(LogLevel.SUCCESS, 'Database restore completed successfully', { backupId });
    } catch (error) {
      console.error("Error restoring backup:", error);
      setError("Impossible de restaurer la sauvegarde. Veuillez réessayer plus tard.");
      addLogEntry(LogLevel.ERROR, 'Failed to restore backup', { 
        backupId,
        error: String(error) 
      });
    } finally {
      setTimeout(() => {
        setCurrentOperation(null);
        setProgress(0);
      }, 1000);
    }
  };

  const deleteBackup = async (backupId: string) => {
    if (!window.confirm("Êtes-vous sûr de vouloir supprimer cette sauvegarde? Cette action est irréversible.")) {
      return;
    }

    setLoading(true);
    setError(null);

    try {
      // In a real application, this would delete the backup via Supabase API
      // For demo purposes, we're simulating the process
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Update the state
      setBackups(prev => prev.filter(b => b.id !== backupId));
      addLogEntry(LogLevel.INFO, 'Backup deleted', { backupId });
    } catch (error) {
      console.error("Error deleting backup:", error);
      setError("Impossible de supprimer la sauvegarde. Veuillez réessayer plus tard.");
      addLogEntry(LogLevel.ERROR, 'Failed to delete backup', { 
        backupId,
        error: String(error) 
      });
    } finally {
      setLoading(false);
    }
  };

  const downloadBackup = async (backupId: string) => {
    setCurrentOperation('download');
    setProgress(0);
    setError(null);

    try {
      // Get the backup to download
      const backupToDownload = backups.find(b => b.id === backupId);
      if (!backupToDownload) {
        throw new Error("Sauvegarde introuvable");
      }

      // Log the start of the download
      addLogEntry(LogLevel.INFO, 'Starting backup download', { backupId });

      // Simulate download progress
      let currentProgress = 0;
      const interval = setInterval(() => {
        currentProgress += 5;
        if (currentProgress > 95) {
          clearInterval(interval);
        }
        setProgress(currentProgress);
      }, 150);

      // In a real application, this would download the backup file
      // For demo purposes, we're simulating the process
      await new Promise(resolve => setTimeout(resolve, 3000));
      clearInterval(interval);
      setProgress(100);

      // In a real application, this would trigger a file download
      // For demo purposes, we'll just show a success message
      setSuccess("Sauvegarde téléchargée avec succès!");
      addLogEntry(LogLevel.SUCCESS, 'Backup downloaded successfully', { backupId });
    } catch (error) {
      console.error("Error downloading backup:", error);
      setError("Impossible de télécharger la sauvegarde. Veuillez réessayer plus tard.");
      addLogEntry(LogLevel.ERROR, 'Failed to download backup', { 
        backupId,
        error: String(error) 
      });
    } finally {
      setTimeout(() => {
        setCurrentOperation(null);
        setProgress(0);
      }, 1000);
    }
  };

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleString();
  };

  return (
    <div className="flex-1 overflow-hidden flex flex-col bg-gray-900">
      <div className="bg-gray-800 p-4 border-b border-violet-900">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <Database size={24} className="mr-2 text-violet-400" />
            <h2 className="text-xl font-semibold text-violet-100">Gestionnaire de Sauvegardes</h2>
          </div>

          <div className="flex items-center space-x-2">
            <button
              onClick={loadBackups}
              disabled={loading || !!currentOperation}
              className="p-2 bg-gray-700 rounded-md text-gray-300 hover:bg-gray-600 hover:text-white disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <RefreshCw size={18} className={loading ? "animate-spin" : ""} />
            </button>

            <button
              onClick={createBackup}
              disabled={!!currentOperation}
              className="px-3 py-1 bg-violet-600 hover:bg-violet-700 text-white rounded-md text-sm flex items-center disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Save size={14} className="mr-1" />
              Créer une sauvegarde
            </button>
          </div>
        </div>

        {(error || success) && (
          <div className={`p-3 rounded-md flex items-center mb-4 ${
            error 
              ? 'bg-red-900/30 text-red-400 border border-red-800' 
              : 'bg-green-900/30 text-green-400 border border-green-800'
          }`}>
            {error ? (
              <AlertTriangle size={16} className="mr-2" />
            ) : (
              <CheckCircle size={16} className="mr-2" />
            )}
            <span>{error || success}</span>
          </div>
        )}

        {currentOperation && (
          <div className="mb-4">
            <div className="flex justify-between text-sm text-gray-400 mb-1">
              <span>
                {currentOperation === 'backup' && 'Création de la sauvegarde en cours...'}
                {currentOperation === 'restore' && 'Restauration de la sauvegarde en cours...'}
                {currentOperation === 'download' && 'Téléchargement de la sauvegarde en cours...'}
              </span>
              <span>{progress}%</span>
            </div>
            <div className="w-full bg-gray-700 rounded-full h-1.5">
              <div 
                className="bg-violet-600 h-1.5 rounded-full transition-all duration-300" 
                style={{ width: `${progress}%` }}
              ></div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-gray-700 rounded-lg p-3">
            <div className="text-sm text-gray-400 mb-1">Sauvegardes totales</div>
            <div className="text-lg font-semibold">{backups.length}</div>
          </div>

          <div className="bg-gray-700 rounded-lg p-3">
            <div className="text-sm text-gray-400 mb-1">Dernière sauvegarde</div>
            <div className="text-lg font-semibold">
              {backups.length > 0 
                ? formatDate(backups[0].created_at)
                : 'Aucune sauvegarde'}
            </div>
          </div>

          <div className="bg-gray-700 rounded-lg p-3">
            <div className="text-sm text-gray-400 mb-1">Taille totale</div>
            <div className="text-lg font-semibold">
              {formatBytes(backups.reduce((total, backup) => total + backup.size, 0))}
            </div>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        <div className="bg-gray-800 rounded-lg overflow-hidden border border-violet-900/50">
          <div className="p-4 border-b border-gray-700 flex items-center justify-between">
            <h3 className="text-lg font-semibold text-violet-100 flex items-center">
              <Save size={18} className="mr-2 text-violet-400" />
              Sauvegardes
            </h3>

            <div className="flex items-center">
              <div className="flex items-center mr-4">
                <input 
                  id="auto-backup"
                  type="checkbox"
                  checked={autoBackupEnabled}
                  onChange={() => setAutoBackupEnabled(!autoBackupEnabled)}
                  className="w-4 h-4 accent-violet-600 rounded border-gray-300 focus:ring-violet-500"
                />
                <label htmlFor="auto-backup" className="ml-2 text-sm text-gray-300">
                  Sauvegarde auto
                </label>
              </div>

              <select
                value={autoBackupInterval}
                onChange={(e) => setAutoBackupInterval(e.target.value)}
                disabled={!autoBackupEnabled}
                className="bg-gray-700 border border-gray-600 rounded text-white text-sm py-1 px-2 disabled:opacity-50"
              >
                <option value="hourly">Toutes les heures</option>
                <option value="daily">Quotidienne</option>
                <option value="weekly">Hebdomadaire</option>
              </select>
            </div>
          </div>

          {loading ? (
            <div className="flex items-center justify-center p-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-violet-500"></div>
            </div>
          ) : backups.length === 0 ? (
            <div className="p-8 text-center">
              <Database size={48} className="mx-auto mb-4 text-gray-600" />
              <p className="text-gray-400">Aucune sauvegarde disponible</p>
              <p className="text-sm text-gray-500 mt-2">Créez votre première sauvegarde pour protéger vos données</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-gray-700">
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Nom</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Date</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Taille</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Tables</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Statut</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-700">
                  {backups.map((backup) => (
                    <tr 
                      key={backup.id} 
                      className={`bg-gray-800 hover:bg-gray-700 ${selectedBackup === backup.id ? 'bg-violet-900/20' : ''}`}
                      onClick={() => setSelectedBackup(selectedBackup === backup.id ? null : backup.id)}
                    >
                      <td className="px-4 py-3">
                        <div className="font-medium text-white">{backup.name}</div>
                        {backup.notes && (
                          <div className="text-xs text-gray-400 mt-1">{backup.notes}</div>
                        )}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-300">
                        {formatDate(backup.created_at)}
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-300">
                        {formatBytes(backup.size)}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex flex-wrap gap-1">
                          {backup.tables.map((table) => (
                            <span 
                              key={table} 
                              className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-violet-900/30 text-violet-300"
                            >
                              {table}
                            </span>
                          ))}
                        </div>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                          backup.status === 'complete' 
                            ? 'bg-green-900/50 text-green-300' 
                            : backup.status === 'in_progress'
                            ? 'bg-blue-900/50 text-blue-300'
                            : 'bg-red-900/50 text-red-300'
                        }`}>
                          {backup.status === 'complete' ? (
                            <CheckCircle size={12} className="mr-1" />
                          ) : backup.status === 'in_progress' ? (
                            <Clock size={12} className="mr-1" />
                          ) : (
                            <AlertTriangle size={12} className="mr-1" />
                          )}
                          {backup.status === 'complete' ? 'Complète' : 
                           backup.status === 'in_progress' ? 'En cours' : 
                           'Erreur'}
                        </span>
                      </td>
                      <td className="px-4 py-3 whitespace-nowrap text-sm">
                        <div className="flex space-x-2">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              downloadBackup(backup.id);
                            }}
                            className="text-violet-400 hover:text-violet-300"
                            disabled={!!currentOperation}
                          >
                            <Download size={16} />
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              restoreBackup(backup.id);
                            }}
                            className="text-blue-400 hover:text-blue-300"
                            disabled={!!currentOperation}
                          >
                            <ArrowDownToLine size={16} />
                          </button>
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              deleteBackup(backup.id);
                            }}
                            className="text-red-400 hover:text-red-300"
                            disabled={!!currentOperation}
                          >
                            <Trash size={16} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        <div className="bg-gray-800 rounded-lg p-4 border border-violet-900/50">
          <h3 className="text-lg font-semibold mb-4 text-violet-100 flex items-center">
            <Save size={18} className="mr-2 text-violet-400" />
            Nouvelle sauvegarde manuelle
          </h3>

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Note (optionnel)
              </label>
              <input
                type="text"
                value={backupNote}
                onChange={(e) => setBackupNote(e.target.value)}
                placeholder="ex: Avant mise à jour majeure..."
                className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:border-violet-500 focus:ring focus:ring-violet-500 focus:ring-opacity-50"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Sélection des tables
              </label>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="table-settings"
                    defaultChecked
                    className="accent-violet-600 w-4 h-4 rounded border-gray-600"
                  />
                  <label htmlFor="table-settings" className="ml-2 text-sm text-gray-300">
                    api_gateway_settings
                  </label>
                </div>
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="table-keys"
                    defaultChecked
                    className="accent-violet-600 w-4 h-4 rounded border-gray-600"
                  />
                  <label htmlFor="table-keys" className="ml-2 text-sm text-gray-300">
                    api_keys
                  </label>
                </div>
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="table-routes"
                    defaultChecked
                    className="accent-violet-600 w-4 h-4 rounded border-gray-600"
                  />
                  <label htmlFor="table-routes" className="ml-2 text-sm text-gray-300">
                    api_routes
                  </label>
                </div>
                <div className="flex items-center">
                  <input
                    type="checkbox"
                    id="table-profiles"
                    defaultChecked
                    className="accent-violet-600 w-4 h-4 rounded border-gray-600"
                  />
                  <label htmlFor="table-profiles" className="ml-2 text-sm text-gray-300">
                    user_profiles
                  </label>
                </div>
              </div>
            </div>

            <div className="flex justify-between items-center">
              <div className="flex items-center">
                <input
                  type="checkbox"
                  id="encrypt-backup"
                  defaultChecked={securityLevel !== 'standard'}
                  className="accent-violet-600 w-4 h-4 rounded border-gray-600"
                />
                <label htmlFor="encrypt-backup" className="ml-2 text-sm text-gray-300">
                  Chiffrer la sauvegarde ({securityLevel === 'extreme' ? 'AES-512' : 'AES-256'})
                </label>
              </div>

              <button
                onClick={createBackup}
                disabled={!!currentOperation}
                className="px-3 py-2 bg-violet-600 hover:bg-violet-700 text-white rounded-md flex items-center disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Save size={16} className="mr-2" />
                Créer une sauvegarde maintenant
              </button>
            </div>
          </div>
        </div>

        <div className="bg-gray-800 rounded-lg p-4 border border-violet-900/50">
          <h3 className="text-lg font-semibold mb-4 text-violet-100 flex items-center">
            <FileText size={18} className="mr-2 text-violet-400" />
            Politique de rétention
          </h3>

          <div className="space-y-4">
            <p className="text-gray-300">
              Configurez combien de temps les sauvegardes sont conservées avant d'être automatiquement supprimées.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-300">
                  Sauvegardes quotidiennes
                </label>
                <select className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:border-violet-500 focus:ring focus:ring-violet-500 focus:ring-opacity-50">
                  <option value="7">7 jours</option>
                  <option value="14">14 jours</option>
                  <option value="30">30 jours</option>
                  <option value="90">90 jours</option>
                </select>
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-300">
                  Sauvegardes hebdomadaires
                </label>
                <select className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:border-violet-500 focus:ring focus:ring-violet-500 focus:ring-opacity-50">
                  <option value="4">4 semaines</option>
                  <option value="8">8 semaines</option>
                  <option value="12">12 semaines</option>
                </select>
              </div>

              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-300">
                  Sauvegardes mensuelles
                </label>
                <select className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:border-violet-500 focus:ring focus:ring-violet-500 focus:ring-opacity-50">
                  <option value="3">3 mois</option>
                  <option value="6">6 mois</option>
                  <option value="12">12 mois</option>
                </select>
              </div>
            </div>

            <div className="flex justify-end">
              <button className="px-3 py-1 bg-violet-600 hover:bg-violet-700 text-white rounded-md text-sm">
                Enregistrer les paramètres
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};