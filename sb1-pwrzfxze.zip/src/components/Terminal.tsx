import React, { useState, useRef, useEffect } from 'react';
import { 
  Download, 
  ShieldCheck, 
  Keyboard, 
  X, 
  Sparkles, 
  ArrowUp, 
  ArrowDown, 
  ArrowLeft, 
  ArrowRight, 
  Delete, 
  Terminal as TerminalIcon,
  Copy,
  Cloud
} from 'lucide-react';
import { checkForUpdates, downloadUpdate, installUpdate, verifyUpdate, rollbackUpdate, getUpdateLog } from '../services/updateService';
import { addLogEntry, LogLevel } from '../utils/logger';

type TerminalProps = {
  isMobile: boolean;
  securityLevel: 'standard' | 'high' | 'extreme';
};

type TerminalEntry = {
  type: 'input' | 'output' | 'error' | 'success';
  content: string;
  timestamp: Date;
};

export const Terminal: React.FC<TerminalProps> = ({ isMobile, securityLevel }) => {
  const [input, setInput] = useState<string>('');
  const [cursorPosition, setCursorPosition] = useState<number>(0);
  const [history, setHistory] = useState<TerminalEntry[]>([
    { 
      type: 'output', 
      content: `WM Terminal Cloud v1.0.0 (${securityLevel === 'extreme' ? 'Sécurité Extrême' : securityLevel === 'high' ? 'Haute Sécurité' : 'Sécurité Standard'})
© 2025 WM AI TECHNOLOGIES INC.
Système initialisé - Prêt à exécuter des commandes.
Tapez 'help' pour voir la liste des commandes disponibles.`,
      timestamp: new Date()
    }
  ]);
  const [commandHistory, setCommandHistory] = useState<string[]>([]);
  const [historyIndex, setHistoryIndex] = useState<number>(-1);
  const [isDownloading, setIsDownloading] = useState<boolean>(false);
  const [currentDownload, setCurrentDownload] = useState<{url: string, dest: string, progress: number} | null>(null);
  const [isUpdating, setIsUpdating] = useState<boolean>(false);
  const [updateProgress, setUpdateProgress] = useState<number>(0);
  const [updateStep, setUpdateStep] = useState<string>('');
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [currentProcess, setCurrentProcess] = useState<string | null>(null);
  const [processTimeout, setProcessTimeout] = useState<ReturnType<typeof setTimeout> | null>(null);
  const [showVirtualKeyboard, setShowVirtualKeyboard] = useState<boolean>(isMobile);
  
  // Google Cloud integration
  const [gcloudCommand, setGcloudCommand] = useState<string>('');
  const [showGcloudSection, setShowGcloudSection] = useState<boolean>(true);
  
  const terminalRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Auto-scroll to bottom when history changes
  useEffect(() => {
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [history]);

  // Focus input when component mounts
  useEffect(() => {
    inputRef.current?.focus();
    if (inputRef.current) {
      inputRef.current.selectionStart = input.length;
      inputRef.current.selectionEnd = input.length;
      setCursorPosition(input.length);
    }
  }, []);

  // Update cursor position when input changes
  useEffect(() => {
    if (inputRef.current) {
      setCursorPosition(inputRef.current.selectionStart || input.length);
    }
  }, [input]);

  // Update virtual keyboard visibility when isMobile changes
  useEffect(() => {
    setShowVirtualKeyboard(isMobile);
  }, [isMobile]);

  // For accessibility and better UX, keep input focused when clicking on the terminal
  const handleTerminalClick = () => {
    inputRef.current?.focus();
  };

  // Ctrl+C interrupt handler
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Detect Ctrl+C
      if (e.ctrlKey && e.key === 'c') {
        if (isRunning) {
          interruptCurrentProcess();
          e.preventDefault();
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isRunning]);

  // Run a terminal process
  const runProcess = (processName: string, duration: number, output: string, isError = false) => {
    if (isRunning) {
      addOutput(`Error: A process is already running: ${currentProcess}`, 'error');
      return;
    }

    setIsRunning(true);
    setCurrentProcess(processName);
    addOutput(`Running: ${processName}...`, 'output');

    // Create a timeout to complete the process
    const timeout = setTimeout(() => {
      setIsRunning(false);
      setCurrentProcess(null);
      
      if (isError) {
        addOutput(output, 'error');
      } else {
        addOutput(output, 'success');
      }
    }, duration);

    setProcessTimeout(timeout);
  };

  // Interrupt the current process (Ctrl+C)
  const interruptCurrentProcess = () => {
    if (!isRunning || !currentProcess) return;

    if (processTimeout) {
      clearTimeout(processTimeout);
    }

    setIsRunning(false);
    setCurrentProcess(null);
    addOutput(`^C`, 'input');
    addOutput(`Process ${currentProcess} interrupted`, 'error');
  };

  // Add a new entry to the terminal history
  const addOutput = (content: string, type: TerminalEntry['type'] = 'output') => {
    setHistory(prev => [...prev, { type, content, timestamp: new Date() }]);
  };

  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Prevent empty commands
    if (!input.trim()) {
      return;
    }

    // Add command to history
    addOutput(input, 'input');
    
    // Add to command history for up/down navigation
    setCommandHistory(prev => [input, ...prev]);
    setHistoryIndex(-1);

    // Process the command
    processCommand(input);
    
    // Reset input
    setInput('');
    setCursorPosition(0);
  };

  // Process user commands
  const processCommand = (cmd: string) => {
    const args = cmd.trim().split(' ');
    const command = args[0].toLowerCase();

    // Log command execution (excluding sensitive commands)
    if (!['login', 'passwd', 'sudo'].includes(command)) {
      addLogEntry(LogLevel.INFO, `Terminal command executed: ${command}`, { args: args.slice(1) });
    }

    switch (command) {
      case 'help':
        addOutput(`
Commandes disponibles:

Système:
  help                - Affiche cette aide
  clear               - Efface l'écran du terminal
  echo [texte]        - Affiche le texte
  info                - Affiche les informations système
  shutdown            - Éteint le système
  reload              - Redémarre le terminal

Fichiers:
  ls [dossier]        - Liste les fichiers dans un dossier
  cd [dossier]        - Change de dossier courant
  mkdir [dossier]     - Crée un nouveau dossier
  touch [fichier]     - Crée un nouveau fichier
  rm [fichier]        - Supprime un fichier
  cat [fichier]       - Affiche le contenu d'un fichier

Réseau:
  ping [hôte]         - Envoie un ping à l'hôte
  wget [url]          - Télécharge un fichier depuis une URL
  curl [url]          - Récupère le contenu d'une URL
  ssh [serveur]       - Connect to a remote server

Google Cloud:
  gcloud [commande]   - Exécute une commande Google Cloud
  gcloud-vm-list      - Liste les instances VM
  gcloud-vm-create    - Crée une nouvelle instance VM
  gcloud-vm-delete    - Supprime une instance VM
  gcloud-status       - Affiche le statut de Google Cloud

Sécurité:
  encrypt [fichier]   - Chiffre un fichier
  decrypt [fichier]   - Déchiffre un fichier
  keygen              - Génère une nouvelle clé SSH
  passwd              - Change le mot de passe

API:
  api list            - Liste les endpoints API disponibles
  api call [endpoint] - Appelle un endpoint API

Mises à jour:
  update check        - Vérifie les mises à jour disponibles
  update download     - Télécharge la mise à jour
  update install      - Installe la mise à jour

Processus:
  ps                  - Affiche les processus en cours
  kill [pid]          - Termine un processus
`);
        break;

      case 'clear':
        setHistory([]);
        break;

      case 'echo':
        addOutput(args.slice(1).join(' '));
        break;

      case 'info':
        addOutput(`
Terminal: WM Terminal Cloud v1.0.0
OS: WM OS v2.5.2
Niveau de sécurité: ${securityLevel}
Date: ${new Date().toLocaleString()}
Architecture: 64-bit
Mode: ${process.env.NODE_ENV === 'production' ? 'Production' : 'Développement'}
`);
        break;

      case 'shutdown':
      case 'exit':
        addOutput('Arrêt du système...');
        setTimeout(() => {
          addOutput('Système arrêté. Rechargez la page pour redémarrer.', 'success');
        }, 1500);
        break;

      case 'reload':
        addOutput('Redémarrage du terminal...');
        setTimeout(() => {
          window.location.reload();
        }, 1000);
        break;

      case 'ls':
        // Simulate listing files
        const files = [
          'Documents/', 
          'Images/', 
          'scripts/',
          'config.json',
          'README.md',
          'data.csv',
          '.env',
          'index.html',
          'app.js',
          'styles.css'
        ];
        
        addOutput(files.join('  '));
        break;

      case 'cd':
        // Simulate changing directory
        const dir = args[1] || '~';
        addOutput(`Changement vers le répertoire: ${dir}`);
        break;

      case 'mkdir':
        if (!args[1]) {
          addOutput('Erreur: Nom de dossier requis.', 'error');
          break;
        }
        addOutput(`Dossier créé: ${args[1]}`);
        break;

      case 'touch':
        if (!args[1]) {
          addOutput('Erreur: Nom de fichier requis.', 'error');
          break;
        }
        addOutput(`Fichier créé: ${args[1]}`);
        break;

      case 'rm':
        if (!args[1]) {
          addOutput('Erreur: Nom de fichier requis.', 'error');
          break;
        }
        addOutput(`Fichier supprimé: ${args[1]}`);
        break;

      case 'cat':
        if (!args[1]) {
          addOutput('Erreur: Nom de fichier requis.', 'error');
          break;
        }
        
        // Simulate different file contents
        if (args[1] === 'config.json') {
          addOutput(`{
  "apiVersion": "1.0",
  "server": "https://api.wmterminal.com",
  "security": "${securityLevel}",
  "timeout": 30000,
  "retries": 3
}`);
        } else if (args[1] === 'README.md') {
          addOutput(`# WM Terminal Cloud

Système de terminal sécurisé pour environnements cloud.

## Fonctionnalités

- Terminal intégré avec commandes unix
- Intégration API avec passerelle sécurisée
- Gestion de dépôts de code
- Chiffrement de bout en bout (niveau ${securityLevel})

## Version

1.0.0 (2025)`);
        } else if (args[1] === '.env') {
          addOutput(`Erreur: Permission refusée. Ce fichier contient des données sensibles.`, 'error');
        } else {
          addOutput(`Erreur: Fichier ${args[1]} introuvable.`, 'error');
        }
        break;

      case 'ping':
        const host = args[1] || 'localhost';
        // Run a process with a timeout
        runProcess(`ping ${host}`, 3000, `
PING ${host} (127.0.0.1) 56(84) bytes of data.
64 bytes from ${host} icmp_seq=1 ttl=64 time=0.034 ms
64 bytes from ${host} icmp_seq=2 ttl=64 time=0.035 ms
64 bytes from ${host} icmp_seq=3 ttl=64 time=0.026 ms
64 bytes from ${host} icmp_seq=4 ttl=64 time=0.030 ms

--- ${host} ping statistics ---
4 packets transmitted, 4 received, 0% packet loss, time 3053ms
rtt min/avg/max/mdev = 0.026/0.031/0.035/0.003 ms`);
        break;

      case 'wget':
        if (!args[1]) {
          addOutput('Erreur: URL requise.', 'error');
          break;
        }

        setIsDownloading(true);
        setCurrentDownload({
          url: args[1],
          dest: args[1].split('/').pop() || 'download.file',
          progress: 0
        });

        // Simulate download progress
        let progress = 0;
        const downloadInterval = setInterval(() => {
          progress += 10;
          setCurrentDownload(prev => prev ? { ...prev, progress } : null);

          if (progress >= 100) {
            clearInterval(downloadInterval);
            setIsDownloading(false);
            addOutput(`Téléchargement terminé: ${args[1]} -> ${args[1].split('/').pop() || 'download.file'}`, 'success');
            setCurrentDownload(null);
          }
        }, 500);
        break;

      case 'curl':
        if (!args[1]) {
          addOutput('Erreur: URL requise.', 'error');
          break;
        }

        // Run a process that simulates fetching content
        runProcess(`curl ${args[1]}`, 2000, `
{
  "status": "success",
  "data": {
    "id": 1234,
    "name": "WM Terminal API",
    "version": "1.0.0",
    "timestamp": "${new Date().toISOString()}"
  }
}`);
        break;

      case 'ssh':
        if (!args[1]) {
          addOutput('Erreur: Serveur requis.', 'error');
          break;
        }

        // Simulate SSH connection
        addOutput(`Connecting to ${args[1]}...`);
        setTimeout(() => {
          addOutput(`Authentification réussie. Connecté à ${args[1]}.`, 'success');
        }, 1500);
        break;

      case 'encrypt':
        if (!args[1]) {
          addOutput('Erreur: Nom de fichier requis.', 'error');
          break;
        }

        // Simulate encryption with security level
        const encryptionAlgo = securityLevel === 'extreme' ? 'AES-512-GCM' : 
                              securityLevel === 'high' ? 'AES-256-GCM' : 
                              'AES-128-CBC';
        
        runProcess(`encrypt ${args[1]}`, 2000, `Fichier ${args[1]} chiffré avec ${encryptionAlgo}.`);
        break;

      case 'decrypt':
        if (!args[1]) {
          addOutput('Erreur: Nom de fichier requis.', 'error');
          break;
        }
        
        // Simulate decryption
        runProcess(`decrypt ${args[1]}`, 1500, `Fichier ${args[1]} déchiffré.`);
        break;

      case 'keygen':
        // Simulate key generation
        runProcess('keygen', 3000, `
Generating public/private RSA key pair.
Your identification has been saved in ~/.ssh/id_rsa.
Your public key has been saved in ~/.ssh/id_rsa.pub.
The key fingerprint is:
SHA256:pJIQw2xVfbPYKJRj1CoKMzQSDLxxx+PO+XXX+XX+XXX
The key's randomart image is:
+---[RSA 3072]----+
|        o+.      |
|       .+.o      |
|     . o.+       |
|    . * O        |
|   o = @ S       |
|  o + X +        |
| . + @ +         |
|  . B +          |
|   o.=           |
+----[SHA256]-----+`);
        break;

      case 'passwd':
        // Simulate password change
        addOutput('Changing password:');
        addOutput('Current password: ********');
        addOutput('New password: ********');
        addOutput('Retype new password: ********');
        addOutput('Password changed successfully.', 'success');
        break;

      case 'api':
        if (args[1] === 'list') {
          // List API endpoints
          addOutput(`
API Endpoints disponibles:

GET  /api/v1/users
POST /api/v1/users
GET  /api/v1/projects
POST /api/v1/projects
PUT  /api/v1/projects/:id
GET  /api/v1/stats
GET  /api/v1/status
`);
        } else if (args[1] === 'call') {
          if (!args[2]) {
            addOutput('Erreur: Endpoint API requis.', 'error');
            break;
          }

          // Simulate API call
          runProcess(`api call ${args[2]}`, 1500, `
{
  "success": true,
  "endpoint": "${args[2]}",
  "data": {
    "items": [
      { "id": 1, "name": "Item 1" },
      { "id": 2, "name": "Item 2" },
      { "id": 3, "name": "Item 3" }
    ],
    "count": 3,
    "timestamp": "${new Date().toISOString()}"
  }
}`);
        } else {
          addOutput('Commandes API disponibles: list, call', 'error');
        }
        break;

      // Google Cloud specific commands
      case 'gcloud':
        if (args.length < 2) {
          addOutput('Erreur: Commande gcloud requise. Essayez "gcloud help" pour voir les commandes disponibles.', 'error');
          break;
        }
        
        // Process gcloud subcommands
        const subcommand = args[1].toLowerCase();
        
        switch (subcommand) {
          case 'help':
            addOutput(`
Commandes Google Cloud disponibles:

Compute Engine:
  gcloud compute instances list          - Liste des instances VM
  gcloud compute instances create [name] - Crée une instance VM
  gcloud compute instances delete [name] - Supprime une instance VM
  gcloud compute instances start [name]  - Démarre une instance VM
  gcloud compute instances stop [name]   - Arrête une instance VM

Storage:
  gcloud storage ls                      - Liste des buckets
  gcloud storage ls gs://[bucket]        - Liste le contenu d'un bucket
  gcloud storage cp [source] [dest]      - Copie des fichiers

IAM:
  gcloud iam service-accounts list       - Liste des comptes de service
  gcloud projects get-iam-policy         - Affiche les politiques IAM

Auth:
  gcloud auth list                       - Liste des comptes authentifiés
  gcloud auth login                      - Se connecter à Google Cloud
  gcloud auth revoke                     - Se déconnecter

Pour plus d'informations, consultez la documentation Google Cloud.
`);
            break;
          
          case 'compute':
            if (args[2] === 'instances') {
              if (args[3] === 'list') {
                runProcess('gcloud compute instances list', 2000, `
NAME           ZONE           MACHINE_TYPE   PREEMPTIBLE  INTERNAL_IP  EXTERNAL_IP     STATUS
instance-1     us-central1-a  e2-medium      false        10.0.0.2     34.68.XX.XX     RUNNING
instance-2     us-central1-b  e2-standard-2  false        10.0.0.3     35.22.XX.XX     TERMINATED
test-server    us-west1-a     e2-small       true         10.0.0.4     35.197.XX.XX    RUNNING
`);
              } else if (args[3] === 'create') {
                if (!args[4]) {
                  addOutput('Erreur: Nom d\'instance requis', 'error');
                  break;
                }
                runProcess(`gcloud compute instances create ${args[4]}`, 4000, `
Creating instance(s) ${args[4]}...
Created [https://www.googleapis.com/compute/v1/projects/project-id/zones/us-central1-a/instances/${args[4]}].
NAME        ZONE           MACHINE_TYPE  PREEMPTIBLE  INTERNAL_IP  EXTERNAL_IP    STATUS
${args[4]}  us-central1-a  e2-medium     false        10.0.0.5     35.222.XX.XX   RUNNING
`);
              } else if (args[3] === 'delete') {
                if (!args[4]) {
                  addOutput('Erreur: Nom d\'instance requis', 'error');
                  break;
                }
                runProcess(`gcloud compute instances delete ${args[4]}`, 3000, `
The following instances will be deleted:
 - ${args[4]} in us-central1-a

Deleted [https://www.googleapis.com/compute/v1/projects/project-id/zones/us-central1-a/instances/${args[4]}].
`);
              } else if (args[3] === 'start') {
                if (!args[4]) {
                  addOutput('Erreur: Nom d\'instance requis', 'error');
                  break;
                }
                runProcess(`gcloud compute instances start ${args[4]}`, 3000, `
Starting instance(s) ${args[4]}...
Started [https://www.googleapis.com/compute/v1/projects/project-id/zones/us-central1-a/instances/${args[4]}].
`);
              } else if (args[3] === 'stop') {
                if (!args[4]) {
                  addOutput('Erreur: Nom d\'instance requis', 'error');
                  break;
                }
                runProcess(`gcloud compute instances stop ${args[4]}`, 2500, `
Stopping instance(s) ${args[4]}...
Stopped [https://www.googleapis.com/compute/v1/projects/project-id/zones/us-central1-a/instances/${args[4]}].
`);
              } else {
                addOutput(`Erreur: Commande inconnue. Essayez "gcloud compute instances list|create|delete|start|stop"`, 'error');
              }
            } else {
              addOutput('Erreur: Sous-commande compute inconnue. Essayez "gcloud compute instances"', 'error');
            }
            break;
          
          case 'storage':
            if (args[2] === 'ls') {
              if (args[3] && args[3].startsWith('gs://')) {
                runProcess(`gcloud storage ls ${args[3]}`, 1500, `
gs://${args[3].substring(5)}/file1.txt
gs://${args[3].substring(5)}/file2.jpg
gs://${args[3].substring(5)}/folder/
gs://${args[3].substring(5)}/data.json
`);
              } else {
                runProcess('gcloud storage ls', 1500, `
gs://bucket1/
gs://bucket2/
gs://backup-bucket/
gs://static-assets/
`);
              }
            } else if (args[2] === 'cp') {
              if (!args[3] || !args[4]) {
                addOutput('Erreur: Source et destination requises', 'error');
                break;
              }
              runProcess(`gcloud storage cp ${args[3]} ${args[4]}`, 3000, `
Copying ${args[3]} to ${args[4]}...
Operation completed successfully.
`);
            } else {
              addOutput('Erreur: Sous-commande storage inconnue. Essayez "gcloud storage ls|cp"', 'error');
            }
            break;
          
          case 'auth':
            if (args[2] === 'list') {
              runProcess('gcloud auth list', 1000, `
                  Credentialed Accounts
ACTIVE  ACCOUNT
*       user@example.com
`);
            } else if (args[2] === 'login') {
              runProcess('gcloud auth login', 2000, `
Vous avez besoin d'utiliser un navigateur pour vous authentifier.

Un navigateur s'ouvrira automatiquement en allant à l'URL suivante :
  https://accounts.google.com/o/oauth2/auth?...

Simulation: Authentification réussie.
Vous êtes maintenant connecté en tant que user@example.com.
`);
            } else if (args[2] === 'revoke') {
              runProcess('gcloud auth revoke', 1500, `
Revoked credentials for user@example.com.
`);
            } else {
              addOutput('Erreur: Sous-commande auth inconnue. Essayez "gcloud auth list|login|revoke"', 'error');
            }
            break;
          
          case 'iam':
            if (args[2] === 'service-accounts' && args[3] === 'list') {
              runProcess('gcloud iam service-accounts list', 1500, `
NAME                                    EMAIL                                               DISABLED
App Engine default service account      app-engine@project-id.iam.gserviceaccount.com       False
Compute Engine default service account  compute@project-id.iam.gserviceaccount.com          False
Custom Service Account                  custom@project-id.iam.gserviceaccount.com           False
`);
            } else if (args[2] === 'projects' && args[3] === 'get-iam-policy') {
              runProcess('gcloud projects get-iam-policy', 2000, `
bindings:
- members:
  - serviceAccount:service-00000@compute-system.iam.gserviceaccount.com
  role: roles/compute.serviceAgent
- members:
  - user:user@example.com
  role: roles/owner
etag: BwX5GOfgZK8=
version: 1
`);
            } else {
              addOutput('Erreur: Sous-commande IAM inconnue', 'error');
            }
            break;
          
          default:
            addOutput(`Erreur: Sous-commande gcloud '${subcommand}' inconnue. Essayez "gcloud help" pour voir les commandes disponibles.`, 'error');
        }
        break;
      
      // Simplified Google Cloud commands
      case 'gcloud-vm-list':
        processCommand('gcloud compute instances list');
        break;
        
      case 'gcloud-vm-create':
        addOutput('Entrez le nom de l\'instance VM à créer:');
        setInput('gcloud compute instances create ');
        setCursorPosition('gcloud compute instances create '.length);
        break;
        
      case 'gcloud-vm-delete':
        addOutput('Entrez le nom de l\'instance VM à supprimer:');
        setInput('gcloud compute instances delete ');
        setCursorPosition('gcloud compute instances delete '.length);
        break;
        
      case 'gcloud-status':
        runProcess('gcloud status', 1500, `
Google Cloud SDK Status:
  Version: 445.0.0
  Account: user@example.com
  Project: project-id
  Region: us-central1
  Zone: us-central1-a
  Installed Components:
    - gcloud
    - gsutil
    - bq
  Default services enabled:
    - Compute Engine
    - Storage
    - BigQuery
`);
        break;

      case 'update':
        switch (args[1]) {
          case 'check':
            setIsUpdating(true);
            setUpdateStep('checking');
            setUpdateProgress(0);
            
            // Simulate update check progress
            let checkProgress = 0;
            const checkInterval = setInterval(() => {
              checkProgress += 20;
              setUpdateProgress(Math.min(checkProgress, 100));
              
              if (checkProgress >= 100) {
                clearInterval(checkInterval);
                setIsUpdating(false);
                
                // Random chance of update being available
                if (Math.random() > 0.5) {
                  addOutput('Une mise à jour est disponible: v1.1.0', 'success');
                  addOutput('Utilisez "update download" pour télécharger la mise à jour.');
                } else {
                  addOutput('Le système est à jour.');
                }
              }
            }, 300);
            break;
            
          case 'download':
            setIsUpdating(true);
            setUpdateStep('downloading');
            setUpdateProgress(0);
            
            // Simulate download progress
            let downloadProgress = 0;
            const downloadInterval = setInterval(() => {
              downloadProgress += 10;
              setUpdateProgress(Math.min(downloadProgress, 100));
              
              if (downloadProgress >= 100) {
                clearInterval(downloadInterval);
                setUpdateStep('verifying');
                
                // Simulate verification
                setTimeout(() => {
                  setIsUpdating(false);
                  addOutput('Mise à jour téléchargée et vérifiée.', 'success');
                  addOutput('Utilisez "update install" pour installer la mise à jour.');
                }, 1000);
              }
            }, 500);
            break;
            
          case 'install':
            setIsUpdating(true);
            setUpdateStep('installing');
            setUpdateProgress(0);
            
            // Simulate installation progress
            let installProgress = 0;
            const installInterval = setInterval(() => {
              installProgress += 10;
              setUpdateProgress(Math.min(installProgress, 100));
              
              if (installProgress >= 100) {
                clearInterval(installInterval);
                setTimeout(() => {
                  setIsUpdating(false);
                  addOutput('Mise à jour installée avec succès.', 'success');
                  addOutput('Redémarrage nécessaire pour appliquer les changements.');
                }, 1000);
              }
            }, 300);
            break;
            
          default:
            addOutput('Usage: update [check|download|install]', 'error');
        }
        break;

      case 'ps':
        // Simulate process list
        addOutput(`
PID   USER     CPU  MEM   COMMAND
1     root     0.0  0.1%  /sbin/init
142   root     0.0  0.3%  /usr/sbin/sshd
423   www      0.2  1.2%  /usr/sbin/apache2
682   mysql    0.5  8.7%  /usr/sbin/mysqld
921   admin    2.1  4.5%  /usr/bin/node server.js
${isRunning ? `1024  admin    5.3  2.1%  ${currentProcess}` : ''}`);
        break;

      case 'kill':
        if (!args[1]) {
          addOutput('Erreur: PID requis.', 'error');
          break;
        }
        
        if (isRunning && args[1] === '1024') {
          interruptCurrentProcess();
        } else {
          addOutput(`Process with PID ${args[1]} terminated.`);
        }
        break;

      default:
        // Simulate command not found
        if (command.length > 0) {
          addOutput(`${command}: command not found`, 'error');
        }
    }
  };

  // Handle keyboard navigation through command history and cursor movement
  const handleKeyDown = (e: React.KeyboardEvent) => {
    // Handle up/down arrows for command history
    if (e.key === 'ArrowUp') {
      e.preventDefault();
      // Navigate to previous command in history
      setHistoryIndex(prevIndex => {
        const newIndex = prevIndex < commandHistory.length - 1 ? prevIndex + 1 : prevIndex;
        if (newIndex >= 0 && newIndex < commandHistory.length) {
          setInput(commandHistory[newIndex]);
          // Set cursor to end of input
          setTimeout(() => {
            if (inputRef.current) {
              inputRef.current.selectionStart = commandHistory[newIndex].length;
              inputRef.current.selectionEnd = commandHistory[newIndex].length;
              setCursorPosition(commandHistory[newIndex].length);
            }
          }, 0);
        }
        return newIndex;
      });
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      // Navigate to next command in history or empty input
      setHistoryIndex(prevIndex => {
        const newIndex = prevIndex > 0 ? prevIndex - 1 : -1;
        if (newIndex >= 0) {
          setInput(commandHistory[newIndex]);
          // Set cursor to end of input
          setTimeout(() => {
            if (inputRef.current) {
              inputRef.current.selectionStart = commandHistory[newIndex].length;
              inputRef.current.selectionEnd = commandHistory[newIndex].length;
              setCursorPosition(commandHistory[newIndex].length);
            }
          }, 0);
        } else {
          setInput('');
          setCursorPosition(0);
        }
        return newIndex;
      });
    } else if (e.key === 'ArrowLeft') {
      // Move cursor left if possible
      if (inputRef.current?.selectionStart && inputRef.current.selectionStart > 0) {
        const newPosition = inputRef.current.selectionStart - 1;
        inputRef.current.selectionStart = newPosition;
        inputRef.current.selectionEnd = newPosition;
        setCursorPosition(newPosition);
      }
    } else if (e.key === 'ArrowRight') {
      // Move cursor right if possible
      if (inputRef.current?.selectionStart !== undefined && 
          inputRef.current.selectionStart < input.length) {
        const newPosition = inputRef.current.selectionStart + 1;
        inputRef.current.selectionStart = newPosition;
        inputRef.current.selectionEnd = newPosition;
        setCursorPosition(newPosition);
      }
    } else if (e.ctrlKey && e.key === 'c') {
      if (isRunning) {
        interruptCurrentProcess();
        e.preventDefault();
      }
    } else if (e.key === 'Tab') {
      e.preventDefault();
      // Simple tab completion for commands
      if (input.trim().length > 0) {
        const commands = ['help', 'clear', 'echo', 'info', 'shutdown', 'reload', 'ls', 'cd', 'mkdir', 'touch', 'rm', 'cat', 'ping', 'wget', 'curl', 'ssh', 'encrypt', 'decrypt', 'keygen', 'passwd', 'api', 'update', 'ps', 'kill', 'gcloud', 'gcloud-vm-list', 'gcloud-vm-create', 'gcloud-vm-delete', 'gcloud-status'];
        const matchingCommands = commands.filter(cmd => cmd.startsWith(input.trim().toLowerCase()));
        
        if (matchingCommands.length === 1) {
          setInput(matchingCommands[0]);
          setCursorPosition(matchingCommands[0].length);
          if (inputRef.current) {
            inputRef.current.selectionStart = matchingCommands[0].length;
            inputRef.current.selectionEnd = matchingCommands[0].length;
          }
        } else if (matchingCommands.length > 1) {
          addOutput(matchingCommands.join('  '));
        }
      }
    }
  };

  // Insert text at current cursor position in input
  const insertText = (text: string) => {
    setInput(prevInput => {
      const before = prevInput.slice(0, cursorPosition);
      const after = prevInput.slice(cursorPosition);
      const newInput = before + text + after;
      
      // Update cursor position
      setCursorPosition(cursorPosition + text.length);
      
      // Update input field selection (needs to be done after render)
      setTimeout(() => {
        if (inputRef.current) {
          const newPosition = cursorPosition + text.length;
          inputRef.current.selectionStart = newPosition;
          inputRef.current.selectionEnd = newPosition;
          inputRef.current.focus();
        }
      }, 0);
      
      return newInput;
    });
  };

  // Handle backspace key
  const handleBackspace = () => {
    if (cursorPosition > 0) {
      setInput(prevInput => {
        const before = prevInput.slice(0, cursorPosition - 1);
        const after = prevInput.slice(cursorPosition);
        const newInput = before + after;
        
        // Update cursor position
        setCursorPosition(cursorPosition - 1);
        
        // Update input field selection (needs to be done after render)
        setTimeout(() => {
          if (inputRef.current) {
            const newPosition = cursorPosition - 1;
            inputRef.current.selectionStart = newPosition;
            inputRef.current.selectionEnd = newPosition;
            inputRef.current.focus();
          }
        }, 0);
        
        return newInput;
      });
    }
  };

  // Handle special keys
  const handleSpecialKey = (action: string) => {
    switch (action) {
      case 'enter':
        handleSubmit(new Event('submit') as any);
        break;
      case 'arrowUp':
        if (commandHistory.length > 0) {
          setHistoryIndex(prevIndex => {
            const newIndex = prevIndex < commandHistory.length - 1 ? prevIndex + 1 : prevIndex;
            if (newIndex >= 0) {
              setInput(commandHistory[newIndex]);
              // Set cursor to end of input
              setTimeout(() => {
                if (inputRef.current) {
                  const position = commandHistory[newIndex].length;
                  inputRef.current.selectionStart = position;
                  inputRef.current.selectionEnd = position;
                  setCursorPosition(position);
                  inputRef.current.focus();
                }
              }, 0);
            }
            return newIndex;
          });
        }
        break;
      case 'arrowDown':
        setHistoryIndex(prevIndex => {
          const newIndex = prevIndex > 0 ? prevIndex - 1 : -1;
          if (newIndex >= 0) {
            setInput(commandHistory[newIndex]);
            // Set cursor to end of input
            setTimeout(() => {
              if (inputRef.current) {
                const position = commandHistory[newIndex].length;
                inputRef.current.selectionStart = position;
                inputRef.current.selectionEnd = position;
                setCursorPosition(position);
                inputRef.current.focus();
              }
            }, 0);
          } else {
            setInput('');
            setCursorPosition(0);
            // Set cursor to start
            setTimeout(() => {
              if (inputRef.current) {
                inputRef.current.selectionStart = 0;
                inputRef.current.selectionEnd = 0;
                inputRef.current.focus();
              }
            }, 0);
          }
          return newIndex;
        });
        break;
      case 'arrowLeft':
        // Move cursor left if not at beginning
        if (cursorPosition > 0) {
          const newPosition = cursorPosition - 1;
          setCursorPosition(newPosition);
          setTimeout(() => {
            if (inputRef.current) {
              inputRef.current.selectionStart = newPosition;
              inputRef.current.selectionEnd = newPosition;
              inputRef.current.focus();
            }
          }, 0);
        }
        break;
      case 'arrowRight':
        // Move cursor right if not at end
        if (cursorPosition < input.length) {
          const newPosition = cursorPosition + 1;
          setCursorPosition(newPosition);
          setTimeout(() => {
            if (inputRef.current) {
              inputRef.current.selectionStart = newPosition;
              inputRef.current.selectionEnd = newPosition;
              inputRef.current.focus();
            }
          }, 0);
        }
        break;
      case 'clear':
        setHistory([]);
        break;
      case 'ctrlC':
        if (isRunning) {
          interruptCurrentProcess();
        }
        break;
      case 'tab':
        // Simple tab completion for commands
        if (input.trim().length > 0) {
          const commands = ['help', 'clear', 'echo', 'info', 'shutdown', 'reload', 'ls', 'cd', 'mkdir', 'touch', 'rm', 'cat', 'ping', 'wget', 'curl', 'ssh', 'encrypt', 'decrypt', 'keygen', 'passwd', 'api', 'update', 'ps', 'kill', 'gcloud', 'gcloud-vm-list', 'gcloud-vm-create', 'gcloud-vm-delete', 'gcloud-status'];
          const matchingCommands = commands.filter(cmd => cmd.startsWith(input.trim().toLowerCase()));
          
          if (matchingCommands.length === 1) {
            setInput(matchingCommands[0]);
            // Set cursor to end of input
            setTimeout(() => {
              if (inputRef.current) {
                const position = matchingCommands[0].length;
                inputRef.current.selectionStart = position;
                inputRef.current.selectionEnd = position;
                setCursorPosition(position);
                inputRef.current.focus();
              }
            }, 0);
          } else if (matchingCommands.length > 1) {
            addOutput(matchingCommands.join('  '));
          }
        }
        break;
      case 'space':
        insertText(' ');
        break;
      case 'copyCommand':
        // Copy current command
        navigator.clipboard.writeText(input);
        break;
      case 'home':
        // Move cursor to beginning of line
        setCursorPosition(0);
        setTimeout(() => {
          if (inputRef.current) {
            inputRef.current.selectionStart = 0;
            inputRef.current.selectionEnd = 0;
            inputRef.current.focus();
          }
        }, 0);
        break;
      case 'end':
        // Move cursor to end of line
        setCursorPosition(input.length);
        setTimeout(() => {
          if (inputRef.current) {
            inputRef.current.selectionStart = input.length;
            inputRef.current.selectionEnd = input.length;
            inputRef.current.focus();
          }
        }, 0);
        break;
    }
  };

  // Handle input changes, updating cursor position
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInput(e.target.value);
    setCursorPosition(e.target.selectionStart || 0);
  };

  // Toggle virtual keyboard
  const toggleVirtualKeyboard = () => {
    setShowVirtualKeyboard(!showVirtualKeyboard);
    // Focus on the input field after toggling
    setTimeout(() => {
      inputRef.current?.focus();
    }, 0);
  };

  // Execute Google Cloud command
  const executeGcloudCommand = () => {
    if (!gcloudCommand.trim()) {
      addOutput('Erreur: La commande Google Cloud ne peut pas être vide', 'error');
      return;
    }
    processCommand(`gcloud ${gcloudCommand}`);
    setGcloudCommand('');
  };

  // Handle gcloud command shortcuts
  const handleGcloudShortcut = (command: string) => {
    setGcloudCommand(command);
    setTimeout(() => {
      const gcloudInput = document.getElementById('gcloud-command') as HTMLInputElement;
      if (gcloudInput) {
        gcloudInput.focus();
      }
    }, 0);
  };

  // Toggle Google Cloud section
  const toggleGcloudSection = () => {
    setShowGcloudSection(!showGcloudSection);
  };

  // Render the Google Cloud section
  const renderGcloudSection = () => {
    if (!showGcloudSection) {
      return (
        <button 
          onClick={toggleGcloudSection}
          className="w-full flex items-center justify-between px-4 py-2 bg-gray-800 hover:bg-gray-700 rounded-md mb-4 border border-gray-700"
        >
          <div className="flex items-center">
            <Cloud size={18} className="text-violet-400 mr-2" />
            <span className="text-violet-100 font-medium">Google Cloud</span>
          </div>
          <span className="text-xs bg-violet-900/30 text-violet-300 px-2 py-0.5 rounded-full">
            Afficher
          </span>
        </button>
      );
    }
    
    return (
      <div className="bg-gray-800 rounded-lg p-4 mb-4 border border-violet-900/50">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <Cloud size={18} className="text-violet-400 mr-2" />
            <h3 className="text-lg font-semibold text-violet-100">Google Cloud</h3>
          </div>
          
          <button 
            onClick={toggleGcloudSection}
            className="text-gray-400 hover:text-violet-400 p-1"
          >
            <X size={16} />
          </button>
        </div>
        
        <div className="space-y-3">
          <div className="flex space-x-2">
            <input
              id="gcloud-command"
              type="text"
              placeholder="Commande Google Cloud (ex: compute instances list)"
              value={gcloudCommand}
              onChange={(e) => setGcloudCommand(e.target.value)}
              className="flex-1 bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:border-violet-500 focus:ring focus:ring-violet-500 focus:ring-opacity-50"
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  executeGcloudCommand();
                }
              }}
            />
            <button
              onClick={executeGcloudCommand}
              className="px-4 py-2 bg-violet-600 text-white rounded-md hover:bg-violet-700"
            >
              Exécuter
            </button>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            <button
              onClick={() => handleGcloudShortcut('compute instances list')}
              className="px-3 py-2 bg-gray-700 text-white rounded-md hover:bg-gray-600 hover:text-white text-sm flex flex-col items-center"
            >
              <span className="font-medium">Lister les VMs</span>
              <span className="text-xs text-gray-400 mt-1">instances list</span>
            </button>
            
            <button
              onClick={() => handleGcloudShortcut('compute instances create vm-')}
              className="px-3 py-2 bg-gray-700 text-white rounded-md hover:bg-gray-600 hover:text-white text-sm flex flex-col items-center"
            >
              <span className="font-medium">Créer une VM</span>
              <span className="text-xs text-gray-400 mt-1">instances create</span>
            </button>
            
            <button
              onClick={() => handleGcloudShortcut('compute instances delete ')}
              className="px-3 py-2 bg-gray-700 text-white rounded-md hover:bg-gray-600 hover:text-white text-sm flex flex-col items-center"
            >
              <span className="font-medium">Supprimer une VM</span>
              <span className="text-xs text-gray-400 mt-1">instances delete</span>
            </button>
            
            <button
              onClick={() => processCommand('gcloud-status')}
              className="px-3 py-2 bg-gray-700 text-white rounded-md hover:bg-gray-600 hover:text-white text-sm flex flex-col items-center"
            >
              <span className="font-medium">Status</span>
              <span className="text-xs text-gray-400 mt-1">gcloud-status</span>
            </button>
          </div>
          
          <div className="text-xs text-gray-400 mt-2">
            Conseil: Utilisez <code className="bg-gray-700 px-1 rounded">gcloud help</code> pour voir toutes les commandes disponibles.
          </div>
        </div>
      </div>
    );
  };

  // Render the virtual keyboard
  const renderVirtualKeyboard = () => {
    // Common button classes
    const baseButtonClass = "flex items-center justify-center rounded border border-gray-700 text-sm font-medium focus:outline-none transition-colors duration-200";
    const normalButtonClass = `${baseButtonClass} bg-gray-800 hover:bg-gray-700 text-white`;
    const specialButtonClass = `${baseButtonClass} bg-violet-900/30 hover:bg-violet-900/50 text-violet-300`;
    const dangerButtonClass = `${baseButtonClass} bg-red-900/30 hover:bg-red-900/50 text-red-300`;
    
    // Special character rows
    const row1 = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'];
    const row2 = ['!', '@', '#', '$', '%', '&', '*', '(', ')', '-'];
    const row3 = ['_', '+', '=', '[', ']', '{', '}', '|', '\\', '/'];
    const row4 = [';', ':', '"', '\'', '<', '>', ',', '.', '?', '~'];

    // Command shortcuts
    const commonCommands = [
      { label: 'help', action: () => setInput('help') },
      { label: 'ls', action: () => setInput('ls') },
      { label: 'cd', action: () => setInput('cd ') },
      { label: 'cat', action: () => setInput('cat ') },
      { label: 'clear', action: () => handleSpecialKey('clear') },
      { label: 'ping', action: () => setInput('ping ') }
    ];

    return (
      <div className="bg-gray-850 border-t border-gray-700 p-2 select-none">
        {/* Command shortcuts */}
        <div className="flex flex-wrap gap-1 mb-2">
          {commonCommands.map((cmd, index) => (
            <button 
              key={index}
              className={`${specialButtonClass} px-2 py-1`}
              onClick={cmd.action}
            >
              {cmd.label}
            </button>
          ))}
        </div>

        {/* Navigation and special keys */}
        <div className="flex gap-1 mb-2">
          <button 
            className={`${specialButtonClass} px-3 py-2 flex-1`}
            onClick={() => handleSpecialKey('home')}
          >
            Home
          </button>
          <button 
            className={`${specialButtonClass} px-3 py-2 flex-1`}
            onClick={() => handleSpecialKey('arrowLeft')}
          >
            <ArrowLeft size={16} />
          </button>
          <button 
            className={`${specialButtonClass} px-3 py-2 flex-1`}
            onClick={() => handleSpecialKey('arrowUp')}
          >
            <ArrowUp size={16} />
          </button>
          <button 
            className={`${specialButtonClass} px-3 py-2 flex-1`}
            onClick={() => handleSpecialKey('arrowDown')}
          >
            <ArrowDown size={16} />
          </button>
          <button 
            className={`${specialButtonClass} px-3 py-2 flex-1`}
            onClick={() => handleSpecialKey('arrowRight')}
          >
            <ArrowRight size={16} />
          </button>
          <button 
            className={`${specialButtonClass} px-3 py-2 flex-1`}
            onClick={() => handleSpecialKey('end')}
          >
            End
          </button>
        </div>

        <div className="flex gap-1 mb-2">
          <button 
            className={`${normalButtonClass} px-3 py-2 flex-1`}
            onClick={() => handleSpecialKey('tab')}
          >
            Tab
          </button>
          <button 
            className={`${dangerButtonClass} px-3 py-2 flex-1 ${!isRunning && 'opacity-60'}`}
            onClick={() => handleSpecialKey('ctrlC')}
            disabled={!isRunning}
          >
            Ctrl+C
          </button>
          <button 
            className={`${normalButtonClass} px-3 py-2 flex-1`}
            onClick={() => handleBackspace()}
          >
            <Delete size={16} />
          </button>
          <button 
            className={`${normalButtonClass} px-3 py-2 flex-1`}
            onClick={() => handleSpecialKey('space')}
          >
            Space
          </button>
          <button 
            className={`${specialButtonClass} px-3 py-2 flex-1`}
            onClick={() => handleSpecialKey('enter')}
          >
            Enter
          </button>
        </div>

        {/* Number row */}
        <div className="flex gap-1 mb-2">
          {row1.map((key) => (
            <button 
              key={key} 
              className={`${normalButtonClass} flex-1 py-2`}
              onClick={() => insertText(key)}
            >
              {key}
            </button>
          ))}
        </div>
        
        {/* Special chars row 1 */}
        <div className="flex gap-1 mb-2">
          {row2.map((key) => (
            <button 
              key={key} 
              className={`${normalButtonClass} flex-1 py-2`}
              onClick={() => insertText(key)}
            >
              {key}
            </button>
          ))}
        </div>
        
        {/* Special chars row 2 */}
        <div className="flex gap-1 mb-2">
          {row3.map((key) => (
            <button 
              key={key} 
              className={`${normalButtonClass} flex-1 py-2`}
              onClick={() => insertText(key)}
            >
              {key}
            </button>
          ))}
        </div>
        
        {/* Special chars row 3 */}
        <div className="flex gap-1 mb-2">
          {row4.map((key) => (
            <button 
              key={key} 
              className={`${normalButtonClass} flex-1 py-2`}
              onClick={() => insertText(key)}
            >
              {key}
            </button>
          ))}
        </div>

        {/* Letter rows */}
        <div className="flex gap-1 mb-2">
          {'qwertyuiop'.split('').map((key) => (
            <button 
              key={key} 
              className={`${normalButtonClass} flex-1 py-2`} 
              onClick={() => insertText(key)}
            >
              {key}
            </button>
          ))}
        </div>
        
        <div className="flex gap-1 mb-2 px-3">
          {'asdfghjkl'.split('').map((key) => (
            <button 
              key={key} 
              className={`${normalButtonClass} flex-1 py-2`} 
              onClick={() => insertText(key)}
            >
              {key}
            </button>
          ))}
        </div>
        
        <div className="flex gap-1 mb-2 px-6">
          {'zxcvbnm'.split('').map((key) => (
            <button 
              key={key} 
              className={`${normalButtonClass} flex-1 py-2`} 
              onClick={() => insertText(key)}
            >
              {key}
            </button>
          ))}
        </div>
      </div>
    );
  };
  
  const isVirtualKeyboardVisible = showVirtualKeyboard && isMobile;

  return (
    <div 
      className="flex-1 flex flex-col bg-gray-900 overflow-hidden"
    >
      <div 
        className={`flex-1 flex flex-col p-4 font-mono ${isVirtualKeyboardVisible ? 'overflow-y-auto' : 'overflow-hidden'}`}
        onClick={handleTerminalClick}
      >
        {renderGcloudSection()}

        <div className="flex-1 overflow-y-auto mb-4" ref={terminalRef}>
          {history.map((entry, index) => (
            <div 
              key={index} 
              className={`mb-1 ${
                entry.type === 'input' ? 'text-violet-300' : 
                entry.type === 'error' ? 'text-red-400' : 
                entry.type === 'success' ? 'text-green-400' :
                'text-gray-300'
              }`}
            >
              {entry.type === 'input' ? (
                <span>
                  <span className="text-green-400">wmterm@cloud</span>
                  <span className="text-gray-400">:</span>
                  <span className="text-blue-400">~$</span> {entry.content}
                </span>
              ) : (
                <span>{entry.content}</span>
              )}
            </div>
          ))}

          {isDownloading && currentDownload && (
            <div className="my-2 bg-gray-800 rounded border border-gray-700 p-2">
              <div className="flex justify-between text-xs mb-1">
                <span>Téléchargement de {currentDownload.url}</span>
                <span>{currentDownload.progress}%</span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-1">
                <div 
                  className="bg-violet-600 h-1 rounded-full"
                  style={{ width: `${currentDownload.progress}%` }}
                ></div>
              </div>
            </div>
          )}

          {isUpdating && (
            <div className="my-2 bg-gray-800 rounded border border-gray-700 p-2">
              <div className="flex justify-between text-xs mb-1">
                <span>
                  {updateStep === 'checking' && 'Vérification des mises à jour...'}
                  {updateStep === 'downloading' && 'Téléchargement de la mise à jour...'}
                  {updateStep === 'verifying' && 'Vérification de la mise à jour...'}
                  {updateStep === 'installing' && 'Installation de la mise à jour...'}
                </span>
                <span>{updateProgress}%</span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-1">
                <div 
                  className="bg-violet-600 h-1 rounded-full"
                  style={{ width: `${updateProgress}%` }}
                ></div>
              </div>
            </div>
          )}

          {isRunning && (
            <div className="animate-pulse text-violet-400 mb-1">
              <span className="text-green-400">wmterm@cloud</span>
              <span className="text-gray-400">:</span>
              <span className="text-blue-400">~$</span> {currentProcess} <span className="animate-ping">▋</span>
            </div>
          )}

          {!isRunning && (
            <div className="text-white">
              <span className="text-green-400">wmterm@cloud</span>
              <span className="text-gray-400">:</span>
              <span className="text-blue-400">~$</span> 
              {input.substring(0, cursorPosition)}
              <span className="animate-pulse">▋</span>
              {input.substring(cursorPosition)}
            </div>
          )}
        </div>
        
        <div className="relative">
          <form onSubmit={handleSubmit} className="relative">
            <input
              ref={inputRef}
              type="text"
              className="w-full bg-gray-800 border border-gray-700 text-white rounded py-2 px-3 focus:outline-none focus:border-violet-500"
              value={input}
              onChange={handleInputChange}
              onKeyDown={handleKeyDown}
              onSelect={(e) => setCursorPosition(e.currentTarget.selectionStart || 0)}
              onFocus={(e) => setCursorPosition(e.currentTarget.selectionStart || 0)}
              disabled={isRunning}
              autoCapitalize="none"
              autoComplete="off"
              autoCorrect="off"
              spellCheck="false"
            />
            
            {isMobile && (
              <div className="absolute right-0 top-0 flex">
                <button 
                  type="button"
                  onClick={() => handleSpecialKey('copyCommand')}
                  className="h-full px-2 text-gray-400 hover:text-violet-400 flex items-center"
                >
                  <Copy size={18} />
                </button>
                <button 
                  type="button"
                  onClick={toggleVirtualKeyboard}
                  className="h-full px-2 text-gray-400 hover:text-violet-400 flex items-center"
                >
                  <Keyboard size={18} />
                </button>
              </div>
            )}
          </form>
        </div>
        
        <div className="flex justify-between mt-2 text-xs text-gray-500">
          <div className="flex space-x-2 items-center">
            <ShieldCheck size={14} className={securityLevel === 'extreme' ? 'text-violet-400' : securityLevel === 'high' ? 'text-purple-400' : 'text-red-400'} />
            <span>{securityLevel === 'extreme' ? 'Sécurité Extrême' : securityLevel === 'high' ? 'Haute Sécurité' : 'Sécurité Standard'}</span>
          </div>
          
          <div className="flex items-center">
            {isRunning ? (
              <button 
                onClick={interruptCurrentProcess}
                className="flex items-center text-red-400 hover:text-red-300"
              >
                <X size={14} className="mr-1" />
                <span>Interrompre (Ctrl+C)</span>
              </button>
            ) : (
              <span>Prêt</span>
            )}
          </div>
        </div>
      </div>
      
      {/* Virtual keyboard */}
      {isVirtualKeyboardVisible && renderVirtualKeyboard()}
    </div>
  );
};