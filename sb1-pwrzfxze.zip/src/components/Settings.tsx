import React, { useState } from 'react';
import { Shield, Monitor, Smartphone, Lock, Key, AlertTriangle, Check, Save, Smartphone as SmartphoneIcon, Copy } from 'lucide-react';
import { TwoFactorSetup } from './TwoFactorSetup';
import { encryptData, decryptData } from '../utils/security';
import { addLogEntry, LogLevel } from '../utils/logger';

type SettingsProps = {
  securityLevel: 'standard' | 'high' | 'extreme';
  setSecurityLevel: (level: 'standard' | 'high' | 'extreme') => void;
  isMobile: boolean;
};

export const Settings: React.FC<SettingsProps> = ({ 
  securityLevel, 
  setSecurityLevel,
  isMobile
}) => {
  const [localSecurityLevel, setLocalSecurityLevel] = useState<'standard' | 'high' | 'extreme'>(securityLevel);
  const [encryptionType, setEncryptionType] = useState<'aes-256' | 'aes-512'>('aes-256');
  const [autoLockTimeout, setAutoLockTimeout] = useState<number>(15);
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [fontSize, setFontSize] = useState<number>(14);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle');
  const [activeTab, setActiveTab] = useState<'general' | 'security' | 'appearance' | 'twoFactor'>('general');
  const [isTwoFactorEnabled, setIsTwoFactorEnabled] = useState<boolean>(false);
  const [showTwoFactorSetup, setShowTwoFactorSetup] = useState<boolean>(false);
  const [recoveryKeys, setRecoveryKeys] = useState<string[]>([]);
  const [showRecoveryKeys, setShowRecoveryKeys] = useState<boolean>(false);
  
  const handleSave = () => {
    setSaveStatus('saving');
    
    // Log the action
    addLogEntry(LogLevel.INFO, 'Settings update initiated', {
      securityLevel: localSecurityLevel,
      encryptionType,
      autoLockTimeout,
      theme
    });
    
    // Simulate API call
    setTimeout(() => {
      setSecurityLevel(localSecurityLevel);
      setSaveStatus('saved');
      
      addLogEntry(LogLevel.SUCCESS, 'Settings updated successfully', {
        securityLevel: localSecurityLevel
      });
      
      // Reset status after some time
      setTimeout(() => {
        setSaveStatus('idle');
      }, 3000);
    }, 1000);
  };
  
  const handleTwoFactorSetup = () => {
    setShowTwoFactorSetup(true);
  };
  
  const handleTwoFactorComplete = (enabled: boolean) => {
    setIsTwoFactorEnabled(enabled);
    setShowTwoFactorSetup(false);
    
    // If enabled, generate recovery keys
    if (enabled && recoveryKeys.length === 0) {
      generateRecoveryKeys();
    }
    
    addLogEntry(LogLevel.INFO, 'Two-factor authentication status changed', {
      enabled
    });
  };
  
  const generateRecoveryKeys = () => {
    // Generate 8 random recovery keys
    const keys = Array(8).fill(0).map(() => 
      Math.random().toString(36).substring(2, 6).toUpperCase() + '-' +
      Math.random().toString(36).substring(2, 6).toUpperCase() + '-' +
      Math.random().toString(36).substring(2, 6).toUpperCase()
    );
    
    setRecoveryKeys(keys);
    setShowRecoveryKeys(true);
    
    addLogEntry(LogLevel.INFO, 'Recovery keys generated', {
      count: keys.length
    });
  };
  
  const handleDismissRecoveryKeys = () => {
    if (!window.confirm("Avez-vous enregistré vos clés de récupération ? Vous ne pourrez plus les voir après cette étape.")) {
      return;
    }
    
    setShowRecoveryKeys(false);
    addLogEntry(LogLevel.INFO, 'Recovery keys dismissed');
  };
  
  const copyRecoveryKeys = () => {
    const keysText = recoveryKeys.join('\n');
    navigator.clipboard.writeText(keysText).then(() => {
      alert('Clés de récupération copiées dans le presse-papiers');
    }).catch(err => {
      console.error('Erreur lors de la copie :', err);
    });
  };
  
  // If showing two factor setup, render that instead
  if (showTwoFactorSetup) {
    return (
      <div className="flex-1 overflow-y-auto p-4 bg-gray-900 flex items-center justify-center">
        <TwoFactorSetup 
          userId="user-123" // In a real app, this would be the actual user ID
          onComplete={handleTwoFactorComplete}
          securityLevel={securityLevel}
        />
      </div>
    );
  }
  
  // If showing recovery keys, render them
  if (showRecoveryKeys) {
    return (
      <div className="flex-1 overflow-y-auto p-4 bg-gray-900 flex items-center justify-center">
        <div className="bg-gray-800 rounded-lg p-6 border border-violet-900/50 max-w-md">
          <div className="flex items-center justify-center mb-6">
            <Key size={40} className="text-violet-500" />
          </div>
          
          <h3 className="text-xl font-semibold mb-2 text-center text-violet-100">
            Clés de récupération
          </h3>
          
          <p className="text-gray-400 mb-6 text-center">
            Conservez ces clés dans un endroit sûr. Elles vous permettront de récupérer votre compte si vous perdez l'accès à votre appareil d'authentification.
          </p>
          
          <div className="bg-gray-900 p-4 rounded-md mb-6">
            <div className="flex justify-between items-center mb-2">
              <h4 className="text-sm font-medium text-violet-300">Vos clés de récupération</h4>
              <button 
                onClick={copyRecoveryKeys}
                className="text-violet-400 hover:text-violet-300 p-1"
              >
                <Copy size={16} />
              </button>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {recoveryKeys.map((key, index) => (
                <div key={index} className="font-mono text-sm bg-gray-800 p-2 rounded border border-gray-700">
                  {key}
                </div>
              ))}
            </div>
          </div>
          
          <div className="bg-yellow-900/20 border border-yellow-800 p-3 rounded-md mb-6">
            <div className="flex items-start">
              <AlertTriangle size={18} className="text-yellow-500 mr-2 mt-0.5" />
              <p className="text-sm text-yellow-100">
                <strong>IMPORTANT:</strong> Ces clés ne seront affichées qu'une seule fois. Assurez-vous de les sauvegarder de manière sécurisée.
              </p>
            </div>
          </div>
          
          <button
            onClick={handleDismissRecoveryKeys}
            className="w-full py-2 bg-violet-600 hover:bg-violet-700 text-white rounded-md"
          >
            J'ai sauvegardé mes clés de récupération
          </button>
        </div>
      </div>
    );
  }
  
  return (
    <div className="flex-1 overflow-y-auto p-4 bg-gray-900">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-2xl font-bold mb-6 text-violet-100">Paramètres</h2>
        
        <div className="flex mb-6 border-b border-gray-700">
          <button
            onClick={() => setActiveTab('general')}
            className={`px-4 py-2 font-medium ${
              activeTab === 'general' 
                ? 'text-violet-400 border-b-2 border-violet-400' 
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Général
          </button>
          <button
            onClick={() => setActiveTab('security')}
            className={`px-4 py-2 font-medium ${
              activeTab === 'security' 
                ? 'text-violet-400 border-b-2 border-violet-400' 
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Sécurité
          </button>
          <button
            onClick={() => setActiveTab('appearance')}
            className={`px-4 py-2 font-medium ${
              activeTab === 'appearance' 
                ? 'text-violet-400 border-b-2 border-violet-400' 
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Apparence
          </button>
          <button
            onClick={() => setActiveTab('twoFactor')}
            className={`px-4 py-2 font-medium ${
              activeTab === 'twoFactor' 
                ? 'text-violet-400 border-b-2 border-violet-400' 
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Authentification
          </button>
        </div>
        
        {activeTab === 'general' && (
          <div className="space-y-6">
            <div className="bg-gray-800 rounded-lg p-4 border border-violet-900/50">
              <h3 className="text-lg font-semibold mb-4 text-violet-100">
                Paramètres généraux
              </h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Langue
                  </label>
                  <select
                    className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:border-violet-500 focus:ring focus:ring-violet-500 focus:ring-opacity-50"
                    defaultValue="fr"
                  >
                    <option value="fr">Français</option>
                    <option value="en">English</option>
                    <option value="es">Español</option>
                    <option value="de">Deutsch</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Fuseau horaire
                  </label>
                  <select
                    className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:border-violet-500 focus:ring focus:ring-violet-500 focus:ring-opacity-50"
                    defaultValue="Europe/Paris"
                  >
                    <option value="Europe/Paris">Europe/Paris (GMT+1)</option>
                    <option value="America/New_York">America/New_York (GMT-5)</option>
                    <option value="Asia/Tokyo">Asia/Tokyo (GMT+9)</option>
                    <option value="Australia/Sydney">Australia/Sydney (GMT+11)</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Format de date
                  </label>
                  <div className="grid grid-cols-3 gap-3">
                    <button
                      className="px-4 py-3 rounded-md flex items-center justify-between bg-violet-900/80 border border-violet-700 text-white"
                    >
                      <span>DD/MM/YYYY</span>
                      <Check size={16} />
                    </button>
                    <button
                      className="px-4 py-3 rounded-md flex items-center justify-between bg-gray-700 border border-gray-600 text-gray-300 hover:border-violet-700"
                    >
                      <span>MM/DD/YYYY</span>
                    </button>
                    <button
                      className="px-4 py-3 rounded-md flex items-center justify-between bg-gray-700 border border-gray-600 text-gray-300 hover:border-violet-700"
                    >
                      <span>YYYY-MM-DD</span>
                    </button>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium text-gray-300">
                    Notifications
                  </label>
                  <div className="relative inline-block w-12 mr-2 align-middle select-none">
                    <input 
                      type="checkbox" 
                      name="notifications" 
                      id="notifications" 
                      defaultChecked 
                      className="sr-only"
                    />
                    <label 
                      htmlFor="notifications" 
                      className="block overflow-hidden h-6 rounded-full bg-gray-600 cursor-pointer"
                    >
                      <span className="dot absolute left-0.5 top-0.5 bg-white w-5 h-5 rounded-full transition-transform duration-200 transform translate-x-6"></span>
                    </label>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-800 rounded-lg p-4 border border-violet-900/50">
              <h3 className="text-lg font-semibold mb-4 text-violet-100">
                Session
              </h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Délai d'inactivité (minutes)
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="60"
                    value={autoLockTimeout}
                    onChange={(e) => setAutoLockTimeout(parseInt(e.target.value))}
                    className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:border-violet-500 focus:ring focus:ring-violet-500 focus:ring-opacity-50"
                  />
                  <p className="mt-1 text-xs text-gray-400">
                    Le terminal sera verrouillé après cette période d'inactivité
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
        
        {activeTab === 'security' && (
          <div className="space-y-6">
            <div className="bg-gray-800 rounded-lg p-4 border border-violet-900/50">
              <h3 className="text-lg font-semibold mb-4 flex items-center text-violet-100">
                <Shield className="mr-2 text-violet-400" size={20} />
                Sécurité
              </h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Niveau de sécurité
                  </label>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    <button
                      onClick={() => setLocalSecurityLevel('standard')}
                      className={`px-4 py-3 rounded-md flex items-center justify-between ${
                        localSecurityLevel === 'standard' 
                          ? 'bg-red-900/80 border border-red-700 text-white' 
                          : 'bg-gray-700 border border-gray-600 text-gray-300 hover:border-violet-700'
                      }`}
                    >
                      <span>Standard</span>
                      {localSecurityLevel === 'standard' && <Check size={16} />}
                    </button>
                    <button
                      onClick={() => setLocalSecurityLevel('high')}
                      className={`px-4 py-3 rounded-md flex items-center justify-between ${
                        localSecurityLevel === 'high' 
                          ? 'bg-purple-900/80 border border-purple-700 text-white' 
                          : 'bg-gray-700 border border-gray-600 text-gray-300 hover:border-violet-700'
                      }`}
                    >
                      <span>Haute</span>
                      {localSecurityLevel === 'high' && <Check size={16} />}
                    </button>
                    <button
                      onClick={() => setLocalSecurityLevel('extreme')}
                      className={`px-4 py-3 rounded-md flex items-center justify-between ${
                        localSecurityLevel === 'extreme' 
                          ? 'bg-violet-900/80 border border-violet-700 text-white' 
                          : 'bg-gray-700 border border-gray-600 text-gray-300 hover:border-violet-700'
                      }`}
                    >
                      <span>Extrême</span>
                      {localSecurityLevel === 'extreme' && <Check size={16} />}
                    </button>
                  </div>
                  {localSecurityLevel === 'extreme' && (
                    <p className="mt-2 text-sm text-violet-400 flex items-start">
                      <AlertTriangle size={16} className="mr-1 mt-0.5" />
                      Le niveau extrême peut réduire les performances sur certains appareils.
                    </p>
                  )}
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Type de chiffrement
                  </label>
                  <select
                    value={encryptionType}
                    onChange={(e) => setEncryptionType(e.target.value as 'aes-256' | 'aes-512')}
                    className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:border-violet-500 focus:ring focus:ring-violet-500 focus:ring-opacity-50"
                  >
                    <option value="aes-256">AES-256-GCM avec PBKDF2</option>
                    <option value="aes-512">AES-512-GCM avec PBKDF2 (Extrême)</option>
                  </select>
                  <p className="mt-1 text-xs text-gray-400">
                    AES-256-GCM offre une sécurité de niveau militaire. AES-512 offre une sécurité encore plus élevée mais peut être plus lent.
                  </p>
                </div>
                
                <div>
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-medium text-gray-300">
                      Protection contre le débogage
                    </label>
                    <div className="relative inline-block w-12 mr-2 align-middle select-none">
                      <input 
                        type="checkbox" 
                        name="debug-protection" 
                        id="debug-protection" 
                        defaultChecked 
                        className="sr-only"
                      />
                      <label 
                        htmlFor="debug-protection" 
                        className="block overflow-hidden h-6 rounded-full bg-gray-600 cursor-pointer"
                      >
                        <span className="dot absolute left-0.5 top-0.5 bg-white w-5 h-5 rounded-full transition-transform duration-200 transform translate-x-6"></span>
                      </label>
                    </div>
                  </div>
                  <p className="mt-1 text-xs text-gray-400">
                    Détecte et bloque les tentatives de débogage et d'analyse
                  </p>
                </div>
                
                <div>
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-medium text-gray-300">
                      Protection contre l'altération du code
                    </label>
                    <div className="relative inline-block w-12 mr-2 align-middle select-none">
                      <input 
                        type="checkbox" 
                        name="tamper-protection" 
                        id="tamper-protection" 
                        defaultChecked 
                        className="sr-only"
                      />
                      <label 
                        htmlFor="tamper-protection" 
                        className="block overflow-hidden h-6 rounded-full bg-gray-600 cursor-pointer"
                      >
                        <span className="dot absolute left-0.5 top-0.5 bg-white w-5 h-5 rounded-full transition-transform duration-200 transform translate-x-6"></span>
                      </label>
                    </div>
                  </div>
                  <p className="mt-1 text-xs text-gray-400">
                    Détecte les modifications non autorisées du code source
                  </p>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-800 rounded-lg p-4 border border-violet-900/50">
              <h3 className="text-lg font-semibold mb-4 flex items-center text-violet-100">
                <Lock className="mr-2 text-violet-400" size={20} />
                Journal de sécurité
              </h3>
              
              <div className="bg-gray-700 border border-gray-600 rounded-md p-3 h-48 overflow-y-auto font-mono text-xs space-y-1">
                <div className="text-green-400">[2025-05-15 12:34:56] Connexion réussie depuis 192.168.1.2</div>
                <div className="text-gray-400">[2025-05-15 13:15:22] Modification du niveau de sécurité: high → extreme</div>
                <div className="text-gray-400">[2025-05-15 13:42:18] Génération de nouvelle clé API</div>
                <div className="text-yellow-400">[2025-05-15 14:15:23] Tentative de connexion échouée depuis 192.168.1.45</div>
                <div className="text-gray-400">[2025-05-15 14:28:56] API Gateway démarré</div>
                <div className="text-red-400">[2025-05-15 15:03:22] 3 tentatives de connexion échouées, compte verrouillé temporairement</div>
                <div className="text-gray-400">[2025-05-15 15:30:15] Compte déverrouillé automatiquement</div>
                <div className="text-gray-400">[2025-05-15 16:05:43] Déconnexion</div>
              </div>
            </div>
          </div>
        )}
        
        {activeTab === 'appearance' && (
          <div className="space-y-6">
            <div className="bg-gray-800 rounded-lg p-4 border border-violet-900/50">
              <h3 className="text-lg font-semibold mb-4 flex items-center text-violet-100">
                <Monitor className="mr-2 text-violet-400" size={20} />
                Apparence
              </h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Thème
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      onClick={() => setTheme('dark')}
                      className={`px-4 py-3 rounded-md flex items-center justify-between ${
                        theme === 'dark' 
                          ? 'bg-violet-900/50 border border-violet-700 text-white' 
                          : 'bg-gray-700 border border-gray-600 text-gray-300 hover:border-violet-700'
                      }`}
                    >
                      <span>Sombre</span>
                      {theme === 'dark' && <Check size={16} />}
                    </button>
                    <button
                      onClick={() => setTheme('light')}
                      className={`px-4 py-3 rounded-md flex items-center justify-between ${
                        theme === 'light' 
                          ? 'bg-violet-900/50 border border-violet-700 text-white' 
                          : 'bg-gray-700 border border-gray-600 text-gray-300 hover:border-violet-700'
                      }`}
                    >
                      <span>Clair</span>
                      {theme === 'light' && <Check size={16} />}
                    </button>
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Taille de police ({fontSize}px)
                  </label>
                  <input
                    type="range"
                    min="10"
                    max="20"
                    value={fontSize}
                    onChange={(e) => setFontSize(parseInt(e.target.value))}
                    className="w-full accent-violet-600"
                  />
                  <div className="flex justify-between text-xs text-gray-500 mt-1">
                    <span>10px</span>
                    <span>20px</span>
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Couleur d'accentuation
                  </label>
                  <div className="grid grid-cols-5 gap-2">
                    <button className="w-full h-8 bg-violet-500 rounded-md border-2 border-violet-300"></button>
                    <button className="w-full h-8 bg-blue-500 rounded-md"></button>
                    <button className="w-full h-8 bg-green-500 rounded-md"></button>
                    <button className="w-full h-8 bg-red-500 rounded-md"></button>
                    <button className="w-full h-8 bg-yellow-500 rounded-md"></button>
                  </div>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Animation des transitions
                  </label>
                  <div className="flex items-center">
                    <input 
                      type="checkbox" 
                      id="animations" 
                      defaultChecked
                      className="mr-2 accent-violet-600"
                    />
                    <label htmlFor="animations" className="text-white">Activer les animations</label>
                  </div>
                  <p className="mt-1 text-xs text-gray-400">
                    Désactiver les animations peut améliorer les performances sur les appareils moins puissants
                  </p>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-800 rounded-lg p-4 border border-violet-900/50">
              <h3 className="text-lg font-semibold mb-4 flex items-center text-violet-100">
                <Smartphone className="mr-2 text-violet-400" size={20} />
                Paramètres mobiles
              </h3>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium text-gray-300">
                    Activer le clavier virtuel
                  </label>
                  <div className="relative inline-block w-12 mr-2 align-middle select-none">
                    <input 
                      type="checkbox" 
                      name="toggle" 
                      id="toggle" 
                      defaultChecked 
                      className="sr-only"
                    />
                    <label 
                      htmlFor="toggle" 
                      className="block overflow-hidden h-6 rounded-full bg-gray-600 cursor-pointer"
                    >
                      <span className="dot absolute left-0.5 top-0.5 bg-white w-5 h-5 rounded-full transition-transform duration-200 transform translate-x-0 checked:translate-x-6 flex items-center justify-center">
                        <span className={`absolute inset-0 rounded-full ${true ? 'bg-violet-600' : 'bg-white'}`}></span>
                      </span>
                    </label>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium text-gray-300">
                    Activer le mode hors ligne
                  </label>
                  <div className="relative inline-block w-12 mr-2 align-middle select-none">
                    <input 
                      type="checkbox" 
                      name="offline" 
                      id="offline" 
                      className="sr-only"
                    />
                    <label 
                      htmlFor="offline" 
                      className="block overflow-hidden h-6 rounded-full bg-gray-600 cursor-pointer"
                    >
                      <span className="dot absolute left-0.5 top-0.5 bg-white w-5 h-5 rounded-full transition-transform duration-200 transform translate-x-0"></span>
                    </label>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium text-gray-300">
                    Mode économie de données
                  </label>
                  <div className="relative inline-block w-12 mr-2 align-middle select-none">
                    <input 
                      type="checkbox" 
                      name="data" 
                      id="data" 
                      className="sr-only"
                    />
                    <label 
                      htmlFor="data" 
                      className="block overflow-hidden h-6 rounded-full bg-gray-600 cursor-pointer"
                    >
                      <span className="dot absolute left-0.5 top-0.5 bg-white w-5 h-5 rounded-full transition-transform duration-200 transform translate-x-0"></span>
                    </label>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
        
        {activeTab === 'twoFactor' && (
          <div className="space-y-6">
            <div className="bg-gray-800 rounded-lg p-4 border border-violet-900/50">
              <h3 className="text-lg font-semibold mb-4 flex items-center text-violet-100">
                <SmartphoneIcon className="mr-2 text-violet-400" size={20} />
                Authentification à deux facteurs (2FA)
              </h3>
              
              <div className="space-y-4">
                <p className="text-gray-300">
                  L'authentification à deux facteurs ajoute une couche de sécurité supplémentaire à votre compte en exigeant un code temporaire en plus de votre mot de passe.
                </p>
                
                <div className="bg-gray-700 p-4 rounded-md">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="font-medium text-white">{isTwoFactorEnabled ? 'Activée' : 'Désactivée'}</h4>
                      <p className="text-sm text-gray-400 mt-1">
                        {isTwoFactorEnabled 
                          ? 'Votre compte est protégé par l\'authentification à deux facteurs.' 
                          : 'Votre compte n\'est pas protégé par l\'authentification à deux facteurs.'}
                      </p>
                    </div>
                    <div>
                      {isTwoFactorEnabled ? (
                        <div className="bg-green-900/30 p-2 rounded-full">
                          <Check size={20} className="text-green-400" />
                        </div>
                      ) : (
                        <button
                          onClick={handleTwoFactorSetup}
                          className="px-3 py-2 bg-violet-600 hover:bg-violet-700 text-white rounded-md"
                        >
                          Activer
                        </button>
                      )}
                    </div>
                  </div>
                </div>
                
                {isTwoFactorEnabled && (
                  <div className="bg-gray-700 p-4 rounded-md">
                    <h4 className="font-medium text-white mb-3">Options</h4>
                    <div className="space-y-3">
                      <button
                        onClick={handleTwoFactorSetup}
                        className="w-full text-left px-3 py-2 bg-gray-600 hover:bg-gray-500 text-white rounded-md flex items-center justify-between"
                      >
                        <span>Reconfigurer l'authentification à deux facteurs</span>
                        <SmartphoneIcon size={16} />
                      </button>
                      
                      <button
                        onClick={generateRecoveryKeys}
                        className="w-full text-left px-3 py-2 bg-gray-600 hover:bg-gray-500 text-white rounded-md flex items-center justify-between"
                      >
                        <span>Générer de nouvelles clés de récupération</span>
                        <Key size={16} />
                      </button>
                      
                      <button
                        className="w-full text-left px-3 py-2 bg-red-900/30 hover:bg-red-900/50 text-red-300 rounded-md"
                      >
                        Désactiver l'authentification à deux facteurs
                      </button>
                    </div>
                  </div>
                )}
                
                <div className="bg-blue-900/20 border border-blue-800 p-3 rounded-md">
                  <p className="text-sm text-blue-300">
                    <strong>Conseil:</strong> Utilisez une application d'authentification comme Google Authenticator, Authy ou Microsoft Authenticator pour générer vos codes 2FA.
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
        
        {(activeTab === 'general' || activeTab === 'security' || activeTab === 'appearance') && (
          <div className="flex justify-end">
            <button
              onClick={handleSave}
              disabled={saveStatus === 'saving'}
              className={`flex items-center px-4 py-2 rounded-md font-medium ${
                saveStatus === 'saved'
                  ? 'bg-green-600 text-white'
                  : saveStatus === 'saving'
                  ? 'bg-gray-600 text-gray-300 cursor-not-allowed'
                  : 'bg-violet-600 text-white hover:bg-violet-700'
              }`}
            >
              {saveStatus === 'saving' ? (
                <>
                  <div className="mr-2 w-4 h-4 border-2 border-gray-300 border-t-white rounded-full animate-spin"></div>
                  Enregistrement...
                </>
              ) : saveStatus === 'saved' ? (
                <>
                  <Check size={16} className="mr-2" />
                  Enregistré
                </>
              ) : (
                <>
                  <Save size={16} className="mr-2" />
                  Enregistrer
                </>
              )}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};