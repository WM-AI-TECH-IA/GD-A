import React from 'react';
import { Terminal, Cloud, Settings, Shield, Download, Server, GitBranch, Database, Package, Code, Archive, Key, RefreshCw, Activity } from 'lucide-react';

type SidebarProps = {
  activeTab: 'terminal' | 'cloud' | 'settings' | 'api' | 'repository' | 'gateway' | 'updates' | 'backup' | 'monitoring';
  setActiveTab: (tab: 'terminal' | 'cloud' | 'settings' | 'api' | 'repository' | 'gateway' | 'updates' | 'backup' | 'monitoring') => void;
  securityLevel: 'standard' | 'high' | 'extreme';
  connectionStatus: 'disconnected' | 'connecting' | 'connected';
};

export const Sidebar: React.FC<SidebarProps> = ({ 
  activeTab, 
  setActiveTab,
  securityLevel,
  connectionStatus
}) => {
  return (
    <div className="w-64 bg-gray-800 border-r border-violet-900 flex flex-col">
      <div className="p-4 border-b border-violet-900">
        <div className="flex items-center mb-4">
          <Terminal size={20} className="text-violet-400 mr-2" />
          <h2 className="text-lg font-semibold text-violet-100">WM Terminal</h2>
        </div>
        
        <div className="text-sm text-gray-400">
          <p>WM AI TECHNOLOGIES INC.</p>
          <p>v1.0.0 (2025)</p>
        </div>
      </div>
      
      <nav className="flex-1 p-2 overflow-y-auto">
        <div className="mb-4">
          <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2 px-2">Navigation</h3>
          <ul>
            <li>
              <button
                onClick={() => setActiveTab('terminal')}
                className={`w-full flex items-center px-2 py-2 rounded-md text-sm ${
                  activeTab === 'terminal' 
                    ? 'bg-violet-900/50 text-violet-100' 
                    : 'text-gray-400 hover:bg-violet-900/30 hover:text-violet-100'
                }`}
              >
                <Terminal size={18} className="mr-2" />
                Terminal
              </button>
            </li>
            <li>
              <button
                onClick={() => setActiveTab('cloud')}
                className={`w-full flex items-center px-2 py-2 rounded-md text-sm ${
                  activeTab === 'cloud' 
                    ? 'bg-violet-900/50 text-violet-100' 
                    : 'text-gray-400 hover:bg-violet-900/30 hover:text-violet-100'
                }`}
              >
                <Cloud size={18} className="mr-2" />
                Cloud
                <span className={`ml-auto inline-block w-2 h-2 rounded-full ${
                  connectionStatus === 'connected' ? 'bg-violet-500' :
                  connectionStatus === 'connecting' ? 'bg-purple-500' :
                  'bg-gray-500'
                }`}></span>
              </button>
            </li>
            <li>
              <button
                onClick={() => setActiveTab('api')}
                className={`w-full flex items-center px-2 py-2 rounded-md text-sm ${
                  activeTab === 'api' 
                    ? 'bg-violet-900/50 text-violet-100' 
                    : 'text-gray-400 hover:bg-violet-900/30 hover:text-violet-100'
                }`}
              >
                <Code size={18} className="mr-2" />
                API Manager
              </button>
            </li>
            <li>
              <button
                onClick={() => setActiveTab('repository')}
                className={`w-full flex items-center px-2 py-2 rounded-md text-sm ${
                  activeTab === 'repository' 
                    ? 'bg-violet-900/50 text-violet-100' 
                    : 'text-gray-400 hover:bg-violet-900/30 hover:text-violet-100'
                }`}
              >
                <Archive size={18} className="mr-2" />
                Dépôt de Projets
              </button>
            </li>
            <li>
              <button
                onClick={() => setActiveTab('gateway')}
                className={`w-full flex items-center px-2 py-2 rounded-md text-sm ${
                  activeTab === 'gateway' 
                    ? 'bg-violet-900/50 text-violet-100' 
                    : 'text-gray-400 hover:bg-violet-900/30 hover:text-violet-100'
                }`}
              >
                <Key size={18} className="mr-2" />
                API Gateway
              </button>
            </li>
            <li>
              <button
                onClick={() => setActiveTab('updates')}
                className={`w-full flex items-center px-2 py-2 rounded-md text-sm ${
                  activeTab === 'updates' 
                    ? 'bg-violet-900/50 text-violet-100' 
                    : 'text-gray-400 hover:bg-violet-900/30 hover:text-violet-100'
                }`}
              >
                <RefreshCw size={18} className="mr-2" />
                Mises à jour
              </button>
            </li>
            <li>
              <button
                onClick={() => setActiveTab('backup')}
                className={`w-full flex items-center px-2 py-2 rounded-md text-sm ${
                  activeTab === 'backup' 
                    ? 'bg-violet-900/50 text-violet-100' 
                    : 'text-gray-400 hover:bg-violet-900/30 hover:text-violet-100'
                }`}
              >
                <Database size={18} className="mr-2" />
                Sauvegardes
              </button>
            </li>
            <li>
              <button
                onClick={() => setActiveTab('monitoring')}
                className={`w-full flex items-center px-2 py-2 rounded-md text-sm ${
                  activeTab === 'monitoring' 
                    ? 'bg-violet-900/50 text-violet-100' 
                    : 'text-gray-400 hover:bg-violet-900/30 hover:text-violet-100'
                }`}
              >
                <Activity size={18} className="mr-2" />
                Monitoring
              </button>
            </li>
            <li>
              <button
                onClick={() => setActiveTab('settings')}
                className={`w-full flex items-center px-2 py-2 rounded-md text-sm ${
                  activeTab === 'settings' 
                    ? 'bg-violet-900/50 text-violet-100' 
                    : 'text-gray-400 hover:bg-violet-900/30 hover:text-violet-100'
                }`}
              >
                <Settings size={18} className="mr-2" />
                Paramètres
              </button>
            </li>
          </ul>
        </div>
        
        <div className="mb-4">
          <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2 px-2">Services</h3>
          <ul>
            <li>
              <button className="w-full flex items-center px-2 py-2 rounded-md text-sm text-gray-400 hover:bg-violet-900/30 hover:text-violet-100">
                <Server size={18} className="mr-2" />
                Serveurs
              </button>
            </li>
            <li>
              <button className="w-full flex items-center px-2 py-2 rounded-md text-sm text-gray-400 hover:bg-violet-900/30 hover:text-violet-100">
                <Database size={18} className="mr-2" />
                Bases de données
              </button>
            </li>
            <li>
              <button className="w-full flex items-center px-2 py-2 rounded-md text-sm text-gray-400 hover:bg-violet-900/30 hover:text-violet-100">
                <GitBranch size={18} className="mr-2" />
                Repositories
              </button>
            </li>
            <li>
              <button className="w-full flex items-center px-2 py-2 rounded-md text-sm text-gray-400 hover:bg-violet-900/30 hover:text-violet-100">
                <Package size={18} className="mr-2" />
                Packages
              </button>
            </li>
          </ul>
        </div>
      </nav>
      
      <div className="p-4 border-t border-violet-900">
        <div className="flex items-center">
          <Shield size={18} className={`mr-2 ${
            securityLevel === 'extreme' ? 'text-violet-400' :
            securityLevel === 'high' ? 'text-purple-400' :
            'text-red-400'
          }`} />
          <div className="text-sm">
            <span className="text-gray-400">Sécurité: </span>
            <span className={
              securityLevel === 'extreme' ? 'text-violet-400' :
              securityLevel === 'high' ? 'text-purple-400' :
              'text-red-400'
            }>
              {securityLevel === 'extreme' ? 'Extrême' :
               securityLevel === 'high' ? 'Haute' :
               'Standard'}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};