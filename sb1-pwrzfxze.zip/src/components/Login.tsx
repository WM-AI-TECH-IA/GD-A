import React, { useState, useEffect } from 'react';
import { Lock, Eye, EyeOff, Shield, AlertTriangle, Mail, User, CheckCircle } from 'lucide-react';
import { signInWithEmail, signUpWithEmail, getCurrentUser } from '../utils/supabaseClient';

type LoginProps = {
  onAuthenticated: () => void;
  securityLevel: 'standard' | 'high' | 'extreme';
};

export const Login: React.FC<LoginProps> = ({ onAuthenticated, securityLevel }) => {
  const [email, setEmail] = useState<string>('');
  const [password, setPassword] = useState<string>('');
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isRegistering, setIsRegistering] = useState<boolean>(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [attempts, setAttempts] = useState<number>(0);
  const [isLocked, setIsLocked] = useState<boolean>(false);
  const [lockTime, setLockTime] = useState<number>(0);
  const [supabaseConfigError, setSupabaseConfigError] = useState<boolean>(false);

  // Anti-debugging technique (simplifié pour la demo)
  useEffect(() => {
    if (process.env.NODE_ENV === 'production') {
      const debugProtection = () => {
        const startTime = new Date().getTime();
        debugger;
        const endTime = new Date().getTime();
        if (endTime - startTime > 100) {
          console.clear();
          window.location.reload();
        }
      };
      
      const interval = setInterval(debugProtection, 1000);
      return () => clearInterval(interval);
    }
  }, []);

  // Check Supabase configuration
  useEffect(() => {
    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
    const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
    
    if (!supabaseUrl || !supabaseAnonKey || 
        supabaseUrl === 'https://your-project-id.supabase.co' || 
        supabaseAnonKey === 'your-anon-key-here') {
      setSupabaseConfigError(true);
      setErrorMessage("Erreur de configuration Supabase. Veuillez configurer correctement les variables d'environnement VITE_SUPABASE_URL et VITE_SUPABASE_ANON_KEY.");
    }
  }, []);

  // Vérifier si l'utilisateur est déjà connecté
  useEffect(() => {
    const checkUser = async () => {
      try {
        // Only proceed if Supabase is configured properly
        if (supabaseConfigError) return;
        
        const user = await getCurrentUser();
        // Only call onAuthenticated if a user was found
        if (user) {
          onAuthenticated();
        }
      } catch (error) {
        // Handle the error gracefully - this is expected if no session exists
        console.error("Error checking current user:", error);
      }
    };
    
    if (!supabaseConfigError) {
      checkUser();
    }
  }, [onAuthenticated, supabaseConfigError]);

  // Timer pour le verrouillage
  useEffect(() => {
    if (isLocked && lockTime > 0) {
      const timer = setTimeout(() => {
        setLockTime(lockTime - 1);
      }, 1000);
      
      return () => clearTimeout(timer);
    } else if (isLocked && lockTime === 0) {
      setIsLocked(false);
    }
  }, [isLocked, lockTime]);

  const handleLogin = async () => {
    if (isLocked || supabaseConfigError) return;
    
    if (!email || !password) {
      setErrorMessage("Veuillez remplir tous les champs");
      return;
    }
    
    const maxRetries = 3; // Nombre maximum de tentatives
    let retryCount = 0;
    
    setIsLoading(true);
    setErrorMessage(null);
    
    while (retryCount < maxRetries) {
      try {
        const { data, error } = await signInWithEmail(email, password);
        
        if (error) {
          // Vérifier si c'est une erreur réseau (comme "Failed to fetch")
          if (error.message && (error.message.includes("Failed to fetch") || 
              error.message.includes("Network Error") || 
              error.message.includes("network") || 
              error.message.includes("connection"))) {
            retryCount++;
            console.log(`Tentative de reconnexion ${retryCount}/${maxRetries}...`);
            
            // Attendre avant la prochaine tentative (délai croissant)
            await new Promise(resolve => setTimeout(resolve, retryCount * 1000));
            continue; // Continuer la boucle pour réessayer
          } else {
            throw error; // Lancer les erreurs non liées au réseau immédiatement
          }
        }
        
        if (data.user) {
          setSuccessMessage("Connexion réussie!");
          setTimeout(() => {
            onAuthenticated();
          }, 1000);
          break; // Sortir de la boucle en cas de succès
        }
      } catch (error: any) {
        const newAttempts = attempts + 1;
        setAttempts(newAttempts);
        
        // Check for specific error types
        let errorMsg = "Identifiants invalides";
        
        if (error.message) {
          if (error.message.includes("Failed to fetch")) {
            errorMsg = "Erreur de connexion au serveur Supabase. Vérifiez votre connexion internet ou votre configuration Supabase.";
          } else if (error.message.includes("Invalid login credentials")) {
            errorMsg = "Identifiants invalides. Vérifiez votre email et votre mot de passe.";
          } else {
            errorMsg = error.message;
          }
        }
        
        // Mécanisme de verrouillage
        if (newAttempts >= 3) {
          const lockoutTime = Math.min(Math.pow(2, newAttempts - 2) * 10, 300); // Backoff exponentiel, max 5 minutes
          setIsLocked(true);
          setLockTime(lockoutTime);
          setErrorMessage(`Trop de tentatives. Verrouillé pour ${lockoutTime} secondes.`);
        } else {
          setErrorMessage(`Erreur: ${errorMsg}. ${3 - newAttempts} tentatives restantes.`);
        }
        break; // Sortir de la boucle en cas d'erreur non liée au réseau
      } finally {
        if (retryCount === maxRetries) {
          setErrorMessage(`Impossible de se connecter après ${maxRetries} tentatives. Veuillez vérifier votre connexion Internet.`);
        }
      }
    }
    
    setIsLoading(false);
  };

  const handleRegister = async () => {
    if (supabaseConfigError) return;
    
    if (!email || !password) {
      setErrorMessage("Veuillez remplir tous les champs");
      return;
    }
    
    if (password.length < 6) {
      setErrorMessage("Le mot de passe doit contenir au moins 6 caractères");
      return;
    }
    
    try {
      setIsLoading(true);
      setErrorMessage(null);
      
      const { data, error } = await signUpWithEmail(email, password);
      
      if (error) {
        throw error;
      }
      
      setSuccessMessage("Inscription réussie! Vous pouvez maintenant vous connecter.");
      setIsRegistering(false);
    } catch (error: any) {
      let errorMsg = "Échec de l'inscription";
      
      if (error.message) {
        if (error.message.includes("Failed to fetch")) {
          errorMsg = "Erreur de connexion au serveur Supabase. Vérifiez votre connexion internet ou votre configuration Supabase.";
        } else if (error.message.includes("User already registered")) {
          errorMsg = "Cet email est déjà enregistré. Veuillez vous connecter ou utiliser un autre email.";
        } else {
          errorMsg = error.message;
        }
      }
      
      setErrorMessage(`Erreur: ${errorMsg}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isRegistering) {
      handleRegister();
    } else {
      handleLogin();
    }
  };

  return (
    <div className="flex-1 overflow-hidden flex items-center justify-center bg-gray-900 p-6">
      <div className="bg-gray-800 rounded-lg p-8 w-full max-w-md border border-violet-900/50 shadow-lg shadow-violet-900/20">
        <div className="flex items-center justify-center mb-6">
          <Shield size={40} className={`
            ${securityLevel === 'extreme' ? 'text-violet-500' : 
              securityLevel === 'high' ? 'text-purple-500' : 
              'text-red-500'}
          `} />
        </div>
        
        <h2 className="text-2xl font-bold text-center text-white mb-2">
          {isRegistering ? 'Créer un compte' : 'Authentification Sécurisée'}
        </h2>
        <p className="text-gray-400 text-center mb-6">
          {isRegistering ? 'Inscrivez-vous pour accéder à WM Terminal' : 'Entrez vos identifiants pour continuer'}
        </p>
        
        {supabaseConfigError && (
          <div className="bg-red-900/30 border border-red-800 rounded-md p-3 text-white flex items-center mb-4">
            <AlertTriangle size={18} className="mr-2 text-red-400" />
            <div>
              <p className="font-bold">Configuration Supabase manquante</p>
              <p className="text-sm">Veuillez configurer les variables d'environnement VITE_SUPABASE_URL et VITE_SUPABASE_ANON_KEY dans le fichier .env</p>
            </div>
          </div>
        )}
        
        {successMessage && (
          <div className="bg-green-900/30 border border-green-800 rounded-md p-3 text-white flex items-center mb-4">
            <CheckCircle size={18} className="mr-2 text-green-400" />
            <p>{successMessage}</p>
          </div>
        )}
        
        {errorMessage && !supabaseConfigError && (
          <div className="bg-red-900/30 border border-red-800 rounded-md p-3 text-white flex items-center mb-4">
            <AlertTriangle size={18} className="mr-2 text-red-400" />
            <p>{errorMessage}</p>
          </div>
        )}
        
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2" htmlFor="email">
              Email
            </label>
            <div className="relative">
              <input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 pl-10 pr-3 text-white focus:outline-none focus:ring-2 focus:ring-violet-500 focus:border-transparent"
                placeholder="votre@email.com"
                disabled={isLoading || isLocked || supabaseConfigError}
              />
              <Mail size={18} className="absolute left-3 top-3 text-gray-400" />
            </div>
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-2" htmlFor="password">
              Mot de passe
            </label>
            <div className="relative">
              <input
                id="password"
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 pl-10 pr-10 text-white focus:outline-none focus:ring-2 focus:ring-violet-500 focus:border-transparent"
                placeholder={isRegistering ? "Créez un mot de passe" : "Votre mot de passe"}
                disabled={isLoading || isLocked || supabaseConfigError}
              />
              <Lock size={18} className="absolute left-3 top-3 text-gray-400" />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-3 text-gray-400 hover:text-violet-400"
                disabled={supabaseConfigError}
              >
                {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
              </button>
            </div>
          </div>
          
          <button
            type="submit"
            disabled={isLoading || isLocked || supabaseConfigError}
            className={`w-full py-3 rounded-md flex items-center justify-center text-white font-medium ${
              isLocked || supabaseConfigError
                ? 'bg-gray-700 cursor-not-allowed' 
                : isLoading
                  ? 'bg-violet-700/70 cursor-wait'
                  : 'bg-violet-700 hover:bg-violet-600'
            }`}
          >
            {isLocked ? (
              <>
                <Lock size={18} className="mr-2" />
                Verrouillé ({lockTime}s)
              </>
            ) : isLoading ? (
              <>
                <div className="mr-2 w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                {isRegistering ? 'Inscription...' : 'Connexion...'}
              </>
            ) : (
              <>
                <Lock size={18} className="mr-2" />
                {isRegistering ? 'S\'inscrire' : 'Se connecter'}
              </>
            )}
          </button>
          
          <div className="text-center">
            <button
              type="button"
              onClick={() => {
                setIsRegistering(!isRegistering);
                setErrorMessage(null);
                setSuccessMessage(null);
              }}
              className="text-violet-400 hover:text-violet-300 text-sm"
              disabled={isLoading || isLocked || supabaseConfigError}
            >
              {isRegistering ? 'Déjà un compte? Connectez-vous' : 'Pas de compte? Inscrivez-vous'}
            </button>
          </div>
        </form>
        
        <div className="flex items-center justify-center border-t border-gray-700 pt-4 mt-4">
          <div className={`w-3 h-3 rounded-full mr-2 ${
            securityLevel === 'extreme' ? 'bg-violet-500' : 
            securityLevel === 'high' ? 'bg-purple-500' : 
            'bg-red-500'
          }`}></div>
          <p className="text-sm text-gray-400">
            {securityLevel === 'extreme' ? 'Sécurité Extrême' : 
             securityLevel === 'high' ? 'Haute Sécurité' : 
             'Sécurité Standard'}
          </p>
        </div>
      </div>
    </div>
  );
};