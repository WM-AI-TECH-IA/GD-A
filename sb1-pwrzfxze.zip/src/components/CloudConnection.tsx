import React, { useState } from 'react';
import { Cloud, Server, Database, Check, AlertTriangle, X, RefreshCw, Download, Upload, Eye, EyeOff, Lock, Code, Key, Settings as SettingsIcon } from 'lucide-react';

type CloudConnectionProps = {
  setConnectionStatus: (status: 'disconnected' | 'connecting' | 'connected') => void;
  securityLevel: 'standard' | 'high' | 'extreme';
};

type CloudService = {
  id: string;
  name: string;
  icon: React.ReactNode;
  status: 'connected' | 'disconnected';
  lastSync?: Date;
  apiEnabled?: boolean;
  apiEndpoints?: number;
};

export const CloudConnection: React.FC<CloudConnectionProps> = ({ 
  setConnectionStatus,
  securityLevel
}) => {
  const [activeService, setActiveService] = useState<string | null>(null);
  const [isConnecting, setIsConnecting] = useState<boolean>(false);
  const [connectionError, setConnectionError] = useState<string | null>(null);
  const [apiKey, setApiKey] = useState<string>('');
  const [showApiKey, setShowApiKey] = useState<boolean>(false);
  const [isUploading, setIsUploading] = useState<boolean>(false);
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const [activeTab, setActiveTab] = useState<'overview' | 'api' | 'settings'>('overview');
  
  const [cloudServices, setCloudServices] = useState<CloudService[]>([
    { 
      id: 'aws', 
      name: 'AWS', 
      icon: <Server size={18} className="text-violet-400" />, 
      status: 'disconnected',
      apiEnabled: true,
      apiEndpoints: 12
    },
    { 
      id: 'gcp', 
      name: 'Google Cloud', 
      icon: <Cloud size={18} className="text-violet-400" />, 
      status: 'disconnected',
      apiEnabled: true,
      apiEndpoints: 9
    },
    { 
      id: 'azure', 
      name: 'Microsoft Azure', 
      icon: <Server size={18} className="text-violet-400" />, 
      status: 'disconnected',
      apiEnabled: true,
      apiEndpoints: 7
    },
    { 
      id: 'ibm', 
      name: 'IBM Cloud', 
      icon: <Server size={18} className="text-violet-400" />, 
      status: 'disconnected',
      apiEnabled: false,
      apiEndpoints: 0
    },
    { 
      id: 'firebase', 
      name: 'Firebase', 
      icon: <Database size={18} className="text-violet-400" />, 
      status: 'connected',
      lastSync: new Date(Date.now() - 3600000), // 1 hour ago
      apiEnabled: true,
      apiEndpoints: 4
    }
  ]);
  
  const handleConnect = (serviceId: string) => {
    // Already connected to this service
    const service = cloudServices.find(s => s.id === serviceId);
    if (service?.status === 'connected') {
      setActiveService(serviceId);
      return;
    }
    
    setActiveService(serviceId);
    
    if (apiKey.trim() === '') {
      return;
    }
    
    setIsConnecting(true);
    setConnectionError(null);
    setConnectionStatus('connecting');
    
    // Simulate connection
    setTimeout(() => {
      // Random success/failure (80% success rate)
      const success = Math.random() > 0.2;
      
      if (success) {
        setCloudServices(services => 
          services.map(s => 
            s.id === serviceId 
              ? { ...s, status: 'connected', lastSync: new Date() }
              : s
          )
        );
        setIsConnecting(false);
        setConnectionStatus('connected');
      } else {
        setConnectionError('Échec de la connexion. Veuillez vérifier vos identifiants et réessayer.');
        setIsConnecting(false);
        setConnectionStatus('disconnected');
      }
    }, 2000);
  };
  
  const handleDisconnect = (serviceId: string) => {
    setCloudServices(services => 
      services.map(s => 
        s.id === serviceId 
          ? { ...s, status: 'disconnected' }
          : s
      )
    );
    
    if (activeService === serviceId) {
      setActiveService(null);
    }
    
    // If no services are connected, update the overall status
    if (!cloudServices.some(s => s.id !== serviceId && s.status === 'connected')) {
      setConnectionStatus('disconnected');
    }
  };
  
  const getServiceById = (id: string | null) => {
    if (!id) return null;
    return cloudServices.find(s => s.id === id) || null;
  };
  
  const formatDate = (date?: Date) => {
    if (!date) return 'Jamais';
    return date.toLocaleString();
  };
  
  const simulateUpload = () => {
    if (isUploading) return;
    
    setIsUploading(true);
    setUploadProgress(0);
    
    const interval = setInterval(() => {
      setUploadProgress(prev => {
        const nextProgress = prev + Math.floor(Math.random() * 10);
        if (nextProgress >= 100) {
          clearInterval(interval);
          setTimeout(() => setIsUploading(false), 500);
          return 100;
        }
        return nextProgress;
      });
    }, 300);
  };
  
  // Content for different service tabs
  const renderTabContent = () => {
    if (!activeService) return null;
    
    const service = getServiceById(activeService);
    if (!service) return null;
    
    switch (activeTab) {
      case 'overview':
        return (
          <>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-gray-700 p-3 rounded-md">
                <div className="text-sm text-gray-400 mb-1">Statut</div>
                <div className="flex items-center">
                  {service.status === 'connected' ? (
                    <>
                      <span className="w-2 h-2 rounded-full bg-violet-500 mr-2"></span>
                      <span className="text-violet-400">Connecté</span>
                    </>
                  ) : (
                    <>
                      <span className="w-2 h-2 rounded-full bg-gray-500 mr-2"></span>
                      <span className="text-gray-400">Déconnecté</span>
                    </>
                  )}
                </div>
              </div>
              
              <div className="bg-gray-700 p-3 rounded-md">
                <div className="text-sm text-gray-400 mb-1">Dernière synchronisation</div>
                <div>{formatDate(service.lastSync)}</div>
              </div>
              
              <div className="bg-gray-700 p-3 rounded-md">
                <div className="text-sm text-gray-400 mb-1">Niveau de sécurité</div>
                <div className={
                  securityLevel === 'extreme' ? 'text-violet-400' :
                  securityLevel === 'high' ? 'text-purple-400' :
                  'text-red-400'
                }>
                  {securityLevel === 'extreme' ? 'Extrême' :
                   securityLevel === 'high' ? 'Haute' :
                   'Standard'}
                </div>
              </div>
              
              <div className="bg-gray-700 p-3 rounded-md">
                <div className="text-sm text-gray-400 mb-1">Type de connexion</div>
                <div className="flex items-center">
                  <Lock size={14} className="mr-1 text-violet-400" />
                  <span>Chiffrée {securityLevel === 'extreme' ? '(E2E)' : ''}</span>
                </div>
              </div>
            </div>
            
            {service.status === 'connected' && (
              <>
                <div className="bg-gray-700 rounded-lg p-4 mt-4">
                  <h4 className="text-md font-semibold mb-3 text-violet-100">Actions rapides</h4>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    <button className="p-3 bg-gray-800 hover:bg-violet-900/30 rounded-md flex flex-col items-center justify-center text-sm">
                      <RefreshCw size={18} className="mb-2 text-violet-400" />
                      Synchroniser
                    </button>
                    <button 
                      className="p-3 bg-gray-800 hover:bg-violet-900/30 rounded-md flex flex-col items-center justify-center text-sm"
                      onClick={simulateUpload}
                    >
                      <Upload size={18} className="mb-2 text-violet-400" />
                      Envoyer fichier
                    </button>
                    <button className="p-3 bg-gray-800 hover:bg-violet-900/30 rounded-md flex flex-col items-center justify-center text-sm">
                      <Download size={18} className="mb-2 text-violet-400" />
                      Télécharger fichier
                    </button>
                    <button className="p-3 bg-gray-800 hover:bg-violet-900/30 rounded-md flex flex-col items-center justify-center text-sm">
                      <AlertTriangle size={18} className="mb-2 text-violet-400" />
                      Diagnostics
                    </button>
                  </div>
                  
                  {isUploading && (
                    <div className="mt-4">
                      <div className="flex justify-between text-xs text-gray-400 mb-1">
                        <span>Envoi de "projet.zip" vers {service.name}</span>
                        <span>{uploadProgress}%</span>
                      </div>
                      <div className="w-full bg-gray-800 rounded-full h-1.5">
                        <div 
                          className="bg-violet-600 h-1.5 rounded-full" 
                          style={{width: `${uploadProgress}%`}}
                        ></div>
                      </div>
                    </div>
                  )}
                </div>
                
                <div className="bg-gray-700 rounded-lg p-4 mt-4">
                  <h4 className="text-md font-semibold mb-3 text-violet-100">Fichiers récents</h4>
                  
                  <div className="bg-gray-800 rounded-md overflow-hidden">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="bg-gray-600">
                          <th className="text-left py-2 px-3">Nom</th>
                          <th className="text-left py-2 px-3">Modifié</th>
                          <th className="text-left py-2 px-3">Taille</th>
                          <th className="text-left py-2 px-3">Actions</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr className="border-t border-gray-600">
                          <td className="py-2 px-3">data.json</td>
                          <td className="py-2 px-3">Il y a 3h</td>
                          <td className="py-2 px-3">1.2 MB</td>
                          <td className="py-2 px-3">
                            <button className="text-violet-400 hover:underline">Télécharger</button>
                          </td>
                        </tr>
                        <tr className="border-t border-gray-600">
                          <td className="py-2 px-3">config.yml</td>
                          <td className="py-2 px-3">Il y a 1j</td>
                          <td className="py-2 px-3">4.7 KB</td>
                          <td className="py-2 px-3">
                            <button className="text-violet-400 hover:underline">Télécharger</button>
                          </td>
                        </tr>
                        <tr className="border-t border-gray-600">
                          <td className="py-2 px-3">backup.tar.gz</td>
                          <td className="py-2 px-3">Il y a 3j</td>
                          <td className="py-2 px-3">45.3 MB</td>
                          <td className="py-2 px-3">
                            <button className="text-violet-400 hover:underline">Télécharger</button>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </>
            )}
          </>
        );
        
      case 'api':
        return (
          <div className="space-y-4">
            <div className="bg-gray-700 rounded-lg p-4">
              <div className="flex items-center justify-between mb-4">
                <h4 className="text-md font-semibold text-violet-100 flex items-center">
                  <Code size={18} className="mr-2 text-violet-400" />
                  API {service.name}
                </h4>
                
                {service.apiEnabled && service.status === 'connected' ? (
                  <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-green-900 text-green-300">
                    <Check size={12} className="mr-1" />
                    API Activée
                  </span>
                ) : (
                  <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-gray-700 text-gray-300">
                    API Désactivée
                  </span>
                )}
              </div>
              
              {service.apiEnabled ? (
                <div className="space-y-4">
                  <p className="text-sm text-gray-300">
                    Ce service cloud dispose d'une API complète permettant d'interagir avec vos données et services.
                  </p>
                  
                  {service.status === 'connected' ? (
                    <div className="space-y-3">
                      <div className="p-3 bg-gray-800 rounded-md">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm text-violet-300 font-medium">URL de base de l'API</span>
                          <button className="text-xs text-violet-400 hover:underline">Copier</button>
                        </div>
                        <code className="text-sm text-white font-mono block bg-gray-900 p-2 rounded">
                          https://api.{service.id}.com/v1
                        </code>
                      </div>
                      
                      <div className="p-3 bg-gray-800 rounded-md">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm text-violet-300 font-medium">Clé API</span>
                          <button className="text-xs text-violet-400 hover:underline">Régénérer</button>
                        </div>
                        <div className="flex items-center">
                          <code className="text-sm text-white font-mono block bg-gray-900 p-2 rounded flex-1">
                            {showApiKey ? "sk_live_1a2b3c4d5e6f7g8h9i0j" : "••••••••••••••••••••••"}
                          </code>
                          <button 
                            onClick={() => setShowApiKey(!showApiKey)}
                            className="ml-2 p-2 bg-gray-900 rounded text-gray-400 hover:text-violet-400"
                          >
                            {showApiKey ? <EyeOff size={18} /> : <Eye size={18} />}
                          </button>
                        </div>
                      </div>
                      
                      <div className="p-3 bg-gray-800 rounded-md">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm text-violet-300 font-medium">Points de terminaison disponibles</span>
                          <span className="text-xs bg-violet-900 text-violet-300 px-2 py-0.5 rounded-full">
                            {service.apiEndpoints} Endpoints
                          </span>
                        </div>
                        <div className="space-y-2">
                          <div className="flex items-center justify-between p-2 bg-gray-900 rounded text-sm">
                            <div className="flex items-center">
                              <span className="inline-block w-10 text-green-400">GET</span>
                              <span className="text-gray-300">/files</span>
                            </div>
                            <button className="text-xs text-violet-400 hover:underline">Tester</button>
                          </div>
                          <div className="flex items-center justify-between p-2 bg-gray-900 rounded text-sm">
                            <div className="flex items-center">
                              <span className="inline-block w-10 text-purple-400">POST</span>
                              <span className="text-gray-300">/files/upload</span>
                            </div>
                            <button className="text-xs text-violet-400 hover:underline">Tester</button>
                          </div>
                          <div className="flex items-center justify-between p-2 bg-gray-900 rounded text-sm">
                            <div className="flex items-center">
                              <span className="inline-block w-10 text-blue-400">PUT</span>
                              <span className="text-gray-300">/settings</span>
                            </div>
                            <button className="text-xs text-violet-400 hover:underline">Tester</button>
                          </div>
                          <div className="flex items-center justify-between p-2 bg-gray-900 rounded text-sm">
                            <div className="flex items-center">
                              <span className="inline-block w-10 text-red-400">DEL</span>
                              <span className="text-gray-300">/files/{'{id}'}</span>
                            </div>
                            <button className="text-xs text-violet-400 hover:underline">Tester</button>
                          </div>
                        </div>
                        
                        <div className="mt-3 text-right">
                          <button className="text-sm text-violet-400 hover:underline">
                            Voir toute la documentation →
                          </button>
                        </div>
                      </div>
                      
                      <div className="p-3 bg-gray-800 rounded-md">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm text-violet-300 font-medium">Exemple de requête</span>
                          <button className="text-xs text-violet-400 hover:underline">Copier</button>
                        </div>
                        <pre className="text-sm text-white font-mono bg-gray-900 p-2 rounded overflow-x-auto">
{`curl -X GET "https://api.${service.id}.com/v1/files" \\
  -H "Authorization: Bearer sk_live_1a2b3c4d5e6f7g8h9i0j" \\
  -H "Content-Type: application/json"`}
                        </pre>
                      </div>
                    </div>
                  ) : (
                    <div className="flex flex-col items-center justify-center p-6 bg-gray-800 rounded-md">
                      <Lock size={32} className="text-gray-500 mb-2" />
                      <p className="text-gray-400 text-center max-w-md mb-3">
                        Connectez-vous à {service.name} pour accéder à l'API et voir les points de terminaison disponibles.
                      </p>
                      <button 
                        onClick={() => handleConnect(service.id)}
                        className="px-4 py-2 bg-violet-600 hover:bg-violet-700 text-white rounded-md text-sm"
                        disabled={apiKey.trim() === ''}
                      >
                        Se connecter pour accéder à l'API
                      </button>
                    </div>
                  )}
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center p-6 bg-gray-800 rounded-md">
                  <AlertTriangle size={32} className="text-gray-500 mb-2" />
                  <p className="text-gray-400 text-center max-w-md">
                    Ce service cloud ne dispose pas encore d'une API publique disponible.
                  </p>
                </div>
              )}
            </div>
            
            {service.apiEnabled && service.status === 'connected' && (
              <div className="bg-gray-700 rounded-lg p-4">
                <h4 className="text-md font-semibold mb-3 text-violet-100 flex items-center">
                  <Key size={18} className="mr-2 text-violet-400" />
                  Paramètres API
                </h4>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-gray-800 rounded-md">
                    <div>
                      <span className="block text-sm font-medium text-violet-300">Limites de débit</span>
                      <span className="text-xs text-gray-400">Contrôle le nombre maximal de requêtes par minute</span>
                    </div>
                    <select className="bg-gray-900 border border-gray-700 rounded-md py-1 px-2 text-white text-sm">
                      <option value="60">60 requêtes/min</option>
                      <option value="120">120 requêtes/min</option>
                      <option value="300">300 requêtes/min</option>
                      <option value="unlimited">Illimité</option>
                    </select>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-gray-800 rounded-md">
                    <div>
                      <span className="block text-sm font-medium text-violet-300">Journalisation des requêtes</span>
                      <span className="text-xs text-gray-400">Enregistre toutes les demandes API effectuées</span>
                    </div>
                    <div className="relative inline-block w-12 mr-2 align-middle select-none">
                      <input 
                        type="checkbox" 
                        name="logging" 
                        id="logging" 
                        defaultChecked 
                        className="sr-only"
                      />
                      <label 
                        htmlFor="logging" 
                        className="block overflow-hidden h-6 rounded-full bg-gray-600 cursor-pointer"
                      >
                        <span className="absolute inset-0 rounded-full bg-violet-900/10"></span>
                        <span className="dot absolute left-0.5 top-0.5 bg-white w-5 h-5 rounded-full transition-transform duration-200 transform translate-x-6">
                          <span className="absolute inset-0 rounded-full bg-violet-600"></span>
                        </span>
                      </label>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-gray-800 rounded-md">
                    <div>
                      <span className="block text-sm font-medium text-violet-300">Notifications webhook</span>
                      <span className="text-xs text-gray-400">Recevez des notifications sur les événements API</span>
                    </div>
                    <button className="px-3 py-1 bg-violet-600 hover:bg-violet-700 text-white rounded-md text-sm">
                      Configurer
                    </button>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-gray-800 rounded-md">
                    <div>
                      <span className="block text-sm font-medium text-violet-300">Restreindre l'accès par IP</span>
                      <span className="text-xs text-gray-400">Limiter les requêtes API à certaines adresses IP</span>
                    </div>
                    <button className="px-3 py-1 bg-violet-600 hover:bg-violet-700 text-white rounded-md text-sm">
                      Ajouter des IPs
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        );
        
      case 'settings':
        return (
          <div className="space-y-4">
            <div className="bg-gray-700 rounded-lg p-4">
              <h4 className="text-md font-semibold mb-4 text-violet-100 flex items-center">
                <SettingsIcon size={18} className="mr-2 text-violet-400" />
                Paramètres du service
              </h4>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Nom du service
                  </label>
                  <input
                    type="text"
                    defaultValue={service.name}
                    className="w-full bg-gray-800 border border-gray-600 rounded-md py-2 px-3 text-white focus:border-violet-500 focus:ring focus:ring-violet-500 focus:ring-opacity-50"
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Niveau de chiffrement de connexion
                  </label>
                  <select
                    defaultValue={securityLevel}
                    className="w-full bg-gray-800 border border-gray-600 rounded-md py-2 px-3 text-white focus:border-violet-500 focus:ring focus:ring-violet-500 focus:ring-opacity-50"
                  >
                    <option value="standard">Standard (AES-128)</option>
                    <option value="high">Haute (AES-256)</option>
                    <option value="extreme">Extrême (AES-512 + E2E)</option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Synchronisation automatique
                  </label>
                  <select
                    defaultValue="hourly"
                    className="w-full bg-gray-800 border border-gray-600 rounded-md py-2 px-3 text-white focus:border-violet-500 focus:ring focus:ring-violet-500 focus:ring-opacity-50"
                  >
                    <option value="never">Jamais (manuel uniquement)</option>
                    <option value="hourly">Toutes les heures</option>
                    <option value="daily">Quotidienne</option>
                    <option value="weekly">Hebdomadaire</option>
                  </select>
                </div>
                
                <div className="flex items-center justify-between p-3 bg-gray-800 rounded-md">
                  <div>
                    <span className="block text-sm font-medium text-violet-300">Activer l'API</span>
                    <span className="text-xs text-gray-400">Permettre l'accès programmatique via API</span>
                  </div>
                  <div className="relative inline-block w-12 mr-2 align-middle select-none">
                    <input 
                      type="checkbox" 
                      name="api" 
                      id="api" 
                      defaultChecked={service.apiEnabled}
                      className="sr-only"
                    />
                    <label 
                      htmlFor="api" 
                      className="block overflow-hidden h-6 rounded-full bg-gray-600 cursor-pointer"
                    >
                      <span className="absolute inset-0 rounded-full bg-violet-900/10"></span>
                      <span className={`dot absolute left-0.5 top-0.5 bg-white w-5 h-5 rounded-full transition-transform duration-200 transform ${service.apiEnabled ? 'translate-x-6' : 'translate-x-0'}`}>
                        <span className={`absolute inset-0 rounded-full ${service.apiEnabled ? 'bg-violet-600' : 'bg-gray-400'}`}></span>
                      </span>
                    </label>
                  </div>
                </div>
                
                <div className="flex items-center justify-between p-3 bg-gray-800 rounded-md">
                  <div>
                    <span className="block text-sm font-medium text-red-300">Zone de danger</span>
                    <span className="text-xs text-gray-400">Supprime toutes les données et déconnecte le service</span>
                  </div>
                  <button className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white rounded-md text-sm flex items-center">
                    <X size={14} className="mr-1" />
                    Réinitialiser
                  </button>
                </div>
              </div>
            </div>
          </div>
        );
        
      default:
        return null;
    }
  };
  
  return (
    <div className="flex-1 overflow-hidden flex">
      <div className="w-64 bg-gray-800 border-r border-violet-900 overflow-y-auto">
        <div className="p-4">
          <h3 className="text-lg font-semibold mb-4 text-violet-100">Services Cloud</h3>
          
          <div className="space-y-2">
            {cloudServices.map(service => (
              <button
                key={service.id}
                onClick={() => setActiveService(service.id)}
                className={`w-full flex items-center justify-between p-3 rounded-md ${
                  activeService === service.id 
                    ? 'bg-violet-900/50 text-white' 
                    : 'text-gray-300 hover:bg-violet-900/30 hover:text-white'
                }`}
              >
                <div className="flex items-center">
                  <span className="mr-2">{service.icon}</span>
                  <span>{service.name}</span>
                </div>
                <div className="flex items-center">
                  {service.apiEnabled && (
                    <Code size={14} className="mr-1 text-violet-400" />
                  )}
                  <span className={`w-2 h-2 rounded-full ${
                    service.status === 'connected' ? 'bg-violet-500' : 'bg-gray-500'
                  }`}></span>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 bg-gray-900">
        {activeService ? (
          <div>
            <div className="bg-gray-800 rounded-lg p-4 mb-4 border border-violet-900/50">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center">
                  <span className="mr-2">{getServiceById(activeService)?.icon}</span>
                  <h3 className="text-xl font-semibold text-violet-100">{getServiceById(activeService)?.name}</h3>
                  {getServiceById(activeService)?.apiEnabled && (
                    <span className="ml-2 px-2 py-0.5 bg-violet-900/50 rounded text-xs text-violet-300 flex items-center">
                      <Code size={12} className="mr-1" />
                      API
                    </span>
                  )}
                </div>
                
                {getServiceById(activeService)?.status === 'connected' ? (
                  <button
                    onClick={() => handleDisconnect(activeService)}
                    className="px-3 py-1 bg-red-600 hover:bg-red-700 text-white rounded-md text-sm flex items-center"
                  >
                    <X size={14} className="mr-1" />
                    Déconnecter
                  </button>
                ) : isConnecting ? (
                  <button
                    disabled
                    className="px-3 py-1 bg-gray-600 text-gray-300 rounded-md text-sm flex items-center cursor-not-allowed"
                  >
                    <div className="mr-1 w-3 h-3 border-2 border-gray-300 border-t-white rounded-full animate-spin"></div>
                    Connexion...
                  </button>
                ) : (
                  <button
                    onClick={() => handleConnect(activeService)}
                    className="px-3 py-1 bg-violet-600 hover:bg-violet-700 text-white rounded-md text-sm flex items-center"
                    disabled={apiKey.trim() === ''}
                  >
                    <Cloud size={14} className="mr-1" />
                    Connecter
                  </button>
                )}
              </div>
              
              {getServiceById(activeService)?.status !== 'connected' && (
                <div className="mb-4">
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Clé API {getServiceById(activeService)?.name}
                  </label>
                  <div className="relative">
                    <input 
                      type={showApiKey ? "text" : "password"}
                      value={apiKey}
                      onChange={(e) => setApiKey(e.target.value)}
                      placeholder="Entrez votre clé API..."
                      className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 pr-10 text-white focus:border-violet-500 focus:ring focus:ring-violet-500 focus:ring-opacity-50"
                    />
                    <button 
                      onClick={() => setShowApiKey(!showApiKey)}
                      className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-violet-400"
                    >
                      {showApiKey ? <EyeOff size={18} /> : <Eye size={18} />}
                    </button>
                  </div>
                </div>
              )}
              
              {connectionError && (
                <div className="mb-4 p-3 bg-red-900/50 border border-red-700 rounded-md text-white flex items-start">
                  <AlertTriangle size={18} className="mr-2 mt-0.5 flex-shrink-0" />
                  <p>{connectionError}</p>
                </div>
              )}
              
              <div className="flex space-x-1 border-b border-gray-700 mb-4">
                <button
                  onClick={() => setActiveTab('overview')}
                  className={`px-4 py-2 text-sm font-medium ${
                    activeTab === 'overview' ? 'text-violet-400 border-b-2 border-violet-400' : 'text-gray-400 hover:text-gray-300'
                  }`}
                >
                  Aperçu
                </button>
                <button
                  onClick={() => setActiveTab('api')}
                  className={`px-4 py-2 text-sm font-medium flex items-center ${
                    activeTab === 'api' ? 'text-violet-400 border-b-2 border-violet-400' : 'text-gray-400 hover:text-gray-300'
                  }`}
                >
                  API
                  {getServiceById(activeService)?.apiEnabled && (
                    <span className="ml-2 bg-violet-900/50 text-violet-300 rounded-full text-xs px-1.5">
                      {getServiceById(activeService)?.apiEndpoints}
                    </span>
                  )}
                </button>
                <button
                  onClick={() => setActiveTab('settings')}
                  className={`px-4 py-2 text-sm font-medium ${
                    activeTab === 'settings' ? 'text-violet-400 border-b-2 border-violet-400' : 'text-gray-400 hover:text-gray-300'
                  }`}
                >
                  Paramètres
                </button>
              </div>
              
              {renderTabContent()}
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <Cloud size={64} className="text-violet-500/50 mb-4" />
            <h3 className="text-xl font-semibold mb-2 text-violet-100">Services Cloud</h3>
            <p className="text-gray-400 mb-4 max-w-md">
              Connectez-vous à différents services cloud pour synchroniser vos fichiers, exécuter des commandes à distance, et plus.
            </p>
            <p className="text-gray-400 max-w-md">
              Sélectionnez un service dans la liste à gauche pour commencer.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};