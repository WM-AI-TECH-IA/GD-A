// This component has been replaced by the integrated mobile keyboard
// in Terminal.tsx using utility keys and gesture controls