import React, { useState, useEffect } from 'react';
import { Key, Code, Shield, RefreshCw, Download, PlayCircle, PauseCircle, Settings, Server, Lock, Copy, Eye, EyeOff, Save, AlertTriangle, CheckCircle } from 'lucide-react';
import { encryptData, decryptData } from '../utils/security';
import { getApiGatewaySettings, updateApiGatewaySettings, getApiKeys, createApiKey, updateApiKey, getApiRoutes, updateApiRouteStatus, ApiGatewaySettings, ApiKey, ApiRoute } from '../utils/supabaseClient';
import { addLogEntry, LogLevel } from '../utils/logger';

type ApiGatewayProps = {
  securityLevel: 'standard' | 'high' | 'extreme';
  refreshLogs: () => void;
};

export const ApiGateway: React.FC<ApiGatewayProps> = ({ 
  securityLevel,
  refreshLogs
}) => {
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([]);
  const [apiRoutes, setApiRoutes] = useState<ApiRoute[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [settings, setSettings] = useState<ApiGatewaySettings>({
    base_url: 'https://api.wmterminal.com',
    security_level: securityLevel,
    default_rate_limit: 100,
    authentication_required_by_default: true,
    cors_origins: 'https://wmterminal.com, https://admin.wmterminal.com'
  });
  
  const [showKey, setShowKey] = useState<{ [key: string]: boolean }>({});
  const [activeTab, setActiveTab] = useState<'keys' | 'routes' | 'settings'>('keys');
  const [gatewayStatus, setGatewayStatus] = useState<'running' | 'stopped'>('running');
  const [requestsPerSecond, setRequestsPerSecond] = useState<number>(0);
  const [newKeyName, setNewKeyName] = useState<string>('');
  const [newKeyScopes, setNewKeyScopes] = useState<string[]>(['read']);
  const [notification, setNotification] = useState<{type: 'success' | 'error', message: string} | null>(null);
  const [newlyCreatedKey, setNewlyCreatedKey] = useState<{id: string, key: string} | null>(null);
  
  // Récupérer les données initiales
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        
        // Récupérer les paramètres
        const settingsData = await getApiGatewaySettings();
        if (settingsData) {
          setSettings(settingsData);
        }
        
        // Récupérer les clés API
        const keysData = await getApiKeys();
        setApiKeys(keysData);
        
        // Récupérer les routes API
        const routesData = await getApiRoutes();
        setApiRoutes(routesData);

        // Log successful data load
        addLogEntry(LogLevel.INFO, 'API Gateway data loaded successfully');
        
      } catch (error) {
        console.error("Erreur lors du chargement des données:", error);
        setNotification({
          type: 'error',
          message: 'Erreur lors du chargement des données'
        });
        
        addLogEntry(LogLevel.ERROR, 'Failed to load API Gateway data', {
          error: String(error)
        });
      } finally {
        setLoading(false);
      }
    };
    
    fetchData();
  }, []);
  
  // Simuler des données de monitoring en temps réel
  useEffect(() => {
    const interval = setInterval(() => {
      if (gatewayStatus === 'running') {
        // Fluctuation aléatoire pour RPS
        setRequestsPerSecond(Math.floor(Math.random() * 10) + 5);
      } else {
        setRequestsPerSecond(0);
      }
    }, 2000);
    
    return () => clearInterval(interval);
  }, [gatewayStatus]);
  
  // Auto-hide notifications after 3 seconds
  useEffect(() => {
    if (notification) {
      const timer = setTimeout(() => {
        setNotification(null);
      }, 3000);
      
      return () => clearTimeout(timer);
    }
  }, [notification]);
  
  const toggleKeyVisibility = (keyId: string) => {
    setShowKey(prev => ({
      ...prev,
      [keyId]: !prev[keyId]
    }));
    
    // Log the event if key visibility is being enabled
    if (!showKey[keyId]) {
      addLogEntry(LogLevel.INFO, 'API key visibility toggled', {
        action: 'show',
        keyId
      });
    }
  };
  
  const toggleRouteStatus = async (routeId: string) => {
    try {
      // Trouver la route actuelle
      const route = apiRoutes.find(r => r.id === routeId);
      if (!route) {
        throw new Error("Route non trouvée");
      }
      
      addLogEntry(LogLevel.INFO, `Toggling API route status`, {
        routeId,
        currentStatus: route.status,
        newStatus: route.status === 'active' ? 'inactive' : 'active'
      });
      
      // Mettre à jour le statut dans la base de données
      const newStatus = route.status === 'active' ? 'inactive' : 'active';
      const updatedRoute = await updateApiRouteStatus(routeId, newStatus);
      
      if (updatedRoute) {
        // Mettre à jour l'état local
        setApiRoutes(routes => 
          routes.map(route => 
            route.id === routeId 
              ? { ...route, status: newStatus }
              : route
          )
        );
        
        setNotification({
          type: 'success',
          message: `Statut de la route modifié avec succès`
        });
        
        addLogEntry(LogLevel.SUCCESS, `API route status changed successfully`, {
          routeId,
          newStatus
        });
      }
    } catch (error) {
      console.error("Erreur lors de la modification du statut de la route:", error);
      setNotification({
        type: 'error',
        message: `Échec de la modification du statut`
      });
      
      addLogEntry(LogLevel.ERROR, `Failed to change API route status`, {
        routeId,
        error: String(error)
      });
    }
  };
  
  const revokeKey = async (keyId: string) => {
    try {
      addLogEntry(LogLevel.WARNING, `API key revocation initiated`, {
        keyId
      });
      
      // Mettre à jour le statut dans la base de données
      const updatedKey = await updateApiKey(keyId, 'revoked');
      
      if (updatedKey) {
        // Mettre à jour l'état local
        setApiKeys(keys => 
          keys.map(key => 
            key.id === keyId 
              ? { ...key, status: 'revoked' }
              : key
          )
        );
        
        setNotification({
          type: 'success',
          message: `Clé API révoquée avec succès`
        });
        
        addLogEntry(LogLevel.SUCCESS, `API key revoked successfully`, {
          keyId
        });
      }
    } catch (error) {
      console.error("Erreur lors de la révocation de la clé API:", error);
      setNotification({
        type: 'error',
        message: `Échec de la révocation de la clé API`
      });
      
      addLogEntry(LogLevel.ERROR, `Failed to revoke API key`, {
        keyId,
        error: String(error)
      });
    }
  };
  
  const generateNewKey = async () => {
    if (!newKeyName.trim()) return;
    
    try {
      addLogEntry(LogLevel.INFO, `API key generation initiated`, {
        name: newKeyName,
        scopes: newKeyScopes
      });
      
      // Create key data without the actual key - will be generated securely by the API
      const keyData = {
        name: newKeyName,
        scopes: newKeyScopes,
        status: 'active' as const
      };
      
      // Call the enhanced createApiKey function
      const result = await createApiKey(keyData);
      
      if (result) {
        // Store the newly created key in state
        setApiKeys(prevKeys => [result.apiKey, ...prevKeys]);
        
        // Remember the full plaintext key for this session only
        setNewlyCreatedKey({
          id: result.apiKey.id,
          key: result.plainTextKey
        });
        
        // Automatically show the full key to the user
        setShowKey(prev => ({
          ...prev,
          [result.apiKey.id]: true
        }));
        
        // Reset the form
        setNewKeyName('');
        setNewKeyScopes(['read']);
        
        setNotification({
          type: 'success',
          message: `Nouvelle clé API générée avec succès. Assurez-vous de copier cette clé maintenant, car vous ne pourrez plus la voir en entier ultérieurement.`
        });
        
        addLogEntry(LogLevel.SUCCESS, 'API key generated successfully', {
          keyId: result.apiKey.id,
          scopes: newKeyScopes
        });
      }
    } catch (error) {
      console.error("Erreur lors de la génération de la nouvelle clé:", error);
      setNotification({
        type: 'error',
        message: `Échec de la génération de la clé API`
      });
      
      addLogEntry(LogLevel.ERROR, 'Failed to generate API key', {
        error: String(error)
      });
    }
  };
  
  const toggleScope = (scope: string) => {
    if (newKeyScopes.includes(scope)) {
      setNewKeyScopes(newKeyScopes.filter(s => s !== scope));
    } else {
      setNewKeyScopes([...newKeyScopes, scope]);
    }
  };
  
  const formatDate = (date?: Date | string) => {
    if (!date) return 'Jamais';
    
    const dateObj = typeof date === 'string' ? new Date(date) : date;
    return dateObj.toLocaleString();
  };
  
  const copyToClipboard = (text: string, isApiKey = false) => {
    try {
      navigator.clipboard.writeText(text);
      
      // If copying an API key, log it (without the key itself)
      if (isApiKey) {
        addLogEntry(LogLevel.INFO, 'API key copied to clipboard');
      }
      
      setNotification({
        type: 'success',
        message: isApiKey 
          ? 'Clé API copiée dans le presse-papier'
          : 'Copié dans le presse-papier'
      });
    } catch (error) {
      console.error("Erreur lors de la copie dans le presse-papier:", error);
      setNotification({
        type: 'error',
        message: 'Échec de la copie dans le presse-papier'
      });
      
      addLogEntry(LogLevel.ERROR, 'Failed to copy to clipboard', {
        error: String(error)
      });
    }
  };
  
  const handleSettingsChange = (key: keyof ApiGatewaySettings, value: any) => {
    setSettings(prev => ({
      ...prev,
      [key]: value
    }));
  };
  
  const saveSettings = async () => {
    try {
      addLogEntry(LogLevel.INFO, 'Saving API Gateway settings', {
        baseUrl: settings.base_url,
        securityLevel: settings.security_level
      });
      
      // Mettre à jour les paramètres dans la base de données
      const updatedSettings = await updateApiGatewaySettings(settings);
      
      if (updatedSettings) {
        setSettings(updatedSettings);
        setNotification({
          type: 'success',
          message: 'Paramètres enregistrés avec succès'
        });
        
        addLogEntry(LogLevel.SUCCESS, 'API Gateway settings saved successfully');
      }
    } catch (error) {
      console.error("Erreur lors de l'enregistrement des paramètres:", error);
      setNotification({
        type: 'error',
        message: 'Échec de l\'enregistrement des paramètres'
      });
      
      addLogEntry(LogLevel.ERROR, 'Failed to save API Gateway settings', {
        error: String(error)
      });
    }
  };
  
  return (
    <div className="flex-1 overflow-hidden flex flex-col bg-gray-900">
      <div className="bg-gray-800 p-4 border-b border-violet-900">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <Key size={24} className="mr-2 text-violet-400" />
            <h2 className="text-xl font-semibold text-violet-100">API Gateway</h2>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="flex items-center">
              <div className={`w-2 h-2 rounded-full mr-2 ${gatewayStatus === 'running' ? 'bg-green-500' : 'bg-red-500'}`}></div>
              <span className="text-sm text-gray-300">
                {gatewayStatus === 'running' ? 'En ligne' : 'Hors ligne'}
              </span>
            </div>
            
            <button
              onClick={() => setGatewayStatus(gatewayStatus === 'running' ? 'stopped' : 'running')}
              className={`p-2 rounded-md ${
                gatewayStatus === 'running' 
                  ? 'bg-red-600/20 text-red-400 hover:bg-red-600/30' 
                  : 'bg-green-600/20 text-green-400 hover:bg-green-600/30'
              }`}
            >
              {gatewayStatus === 'running' ? <PauseCircle size={20} /> : <PlayCircle size={20} />}
            </button>
            
            <button
              className="p-2 bg-gray-700 rounded-md text-gray-300 hover:bg-gray-600 hover:text-white"
              onClick={refreshLogs}
            >
              <RefreshCw size={20} />
            </button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-gray-700 rounded-lg p-3">
            <div className="text-sm text-gray-400 mb-1">Requêtes/sec</div>
            <div className="text-lg font-semibold">{requestsPerSecond}</div>
          </div>
          
          <div className="bg-gray-700 rounded-lg p-3">
            <div className="text-sm text-gray-400 mb-1">Endpoints actifs</div>
            <div className="text-lg font-semibold">{apiRoutes.filter(r => r.status === 'active').length}/{apiRoutes.length}</div>
          </div>
          
          <div className="bg-gray-700 rounded-lg p-3">
            <div className="text-sm text-gray-400 mb-1">Niveau de sécurité</div>
            <div className="text-lg font-semibold flex items-center">
              <Shield size={16} className={`mr-1 ${
                securityLevel === 'extreme' ? 'text-violet-400' :
                securityLevel === 'high' ? 'text-purple-400' :
                'text-red-400'
              }`} />
              {securityLevel === 'extreme' ? 'Extrême' :
               securityLevel === 'high' ? 'Haute' :
               'Standard'}
            </div>
          </div>
        </div>
        
        {notification && (
          <div className={`mt-4 p-3 rounded-md flex items-center ${
            notification.type === 'success' ? 'bg-green-900/30 text-green-400 border border-green-800' : 
            'bg-red-900/30 text-red-400 border border-red-800'
          }`}>
            {notification.type === 'success' ? (
              <CheckCircle size={16} className="mr-2" />
            ) : (
              <AlertTriangle size={16} className="mr-2" />
            )}
            <span>{notification.message}</span>
          </div>
        )}
      </div>
      
      <div className="flex border-b border-gray-700">
        <button
          onClick={() => setActiveTab('keys')}
          className={`px-4 py-2 font-medium ${
            activeTab === 'keys' 
              ? 'text-violet-400 border-b-2 border-violet-400' 
              : 'text-gray-400 hover:text-white'
          }`}
        >
          Clés API
        </button>
        <button
          onClick={() => setActiveTab('routes')}
          className={`px-4 py-2 font-medium ${
            activeTab === 'routes' 
              ? 'text-violet-400 border-b-2 border-violet-400' 
              : 'text-gray-400 hover:text-white'
          }`}
        >
          Routes
        </button>
        <button
          onClick={() => setActiveTab('settings')}
          className={`px-4 py-2 font-medium ${
            activeTab === 'settings' 
              ? 'text-violet-400 border-b-2 border-violet-400' 
              : 'text-gray-400 hover:text-white'
          }`}
        >
          Paramètres
        </button>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4">
        {loading ? (
          <div className="flex items-center justify-center h-full">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-violet-500"></div>
          </div>
        ) : (
          <>
            {activeTab === 'keys' && (
              <div className="space-y-6">
                <div className="bg-gray-800 rounded-lg p-4 border border-violet-900/50">
                  <h3 className="text-lg font-semibold mb-4 text-violet-100">Générer une nouvelle clé API</h3>
                  
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Nom de la clé
                      </label>
                      <input
                        type="text"
                        value={newKeyName}
                        onChange={(e) => setNewKeyName(e.target.value)}
                        placeholder="ex: App Frontend, Service Client, etc."
                        className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:border-violet-500 focus:ring focus:ring-violet-500 focus:ring-opacity-50"
                      />
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Permissions
                      </label>
                      <div className="flex flex-wrap gap-2">
                        <button
                          onClick={() => toggleScope('read')}
                          className={`px-3 py-1 rounded-md text-sm ${
                            newKeyScopes.includes('read')
                              ? 'bg-green-600/50 text-green-300 border border-green-600'
                              : 'bg-gray-700 text-gray-300 border border-gray-600'
                          }`}
                        >
                          Lecture
                        </button>
                        <button
                          onClick={() => toggleScope('write')}
                          className={`px-3 py-1 rounded-md text-sm ${
                            newKeyScopes.includes('write')
                              ? 'bg-blue-600/50 text-blue-300 border border-blue-600'
                              : 'bg-gray-700 text-gray-300 border border-gray-600'
                          }`}
                        >
                          Écriture
                        </button>
                        <button
                          onClick={() => toggleScope('admin')}
                          className={`px-3 py-1 rounded-md text-sm ${
                            newKeyScopes.includes('admin')
                              ? 'bg-red-600/50 text-red-300 border border-red-600'
                              : 'bg-gray-700 text-gray-300 border border-gray-600'
                          }`}
                        >
                          Admin
                        </button>
                        <button
                          onClick={() => toggleScope('terminal')}
                          className={`px-3 py-1 rounded-md text-sm ${
                            newKeyScopes.includes('terminal')
                              ? 'bg-purple-600/50 text-purple-300 border border-purple-600'
                              : 'bg-gray-700 text-gray-300 border border-gray-600'
                          }`}
                        >
                          Terminal
                        </button>
                      </div>
                    </div>
                    
                    <div className="flex justify-end">
                      <button
                        onClick={generateNewKey}
                        disabled={!newKeyName.trim()}
                        className={`px-4 py-2 rounded-md text-white flex items-center ${
                          !newKeyName.trim()
                            ? 'bg-gray-600 cursor-not-allowed'
                            : 'bg-violet-600 hover:bg-violet-700'
                        }`}
                      >
                        <Key size={16} className="mr-2" />
                        Générer une nouvelle clé
                      </button>
                    </div>
                  </div>
                </div>
                
                <div className="bg-gray-800 rounded-lg overflow-hidden border border-violet-900/50">
                  <div className="p-4 border-b border-gray-700">
                    <h3 className="text-lg font-semibold text-violet-100">Clés API</h3>
                    <p className="text-sm text-gray-400">Gérez les clés API pour l'accès à la passerelle</p>
                  </div>
                  
                  <div className="overflow-x-auto">
                    {apiKeys.length === 0 ? (
                      <div className="p-8 text-center text-gray-400">
                        Aucune clé API trouvée. Créez une nouvelle clé pour commencer.
                      </div>
                    ) : (
                      <table className="w-full">
                        <thead>
                          <tr className="bg-gray-700">
                            <th className="px-4 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Nom</th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Clé</th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Permissions</th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Créée le</th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Dernière utilisation</th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Statut</th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Actions</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-700">
                          {apiKeys.map((key) => (
                            <tr key={key.id} className="bg-gray-800 hover:bg-gray-700">
                              <td className="px-4 py-3 whitespace-nowrap">
                                <div className="font-medium text-white">{key.name}</div>
                              </td>
                              <td className="px-4 py-3 whitespace-nowrap">
                                <div className="font-mono text-sm flex items-center">
                                  <span className="inline-flex items-center">
                                    {showKey[key.id] ? (newlyCreatedKey?.id === key.id ? newlyCreatedKey.key : key.key) : key.key.substring(0, 8) + '••••••••••••••'}
                                    <button 
                                      onClick={() => toggleKeyVisibility(key.id)}
                                      className="ml-2 text-gray-400 hover:text-violet-400"
                                      title={showKey[key.id] ? "Masquer la clé" : "Afficher la clé"}
                                    >
                                      {showKey[key.id] ? <EyeOff size={16} /> : <Eye size={16} />}
                                    </button>
                                    <button 
                                      onClick={() => copyToClipboard(newlyCreatedKey?.id === key.id ? newlyCreatedKey.key : key.key, true)}
                                      className="ml-2 text-gray-400 hover:text-violet-400"
                                      title="Copier la clé"
                                    >
                                      <Copy size={16} />
                                    </button>
                                  </span>
                                </div>
                              </td>
                              <td className="px-4 py-3 whitespace-nowrap">
                                <div className="flex space-x-1">
                                  {key.scopes.map((scope) => (
                                    <span key={scope} className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                                      scope === 'read' ? 'bg-green-900 text-green-300' :
                                      scope === 'write' ? 'bg-blue-900 text-blue-300' :
                                      scope === 'admin' ? 'bg-red-900 text-red-300' :
                                      'bg-purple-900 text-purple-300'
                                    }`}>
                                      {scope}
                                    </span>
                                  ))}
                                </div>
                              </td>
                              <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-300">
                                {formatDate(key.created_at)}
                              </td>
                              <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-300">
                                {formatDate(key.last_used)}
                              </td>
                              <td className="px-4 py-3 whitespace-nowrap">
                                <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                                  key.status === 'active' ? 'bg-green-900 text-green-300' :
                                  key.status === 'revoked' ? 'bg-red-900 text-red-300' :
                                  'bg-orange-900 text-orange-300'
                                }`}>
                                  {key.status === 'active' ? 'Active' :
                                  key.status === 'revoked' ? 'Révoquée' :
                                  'Expirée'}
                                </span>
                              </td>
                              <td className="px-4 py-3 whitespace-nowrap text-sm font-medium">
                                {key.status === 'active' ? (
                                  <button 
                                    onClick={() => revokeKey(key.id)}
                                    className="text-red-400 hover:text-red-300"
                                  >
                                    Révoquer
                                  </button>
                                ) : (
                                  <span className="text-gray-500">Révoquée</span>
                                )}
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    )}
                  </div>
                </div>
              </div>
            )}
            
            {activeTab === 'routes' && (
              <div className="space-y-6">
                <div className="bg-gray-800 rounded-lg overflow-hidden border border-violet-900/50">
                  <div className="p-4 border-b border-gray-700">
                    <h3 className="text-lg font-semibold text-violet-100">Routes API</h3>
                    <p className="text-sm text-gray-400">Configurer les points de terminaison exposés par la passerelle API</p>
                  </div>
                  
                  <div className="overflow-x-auto">
                    {apiRoutes.length === 0 ? (
                      <div className="p-8 text-center text-gray-400">
                        Aucune route API trouvée.
                      </div>
                    ) : (
                      <table className="w-full">
                        <thead>
                          <tr className="bg-gray-700">
                            <th className="px-4 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Chemin</th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Méthode</th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Authentification</th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Limite de requêtes</th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Sécurité</th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Statut</th>
                            <th className="px-4 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Actions</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-700">
                          {apiRoutes.map((route) => (
                            <tr key={route.id} className="bg-gray-800 hover:bg-gray-700">
                              <td className="px-4 py-3 whitespace-nowrap">
                                <div className="font-mono text-sm text-white">{route.path}</div>
                              </td>
                              <td className="px-4 py-3 whitespace-nowrap">
                                <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                                  route.method === 'GET' ? 'bg-green-900 text-green-300' :
                                  route.method === 'POST' ? 'bg-blue-900 text-blue-300' :
                                  route.method === 'PUT' ? 'bg-orange-900 text-orange-300' :
                                  'bg-red-900 text-red-300'
                                }`}>
                                  {route.method}
                                </span>
                              </td>
                              <td className="px-4 py-3 whitespace-nowrap text-sm">
                                {route.authenticated ? (
                                  <span className="flex items-center text-violet-400">
                                    <Lock size={14} className="mr-1" />
                                    Requise
                                  </span>
                                ) : (
                                  <span className="text-gray-400">Aucune</span>
                                )}
                              </td>
                              <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-300">
                                {route.rate_limit} req/min
                              </td>
                              <td className="px-4 py-3 whitespace-nowrap">
                                {route.secured ? (
                                  <span className="flex items-center text-violet-400">
                                    <Shield size={14} className="mr-1" />
                                    {securityLevel === 'extreme' ? 'E2E' : securityLevel === 'high' ? 'Haute' : 'Standard'}
                                  </span>
                                ) : (
                                  <span className="text-gray-400">Non sécurisé</span>
                                )}
                              </td>
                              <td className="px-4 py-3 whitespace-nowrap">
                                <div className="flex items-center">
                                  <div className={`w-2 h-2 rounded-full mr-2 ${
                                    route.status === 'active' ? 'bg-green-500' : 'bg-gray-500'
                                  }`}></div>
                                  <span className={route.status === 'active' ? 'text-green-400' : 'text-gray-400'}>
                                    {route.status === 'active' ? 'Actif' : 'Inactif'}
                                  </span>
                                </div>
                              </td>
                              <td className="px-4 py-3 whitespace-nowrap text-sm font-medium">
                                <button 
                                  onClick={() => toggleRouteStatus(route.id)}
                                  className={`${
                                    route.status === 'active' 
                                      ? 'text-red-400 hover:text-red-300' 
                                      : 'text-green-400 hover:text-green-300'
                                  }`}
                                >
                                  {route.status === 'active' ? 'Désactiver' : 'Activer'}
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    )}
                  </div>
                </div>
                
                <div className="bg-gray-800 rounded-lg p-4 border border-violet-900/50">
                  <h3 className="text-lg font-semibold mb-4 text-violet-100">Exemple d'utilisation</h3>
                  
                  <div className="bg-gray-700 rounded-md p-4">
                    <div className="font-medium text-violet-300 mb-2">Requête avec authentification</div>
                    <pre className="bg-gray-800 p-3 rounded-md text-sm font-mono text-white overflow-x-auto">
{`curl -X GET "${settings.base_url}/api/v1/projects" \\
  -H "Authorization: Bearer wm_******************************" \\
  -H "Content-Type: application/json"`}
                    </pre>
                  </div>
                </div>
              </div>
            )}
            
            {activeTab === 'settings' && (
              <div className="space-y-6">
                <div className="bg-gray-800 rounded-lg p-4 border border-violet-900/50">
                  <h3 className="text-lg font-semibold mb-4 text-violet-100 flex items-center">
                    <Settings size={20} className="mr-2 text-violet-400" />
                    Paramètres de la passerelle
                  </h3>
                  
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        URL de base
                      </label>
                      <div className="flex">
                        <input
                          type="text"
                          value={settings.base_url}
                          onChange={(e) => handleSettingsChange('base_url', e.target.value)}
                          className="flex-1 bg-gray-700 border border-gray-600 rounded-l-md py-2 px-3 text-white"
                        />
                        <button
                          onClick={() => copyToClipboard(settings.base_url)}
                          className="bg-gray-600 px-3 py-2 rounded-r-md text-gray-300 hover:bg-gray-500"
                        >
                          <Copy size={18} />
                        </button>
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Niveau de sécurité
                      </label>
                      <select
                        value={settings.security_level}
                        onChange={(e) => handleSettingsChange('security_level', e.target.value)}
                        className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:border-violet-500 focus:ring focus:ring-violet-500 focus:ring-opacity-50"
                      >
                        <option value="standard">Standard (AES-128)</option>
                        <option value="high">Haute (AES-256)</option>
                        <option value="extreme">Extrême (AES-512 + E2E)</option>
                      </select>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Limite de requêtes par défaut
                      </label>
                      <select
                        value={settings.default_rate_limit}
                        onChange={(e) => handleSettingsChange('default_rate_limit', parseInt(e.target.value))}
                        className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:border-violet-500 focus:ring focus:ring-violet-500 focus:ring-opacity-50"
                      >
                        <option value="50">50 req/min</option>
                        <option value="100">100 req/min</option>
                        <option value="200">200 req/min</option>
                        <option value="500">500 req/min</option>
                        <option value="1000">1000 req/min</option>
                      </select>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Authentification requise par défaut
                      </label>
                      <div className="relative inline-block w-12 mr-2 align-middle select-none">
                        <input 
                          type="checkbox" 
                          name="auth-toggle" 
                          id="auth-toggle" 
                          checked={settings.authentication_required_by_default}
                          onChange={(e) => handleSettingsChange('authentication_required_by_default', e.target.checked)}
                          className="sr-only"
                        />
                        <label 
                          htmlFor="auth-toggle" 
                          className="block overflow-hidden h-6 rounded-full bg-gray-600 cursor-pointer"
                        >
                          <span className={`dot absolute left-0.5 top-0.5 bg-white w-5 h-5 rounded-full transition-transform duration-200 transform ${settings.authentication_required_by_default ? 'translate-x-6' : 'translate-x-0'}`}></span>
                        </label>
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        CORS (Cross-Origin Resource Sharing)
                      </label>
                      <textarea
                        value={settings.cors_origins}
                        onChange={(e) => handleSettingsChange('cors_origins', e.target.value)}
                        rows={3}
                        className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:border-violet-500 focus:ring focus:ring-violet-500 focus:ring-opacity-50"
                        placeholder="Séparez les origines par des virgules"
                      ></textarea>
                      <p className="mt-1 text-xs text-gray-400">Liste des origines autorisées à accéder à l'API</p>
                    </div>
                    
                    <div className="flex justify-end pt-4 border-t border-gray-700">
                      <button
                        onClick={saveSettings}
                        className="px-4 py-2 bg-violet-600 text-white rounded-md hover:bg-violet-700 flex items-center"
                      >
                        <Save size={16} className="mr-2" />
                        Enregistrer les paramètres
                      </button>
                    </div>
                  </div>
                </div>
                
                <div className="bg-gray-800 rounded-lg p-4 border border-violet-900/50">
                  <h3 className="text-lg font-semibold mb-4 text-violet-100 flex items-center">
                    <Server size={20} className="mr-2 text-violet-400" />
                    Statut du serveur
                  </h3>
                  
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="bg-gray-700 rounded-lg p-3">
                        <div className="text-sm text-gray-400 mb-1">Temps de fonctionnement</div>
                        <div className="text-lg font-semibold">7 jours, 3 heures</div>
                      </div>
                      
                      <div className="bg-gray-700 rounded-lg p-3">
                        <div className="text-sm text-gray-400 mb-1">Utilisation de la mémoire</div>
                        <div className="text-lg font-semibold">356 MB / 1024 MB</div>
                      </div>
                      
                      <div className="bg-gray-700 rounded-lg p-3">
                        <div className="text-sm text-gray-400 mb-1">Requêtes totales</div>
                        <div className="text-lg font-semibold">12,432</div>
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Journal des événements
                      </label>
                      <div className="bg-gray-700 border border-gray-600 rounded-md p-2 h-40 overflow-y-auto font-mono text-xs">
                        <div className="text-green-400">[2025-05-15 12:34:56] INFO: API Gateway started successfully</div>
                        <div className="text-gray-400">[2025-05-15 12:35:12] INFO: Route /api/v1/projects registered</div>
                        <div className="text-gray-400">[2025-05-15 12:35:12] INFO: Route /api/v1/users registered</div>
                        <div className="text-yellow-400">[2025-05-15 13:42:18] WARN: Rate limit exceeded for IP 192.168.1.45</div>
                        <div className="text-red-400">[2025-05-15 14:15:23] ERROR: Authentication failed - Invalid token</div>
                        <div className="text-gray-400">[2025-05-15 14:28:56] INFO: Key 'Application Frontend' used for API access</div>
                        <div className="text-gray-400">[2025-05-15 15:03:22] INFO: Successfully processed 500 requests in the last hour</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};