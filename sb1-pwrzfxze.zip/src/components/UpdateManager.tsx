import React, { useState, useEffect } from 'react';
import { 
  RefreshCw, Download, Upload, Check, AlertTriangle, X, 
  FileText, ArrowDownCircle, ArrowUpCircle, Shield, RotateCcw,
  Clock, CheckCircle, XCircle, AlertCircle
} from 'lucide-react';
import { 
  checkForUpdates, 
  downloadUpdate, 
  verifyUpdate, 
  installUpdate, 
  rollbackUpdate,
  getSystemInfo,
  getUpdateLog,
  UpdateLogEntry
} from '../services/updateService';

type UpdateManagerProps = {
  securityLevel: 'standard' | 'high' | 'extreme';
};

type UpdateStatus = 'idle' | 'checking' | 'downloading' | 'verifying' | 'installing' | 'complete' | 'error' | 'rollback';

export const UpdateManager: React.FC<UpdateManagerProps> = ({ securityLevel }) => {
  const [updateStatus, setUpdateStatus] = useState<UpdateStatus>('idle');
  const [updateAvailable, setUpdateAvailable] = useState<boolean>(false);
  const [currentVersion, setCurrentVersion] = useState<string>('');
  const [latestVersion, setLatestVersion] = useState<string>('');
  const [updateInfo, setUpdateInfo] = useState<any>(null);
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [downloadPath, setDownloadPath] = useState<string>('');
  const [updateLogs, setUpdateLogs] = useState<UpdateLogEntry[]>([]);
  const [activeTab, setActiveTab] = useState<'overview' | 'changelog' | 'logs'>('overview');
  
  // Initial load of system info
  useEffect(() => {
    const systemInfo = getSystemInfo();
    setCurrentVersion(systemInfo.currentVersion);
  }, []);
  
  // Load update logs
  useEffect(() => {
    setUpdateLogs(getUpdateLog());
    
    // Refresh logs periodically
    const interval = setInterval(() => {
      setUpdateLogs(getUpdateLog());
    }, 5000);
    
    return () => clearInterval(interval);
  }, []);
  
  const handleCheckForUpdates = async () => {
    try {
      setUpdateStatus('checking');
      setErrorMessage('');
      
      const result = await checkForUpdates();
      setUpdateAvailable(result.hasUpdate);
      setLatestVersion(result.latestVersion);
      setCurrentVersion(result.currentVersion);
      setUpdateInfo(result.updateInfo);
      
      setUpdateStatus('idle');
    } catch (error) {
      setUpdateStatus('error');
      setErrorMessage(error instanceof Error ? error.message : 'Erreur lors de la vérification des mises à jour');
    }
  };
  
  const handleDownloadUpdate = async () => {
    if (!updateInfo) return;
    
    try {
      setUpdateStatus('downloading');
      setErrorMessage('');
      
      const result = await downloadUpdate(updateInfo);
      
      if (result.success && result.path) {
        setDownloadPath(result.path);
        setUpdateStatus('verifying');
        
        // Automatically verify after download
        const verified = await verifyUpdate(result.path, updateInfo.sha256);
        
        if (verified) {
          setUpdateStatus('idle');
        } else {
          setUpdateStatus('error');
          setErrorMessage('La vérification de l\'intégrité du fichier a échoué');
        }
      } else {
        setUpdateStatus('error');
        setErrorMessage(result.error || 'Échec du téléchargement');
      }
    } catch (error) {
      setUpdateStatus('error');
      setErrorMessage(error instanceof Error ? error.message : 'Erreur lors du téléchargement');
    }
  };
  
  const handleInstallUpdate = async () => {
    if (!updateInfo || !downloadPath) return;
    
    try {
      setUpdateStatus('installing');
      setErrorMessage('');
      
      const result = await installUpdate(downloadPath, updateInfo);
      
      if (result.success) {
        setUpdateStatus('complete');
        setCurrentVersion(updateInfo.version);
        setUpdateAvailable(false);
      } else {
        setUpdateStatus('error');
        setErrorMessage(result.error || 'Échec de l\'installation');
      }
    } catch (error) {
      setUpdateStatus('error');
      setErrorMessage(error instanceof Error ? error.message : 'Erreur lors de l\'installation');
    }
  };
  
  const handleRollbackUpdate = async () => {
    try {
      setUpdateStatus('rollback');
      setErrorMessage('');
      
      const result = await rollbackUpdate();
      
      if (result.success) {
        // Refresh system info
        const systemInfo = getSystemInfo();
        setCurrentVersion(systemInfo.currentVersion);
        
        setUpdateStatus('idle');
        // Check for updates again to refresh the state
        handleCheckForUpdates();
      } else {
        setUpdateStatus('error');
        setErrorMessage(result.error || 'Échec de la restauration');
      }
    } catch (error) {
      setUpdateStatus('error');
      setErrorMessage(error instanceof Error ? error.message : 'Erreur lors de la restauration');
    }
  };
  
  // Format date string
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
  };
  
  // Get status badge
  const getStatusBadge = (status: UpdateStatus) => {
    switch (status) {
      case 'checking':
        return (
          <span className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-blue-900 text-blue-300">
            <RefreshCw size={12} className="mr-1 animate-spin" />
            Vérification...
          </span>
        );
      case 'downloading':
        return (
          <span className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-blue-900 text-blue-300">
            <Download size={12} className="mr-1 animate-pulse" />
            Téléchargement...
          </span>
        );
      case 'verifying':
        return (
          <span className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-yellow-900 text-yellow-300">
            <Shield size={12} className="mr-1" />
            Vérification...
          </span>
        );
      case 'installing':
        return (
          <span className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-purple-900 text-purple-300">
            <Upload size={12} className="mr-1 animate-pulse" />
            Installation...
          </span>
        );
      case 'complete':
        return (
          <span className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-green-900 text-green-300">
            <Check size={12} className="mr-1" />
            Mise à jour terminée
          </span>
        );
      case 'error':
        return (
          <span className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-red-900 text-red-300">
            <X size={12} className="mr-1" />
            Erreur
          </span>
        );
      case 'rollback':
        return (
          <span className="inline-flex items-center px-2 py-1 rounded text-xs font-medium bg-orange-900 text-orange-300">
            <RotateCcw size={12} className="mr-1 animate-spin" />
            Restauration...
          </span>
        );
      default:
        return null;
    }
  };
  
  // Get log entry icon
  const getLogIcon = (entry: UpdateLogEntry) => {
    switch (entry.status) {
      case 'success':
        return <CheckCircle size={16} className="text-green-400" />;
      case 'error':
        return <XCircle size={16} className="text-red-400" />;
      case 'warning':
        return <AlertCircle size={16} className="text-yellow-400" />;
      case 'info':
        return <Clock size={16} className="text-blue-400" />;
      default:
        return <Clock size={16} className="text-gray-400" />;
    }
  };
  
  return (
    <div className="flex-1 overflow-hidden flex flex-col bg-gray-900">
      <div className="bg-gray-800 p-4 border-b border-violet-900">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <RefreshCw size={24} className="mr-2 text-violet-400" />
            <h2 className="text-xl font-semibold text-violet-100">Gestionnaire de Mises à Jour</h2>
          </div>
          
          <div className="flex items-center space-x-2">
            {updateStatus !== 'idle' && getStatusBadge(updateStatus)}
            
            {updateStatus === 'idle' && (
              <button
                onClick={handleCheckForUpdates}
                className="px-3 py-1 bg-violet-600 hover:bg-violet-700 text-white rounded-md text-sm flex items-center"
              >
                <RefreshCw size={14} className="mr-1" />
                Vérifier les mises à jour
              </button>
            )}
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-gray-700 rounded-lg p-3">
            <div className="text-sm text-gray-400 mb-1">Version actuelle</div>
            <div className="text-lg font-semibold">{currentVersion}</div>
          </div>
          
          <div className="bg-gray-700 rounded-lg p-3">
            <div className="text-sm text-gray-400 mb-1">Dernière version</div>
            <div className="text-lg font-semibold">
              {latestVersion || 'N/A'}
              {updateAvailable && (
                <span className="ml-2 text-xs bg-green-900 text-green-300 px-2 py-0.5 rounded-full">
                  Mise à jour disponible
                </span>
              )}
            </div>
          </div>
          
          <div className="bg-gray-700 rounded-lg p-3">
            <div className="text-sm text-gray-400 mb-1">Niveau de sécurité</div>
            <div className="text-lg font-semibold flex items-center">
              <Shield size={16} className={`mr-1 ${
                securityLevel === 'extreme' ? 'text-violet-400' :
                securityLevel === 'high' ? 'text-purple-400' :
                'text-red-400'
              }`} />
              {securityLevel === 'extreme' ? 'Extrême' :
              securityLevel === 'high' ? 'Haute' :
              'Standard'}
            </div>
          </div>
        </div>
      </div>
      
      <div className="flex border-b border-gray-700">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-4 py-2 font-medium ${
            activeTab === 'overview' 
              ? 'text-violet-400 border-b-2 border-violet-400' 
              : 'text-gray-400 hover:text-white'
          }`}
        >
          Aperçu
        </button>
        {updateInfo && (
          <button
            onClick={() => setActiveTab('changelog')}
            className={`px-4 py-2 font-medium ${
              activeTab === 'changelog' 
                ? 'text-violet-400 border-b-2 border-violet-400' 
                : 'text-gray-400 hover:text-white'
            }`}
          >
            Notes de version
          </button>
        )}
        <button
          onClick={() => setActiveTab('logs')}
          className={`px-4 py-2 font-medium ${
            activeTab === 'logs' 
              ? 'text-violet-400 border-b-2 border-violet-400' 
              : 'text-gray-400 hover:text-white'
          }`}
        >
          Journal des mises à jour
        </button>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4">
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {errorMessage && (
              <div className="bg-red-900/30 border border-red-700 rounded-lg p-4 flex items-start mb-4">
                <AlertTriangle size={20} className="text-red-400 mr-3 mt-0.5" />
                <div className="flex-1">
                  <h3 className="font-medium text-red-400 mb-1">Erreur</h3>
                  <p className="text-white text-sm">{errorMessage}</p>
                </div>
              </div>
            )}
            
            {updateStatus === 'complete' && (
              <div className="bg-green-900/30 border border-green-700 rounded-lg p-4 flex items-start mb-4">
                <Check size={20} className="text-green-400 mr-3 mt-0.5" />
                <div className="flex-1">
                  <h3 className="font-medium text-green-400 mb-1">Mise à jour terminée</h3>
                  <p className="text-white text-sm">
                    La mise à jour vers la version {updateInfo?.version} a été installée avec succès.
                    {updateInfo?.requiresRestart && (
                      <span className="block mt-1 font-medium">Un redémarrage du système est nécessaire pour appliquer les changements.</span>
                    )}
                  </p>
                </div>
              </div>
            )}
            
            <div className="bg-gray-800 rounded-lg overflow-hidden border border-violet-900/50">
              <div className="p-4 border-b border-gray-700">
                <h3 className="text-lg font-semibold text-violet-100">État du système</h3>
              </div>
              
              <div className="p-4">
                {!updateAvailable && updateStatus === 'idle' ? (
                  <div className="flex items-center space-x-3 mb-6">
                    <div className="bg-green-900/30 p-3 rounded-full">
                      <Check size={24} className="text-green-400" />
                    </div>
                    <div>
                      <h4 className="text-lg font-medium text-white">Le système est à jour</h4>
                      <p className="text-gray-400">
                        Vous utilisez la dernière version ({currentVersion}) de WM Terminal.
                      </p>
                    </div>
                  </div>
                ) : updateAvailable ? (
                  <div className="flex items-start space-x-3 mb-6">
                    <div className="bg-blue-900/30 p-3 rounded-full">
                      <ArrowUpCircle size={24} className="text-blue-400" />
                    </div>
                    <div>
                      <h4 className="text-lg font-medium text-white">Mise à jour disponible</h4>
                      <p className="text-gray-400 mb-2">
                        Une nouvelle version ({updateInfo?.version}) est disponible. Vous utilisez actuellement la version {currentVersion}.
                      </p>
                      
                      {updateInfo && (
                        <div className="mt-2 space-y-2">
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <span className="text-gray-400">Date de sortie:</span> 
                              <span className="ml-2 text-white">{formatDate(updateInfo.releaseDate)}</span>
                            </div>
                            <div>
                              <span className="text-gray-400">Taille:</span> 
                              <span className="ml-2 text-white">{(updateInfo.size / 1024 / 1024).toFixed(2)} MB</span>
                            </div>
                            {updateInfo.critical && (
                              <div className="col-span-2">
                                <span className="bg-red-900/50 text-red-300 px-2 py-0.5 rounded text-xs">Mise à jour critique</span>
                              </div>
                            )}
                          </div>
                          
                          <div className="flex space-x-2 mt-3">
                            {downloadPath ? (
                              <button
                                onClick={handleInstallUpdate}
                                disabled={updateStatus !== 'idle'}
                                className={`px-3 py-1.5 rounded-md text-white flex items-center ${
                                  updateStatus !== 'idle' 
                                    ? 'bg-gray-600 cursor-not-allowed' 
                                    : 'bg-violet-600 hover:bg-violet-700'
                                }`}
                              >
                                <Upload size={16} className="mr-2" />
                                Installer la mise à jour
                              </button>
                            ) : (
                              <button
                                onClick={handleDownloadUpdate}
                                disabled={updateStatus !== 'idle'}
                                className={`px-3 py-1.5 rounded-md text-white flex items-center ${
                                  updateStatus !== 'idle' 
                                    ? 'bg-gray-600 cursor-not-allowed' 
                                    : 'bg-violet-600 hover:bg-violet-700'
                                }`}
                              >
                                <Download size={16} className="mr-2" />
                                Télécharger la mise à jour
                              </button>
                            )}
                            
                            <button
                              onClick={() => setActiveTab('changelog')}
                              className="px-3 py-1.5 bg-gray-700 hover:bg-gray-600 text-white rounded-md flex items-center"
                            >
                              <FileText size={16} className="mr-2" />
                              Voir les notes de version
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                ) : null}
                
                <div className="bg-gray-700 rounded-lg p-4">
                  <h4 className="text-md font-semibold mb-3 text-violet-100 flex items-center">
                    <Shield size={18} className="mr-2 text-violet-400" />
                    Options de mise à jour
                  </h4>
                  
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="block text-sm font-medium text-white">Vérification automatique</span>
                        <span className="text-xs text-gray-400">Vérifier périodiquement les nouvelles mises à jour</span>
                      </div>
                      <div className="relative inline-block w-12 align-middle select-none">
                        <input type="checkbox" id="auto-check" className="sr-only" defaultChecked />
                        <label htmlFor="auto-check" className="block overflow-hidden h-6 rounded-full bg-gray-600 cursor-pointer">
                          <span className="dot absolute left-0.5 top-0.5 bg-white w-5 h-5 rounded-full transition-transform duration-200 transform translate-x-6">
                            <span className="absolute inset-0 rounded-full bg-violet-600"></span>
                          </span>
                        </label>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="block text-sm font-medium text-white">Téléchargement automatique</span>
                        <span className="text-xs text-gray-400">Télécharger automatiquement les nouvelles mises à jour</span>
                      </div>
                      <div className="relative inline-block w-12 align-middle select-none">
                        <input type="checkbox" id="auto-download" className="sr-only" />
                        <label htmlFor="auto-download" className="block overflow-hidden h-6 rounded-full bg-gray-600 cursor-pointer">
                          <span className="dot absolute left-0.5 top-0.5 bg-white w-5 h-5 rounded-full transition-transform duration-200 transform translate-x-0"></span>
                        </label>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="block text-sm font-medium text-white">Installation automatique</span>
                        <span className="text-xs text-gray-400">Installer automatiquement les mises à jour téléchargées</span>
                      </div>
                      <div className="relative inline-block w-12 align-middle select-none">
                        <input type="checkbox" id="auto-install" className="sr-only" />
                        <label htmlFor="auto-install" className="block overflow-hidden h-6 rounded-full bg-gray-600 cursor-pointer">
                          <span className="dot absolute left-0.5 top-0.5 bg-white w-5 h-5 rounded-full transition-transform duration-200 transform translate-x-0"></span>
                        </label>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="block text-sm font-medium text-white">Mises à jour critiques uniquement</span>
                        <span className="text-xs text-gray-400">Ne télécharger que les mises à jour de sécurité importantes</span>
                      </div>
                      <div className="relative inline-block w-12 align-middle select-none">
                        <input type="checkbox" id="critical-only" className="sr-only" />
                        <label htmlFor="critical-only" className="block overflow-hidden h-6 rounded-full bg-gray-600 cursor-pointer">
                          <span className="dot absolute left-0.5 top-0.5 bg-white w-5 h-5 rounded-full transition-transform duration-200 transform translate-x-0"></span>
                        </label>
                      </div>
                    </div>
                    
                    <div className="pt-3 border-t border-gray-600">
                      <button
                        onClick={handleRollbackUpdate}
                        className="px-3 py-1 bg-orange-600/50 hover:bg-orange-600 text-white rounded-md flex items-center text-sm"
                        disabled={updateStatus !== 'idle' && updateStatus !== 'error'}
                      >
                        <RotateCcw size={14} className="mr-1" />
                        Restaurer la version précédente
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
        
        {activeTab === 'changelog' && updateInfo && (
          <div className="bg-gray-800 rounded-lg overflow-hidden border border-violet-900/50">
            <div className="p-4 border-b border-gray-700">
              <h3 className="text-lg font-semibold text-violet-100">Notes de version - {updateInfo.version}</h3>
              <p className="text-sm text-gray-400">Publié le {formatDate(updateInfo.releaseDate)}</p>
            </div>
            
            <div className="p-4">
              <h4 className="text-md font-semibold mb-3 text-violet-100">Nouveautés</h4>
              
              <ul className="mb-6 space-y-2 pl-2">
                {updateInfo.changeLog.map((change: string, index: number) => (
                  <li key={index} className="flex items-start">
                    <span className="inline-block w-4 h-4 rounded-full bg-violet-900 mr-3 mt-1 flex-shrink-0"></span>
                    <span>{change}</span>
                  </li>
                ))}
              </ul>
              
              <h4 className="text-md font-semibold mb-3 text-violet-100">Composants mis à jour</h4>
              
              <div className="bg-gray-700 rounded-md overflow-hidden">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-gray-600">
                      <th className="text-left py-2 px-3">Nom</th>
                      <th className="text-left py-2 px-3">Version</th>
                      <th className="text-left py-2 px-3">Chemin</th>
                    </tr>
                  </thead>
                  <tbody>
                    {updateInfo.components.map((component: any, index: number) => (
                      <tr key={index} className="border-t border-gray-600">
                        <td className="py-2 px-3">{component.name}</td>
                        <td className="py-2 px-3">{component.version}</td>
                        <td className="py-2 px-3 font-mono text-xs">{component.path}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              
              <div className="mt-4 flex justify-between">
                {updateInfo.requiresRestart && (
                  <div className="flex items-center text-sm text-yellow-400">
                    <AlertTriangle size={16} className="mr-1" />
                    Cette mise à jour nécessite un redémarrage du système.
                  </div>
                )}
                
                <div className="flex space-x-2">
                  {downloadPath ? (
                    <button
                      onClick={handleInstallUpdate}
                      disabled={updateStatus !== 'idle'}
                      className={`px-3 py-1.5 rounded-md text-white flex items-center ${
                        updateStatus !== 'idle' 
                          ? 'bg-gray-600 cursor-not-allowed' 
                          : 'bg-violet-600 hover:bg-violet-700'
                      }`}
                    >
                      <Upload size={16} className="mr-2" />
                      Installer la mise à jour
                    </button>
                  ) : (
                    <button
                      onClick={handleDownloadUpdate}
                      disabled={updateStatus !== 'idle'}
                      className={`px-3 py-1.5 rounded-md text-white flex items-center ${
                        updateStatus !== 'idle' 
                          ? 'bg-gray-600 cursor-not-allowed' 
                          : 'bg-violet-600 hover:bg-violet-700'
                      }`}
                    >
                      <Download size={16} className="mr-2" />
                      Télécharger la mise à jour
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
        
        {activeTab === 'logs' && (
          <div className="bg-gray-800 rounded-lg overflow-hidden border border-violet-900/50">
            <div className="p-4 border-b border-gray-700 flex justify-between items-center">
              <h3 className="text-lg font-semibold text-violet-100">Journal des mises à jour</h3>
              <button
                className="px-2 py-1 bg-gray-700 hover:bg-gray-600 text-sm text-gray-300 hover:text-white rounded"
                onClick={() => setUpdateLogs(getUpdateLog())}
              >
                <RefreshCw size={14} />
              </button>
            </div>
            
            <div className="overflow-y-auto max-h-96">
              {updateLogs.length === 0 ? (
                <div className="p-4 text-center text-gray-400">
                  Aucune entrée dans le journal des mises à jour
                </div>
              ) : (
                <ul className="divide-y divide-gray-700">
                  {updateLogs.map((log, index) => (
                    <li key={index} className="p-3 hover:bg-gray-700">
                      <div className="flex items-start">
                        <div className="mr-3 mt-1">{getLogIcon(log)}</div>
                        <div className="flex-1">
                          <div className="flex justify-between mb-1">
                            <span className="font-medium text-white">{log.message}</span>
                            <span className="text-xs text-gray-400">
                              {new Date(log.timestamp).toLocaleString()}
                            </span>
                          </div>
                          <div className="text-sm text-gray-400 flex items-center">
                            <span className="capitalize">{log.action}</span>
                            {log.version && (
                              <span className="ml-2 bg-gray-700 px-2 py-0.5 rounded text-xs">
                                v{log.version}
                              </span>
                            )}
                          </div>
                          {log.details && (
                            <div className="mt-1 text-xs text-gray-500">
                              {log.details}
                            </div>
                          )}
                        </div>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};