import React, { useState, useEffect } from 'react';
import { Code, Key, Settings, Lock, Clock, Play, Pause, Save, X, Plus, Check, RefreshCw, FileJson, Database, Server } from 'lucide-react';

type ApiEndpoint = {
  id: string;
  name: string;
  url: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
  headers: Record<string, string>;
  body?: string;
  authentication: 'none' | 'basic' | 'bearer' | 'api-key' | 'oauth2';
  authDetails?: {
    username?: string;
    password?: string;
    token?: string;
    apiKey?: string;
    keyLocation?: 'header' | 'query';
    keyName?: string;
  };
  status: 'idle' | 'active' | 'error';
  lastUsed?: Date;
  responses?: Array<{
    timestamp: Date;
    status: number;
    duration: number;
    data: string;
  }>;
};

type ApiCollection = {
  id: string;
  name: string;
  description?: string;
  endpoints: ApiEndpoint[];
  environment?: Record<string, string>;
};

type ApiManagerProps = {
  securityLevel: 'standard' | 'high' | 'extreme';
};

export const ApiManager: React.FC<ApiManagerProps> = ({ securityLevel }) => {
  const [collections, setCollections] = useState<ApiCollection[]>([
    {
      id: 'default',
      name: 'API Collection par défaut',
      description: 'Collection d\'API générée automatiquement',
      endpoints: [
        {
          id: 'example1',
          name: 'Exemple GET',
          url: 'https://api.example.com/data',
          method: 'GET',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
          },
          authentication: 'none',
          status: 'idle',
          lastUsed: new Date(Date.now() - 86400000), // 1 day ago
          responses: [
            {
              timestamp: new Date(Date.now() - 86400000),
              status: 200,
              duration: 230,
              data: '{"success": true, "data": {"id": 1, "name": "Exemple"}}'
            }
          ]
        },
        {
          id: 'example2',
          name: 'Exemple POST avec Auth',
          url: 'https://api.wmtech.com/secure',
          method: 'POST',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
          },
          body: '{\n  "query": "data",\n  "filter": {\n    "active": true\n  }\n}',
          authentication: 'bearer',
          authDetails: {
            token: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...'
          },
          status: 'idle'
        }
      ],
      environment: {
        'BASE_URL': 'https://api.example.com',
        'API_VERSION': 'v1'
      }
    },
    {
      id: 'cloud',
      name: 'Services Cloud',
      description: 'APIs pour différents services cloud',
      endpoints: [
        {
          id: 'aws-s3',
          name: 'AWS S3 Buckets',
          url: 'https://s3.amazonaws.com/buckets',
          method: 'GET',
          headers: {
            'Accept': 'application/json'
          },
          authentication: 'api-key',
          authDetails: {
            apiKey: '••••••••••••••••',
            keyLocation: 'header',
            keyName: 'X-AWS-Key'
          },
          status: 'idle'
        },
        {
          id: 'gcp-storage',
          name: 'GCP Storage',
          url: 'https://storage.googleapis.com/v1/objects',
          method: 'GET',
          headers: {
            'Accept': 'application/json'
          },
          authentication: 'bearer',
          authDetails: {
            token: '••••••••••••••••'
          },
          status: 'idle'
        }
      ]
    }
  ]);
  
  const [activeCollection, setActiveCollection] = useState<string>('default');
  const [activeEndpoint, setActiveEndpoint] = useState<string | null>(null);
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [responseData, setResponseData] = useState<string | null>(null);
  const [responseStatus, setResponseStatus] = useState<number | null>(null);
  const [responseDuration, setResponseDuration] = useState<number | null>(null);
  const [showNewEndpointForm, setShowNewEndpointForm] = useState<boolean>(false);
  const [newEndpoint, setNewEndpoint] = useState<Partial<ApiEndpoint>>({
    id: '',
    name: '',
    url: '',
    method: 'GET',
    headers: {},
    authentication: 'none',
    status: 'idle'
  });
  
  const getCollectionById = (id: string): ApiCollection | undefined => {
    return collections.find(c => c.id === id);
  };
  
  const getEndpointById = (collectionId: string, endpointId: string | null): ApiEndpoint | undefined => {
    if (!endpointId) return undefined;
    const collection = getCollectionById(collectionId);
    return collection?.endpoints.find(e => e.id === endpointId) || null;
  };
  
  const handleRunApi = (collectionId: string, endpointId: string) => {
    setIsRunning(true);
    setResponseData(null);
    setResponseStatus(null);
    setResponseDuration(null);
    
    // Simulate API call
    const startTime = Date.now();
    
    setTimeout(() => {
      const responseTime = Date.now() - startTime;
      
      // Randomly generate status code (mostly successful)
      const status = Math.random() > 0.8 ? 
        [400, 401, 403, 404, 500][Math.floor(Math.random() * 5)] : 
        [200, 201, 204][Math.floor(Math.random() * 3)];
      
      // Generate sample response
      let response = '';
      if (status >= 200 && status < 300) {
        if (status !== 204) {
          response = JSON.stringify({
            success: true,
            data: {
              id: Math.floor(Math.random() * 1000),
              timestamp: new Date().toISOString(),
              items: [
                { id: 1, name: "Item 1", value: Math.random() * 100 },
                { id: 2, name: "Item 2", value: Math.random() * 100 }
              ]
            }
          }, null, 2);
        }
      } else {
        response = JSON.stringify({
          success: false,
          error: {
            code: status,
            message: status === 401 ? "Non autorisé" : 
                    status === 404 ? "Ressource non trouvée" : 
                    "Erreur lors de la requête"
          }
        }, null, 2);
      }
      
      setResponseData(response);
      setResponseStatus(status);
      setResponseDuration(responseTime);
      setIsRunning(false);
      
      // Update endpoint with new response
      setCollections(prevCollections => {
        return prevCollections.map(collection => {
          if (collection.id === collectionId) {
            return {
              ...collection,
              endpoints: collection.endpoints.map(endpoint => {
                if (endpoint.id === endpointId) {
                  const newResponse = {
                    timestamp: new Date(),
                    status,
                    duration: responseTime,
                    data: response
                  };
                  
                  return {
                    ...endpoint,
                    status: status >= 200 && status < 300 ? 'active' : 'error',
                    lastUsed: new Date(),
                    responses: [newResponse, ...(endpoint.responses || [])]
                  };
                }
                return endpoint;
              })
            };
          }
          return collection;
        });
      });
    }, 1000 + Math.random() * 1000); // Random delay between 1-2 seconds
  };
  
  const handleSaveEndpoint = () => {
    if (!newEndpoint.name || !newEndpoint.url) return;
    
    // Create new endpoint
    const endpoint: ApiEndpoint = {
      id: newEndpoint.id || `endpoint-${Date.now()}`,
      name: newEndpoint.name,
      url: newEndpoint.url,
      method: newEndpoint.method as 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH',
      headers: newEndpoint.headers || {},
      body: newEndpoint.body,
      authentication: newEndpoint.authentication as 'none' | 'basic' | 'bearer' | 'api-key' | 'oauth2',
      authDetails: newEndpoint.authDetails,
      status: 'idle'
    };
    
    // Add to collection
    setCollections(prevCollections => {
      return prevCollections.map(collection => {
        if (collection.id === activeCollection) {
          return {
            ...collection,
            endpoints: [...collection.endpoints, endpoint]
          };
        }
        return collection;
      });
    });
    
    // Reset form
    setNewEndpoint({
      id: '',
      name: '',
      url: '',
      method: 'GET',
      headers: {},
      authentication: 'none',
      status: 'idle'
    });
    setShowNewEndpointForm(false);
  };
  
  const handleAddHeader = () => {
    const headers = newEndpoint.headers || {};
    setNewEndpoint({
      ...newEndpoint,
      headers: {
        ...headers,
        '': ''
      }
    });
  };
  
  const handleUpdateHeader = (oldKey: string, newKey: string, value: string) => {
    const headers = { ...newEndpoint.headers } || {};
    if (oldKey !== newKey) {
      delete headers[oldKey];
    }
    headers[newKey] = value;
    
    setNewEndpoint({
      ...newEndpoint,
      headers
    });
  };
  
  const handleRemoveHeader = (key: string) => {
    const headers = { ...newEndpoint.headers } || {};
    delete headers[key];
    
    setNewEndpoint({
      ...newEndpoint,
      headers
    });
  };
  
  const formatDate = (date?: Date) => {
    if (!date) return 'Jamais';
    
    // If today, show time only
    const today = new Date();
    const dateToFormat = new Date(date);
    
    if (dateToFormat.toDateString() === today.toDateString()) {
      return dateToFormat.toLocaleTimeString();
    }
    
    // Otherwise show date and time
    return dateToFormat.toLocaleString();
  };
  
  const renderStatusBadge = (status: 'idle' | 'active' | 'error') => {
    switch (status) {
      case 'active':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-purple-900 text-purple-300">
            <Check size={10} className="mr-1" />
            Actif
          </span>
        );
      case 'error':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-red-900 text-red-300">
            <X size={10} className="mr-1" />
            Erreur
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-gray-700 text-gray-300">
            Inactif
          </span>
        );
    }
  };
  
  const renderAuthBadge = (auth: 'none' | 'basic' | 'bearer' | 'api-key' | 'oauth2') => {
    switch (auth) {
      case 'none':
        return null;
      case 'basic':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-gray-700 text-gray-300">
            <Lock size={10} className="mr-1" />
            Basic
          </span>
        );
      case 'bearer':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-violet-900 text-violet-300">
            <Lock size={10} className="mr-1" />
            Bearer
          </span>
        );
      case 'api-key':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-purple-900 text-purple-300">
            <Key size={10} className="mr-1" />
            API Key
          </span>
        );
      case 'oauth2':
        return (
          <span className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium bg-blue-900 text-blue-300">
            <Lock size={10} className="mr-1" />
            OAuth 2.0
          </span>
        );
    }
  };
  
  const renderMethodBadge = (method: string) => {
    const bgColor = 
      method === 'GET' ? 'bg-green-900 text-green-300' : 
      method === 'POST' ? 'bg-purple-900 text-purple-300' : 
      method === 'PUT' ? 'bg-blue-900 text-blue-300' : 
      method === 'DELETE' ? 'bg-red-900 text-red-300' : 
      'bg-gray-700 text-gray-300';
      
    return (
      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${bgColor}`}>
        {method}
      </span>
    );
  };
  
  const renderStatusCode = (status: number) => {
    const bgColor = 
      status >= 200 && status < 300 ? 'bg-green-900 text-green-300' : 
      status >= 400 && status < 500 ? 'bg-orange-900 text-orange-300' : 
      status >= 500 ? 'bg-red-900 text-red-300' : 
      'bg-gray-700 text-gray-300';
      
    return (
      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${bgColor}`}>
        {status}
      </span>
    );
  };
  
  return (
    <div className="flex-1 overflow-hidden flex">
      <div className="w-64 bg-gray-800 border-r border-violet-900 overflow-y-auto">
        <div className="p-4">
          <h3 className="text-lg font-semibold mb-4 text-violet-100">Collections API</h3>
          
          <div className="space-y-4">
            {collections.map(collection => (
              <div key={collection.id} className="space-y-2">
                <button
                  onClick={() => setActiveCollection(collection.id)}
                  className={`w-full flex items-center justify-between p-2 rounded-md ${
                    activeCollection === collection.id 
                      ? 'bg-violet-900/50 text-white' 
                      : 'text-gray-300 hover:bg-violet-900/30 hover:text-white'
                  }`}
                >
                  <div className="flex items-center">
                    <Code size={18} className="mr-2 text-violet-400" />
                    <span>{collection.name}</span>
                  </div>
                  <span className="text-xs bg-gray-700 rounded-full px-2 py-0.5">
                    {collection.endpoints.length}
                  </span>
                </button>
                
                {activeCollection === collection.id && (
                  <div className="pl-6 space-y-1 border-l border-violet-900/50 ml-2">
                    {collection.endpoints.map(endpoint => (
                      <button
                        key={endpoint.id}
                        onClick={() => setActiveEndpoint(endpoint.id)}
                        className={`w-full flex items-center justify-between p-2 rounded-md text-sm ${
                          activeEndpoint === endpoint.id 
                            ? 'bg-violet-900/30 text-white' 
                            : 'text-gray-400 hover:bg-violet-900/20 hover:text-white'
                        }`}
                      >
                        <div className="flex items-center overflow-hidden">
                          <span className="mr-2 min-w-[36px]">{renderMethodBadge(endpoint.method)}</span>
                          <span className="truncate">{endpoint.name}</span>
                        </div>
                      </button>
                    ))}
                    
                    <button 
                      onClick={() => setShowNewEndpointForm(true)}
                      className="w-full flex items-center justify-center p-2 rounded-md text-sm text-gray-400 hover:bg-violet-900/20 hover:text-white"
                    >
                      <Plus size={16} className="mr-1" />
                      Ajouter un endpoint
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 bg-gray-900">
        {activeEndpoint && getEndpointById(activeCollection, activeEndpoint) ? (
          <div>
            {showNewEndpointForm ? (
              <div className="bg-gray-800 rounded-lg p-4 mb-4 border border-violet-900/50">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-semibold text-violet-100">Nouvel endpoint API</h3>
                  
                  <button
                    onClick={() => setShowNewEndpointForm(false)}
                    className="p-1 text-gray-400 hover:text-white"
                  >
                    <X size={18} />
                  </button>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Nom de l'endpoint
                    </label>
                    <input
                      type="text"
                      value={newEndpoint.name}
                      onChange={(e) => setNewEndpoint({...newEndpoint, name: e.target.value})}
                      placeholder="Entrez un nom descriptif..."
                      className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:border-violet-500 focus:ring focus:ring-violet-500 focus:ring-opacity-50"
                    />
                  </div>
                  
                  <div className="flex space-x-2">
                    <div className="w-1/4">
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Méthode
                      </label>
                      <select
                        value={newEndpoint.method}
                        onChange={(e) => setNewEndpoint({...newEndpoint, method: e.target.value as any})}
                        className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:border-violet-500 focus:ring focus:ring-violet-500 focus:ring-opacity-50"
                      >
                        <option value="GET">GET</option>
                        <option value="POST">POST</option>
                        <option value="PUT">PUT</option>
                        <option value="PATCH">PATCH</option>
                        <option value="DELETE">DELETE</option>
                      </select>
                    </div>
                    
                    <div className="w-3/4">
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        URL
                      </label>
                      <input
                        type="text"
                        value={newEndpoint.url}
                        onChange={(e) => setNewEndpoint({...newEndpoint, url: e.target.value})}
                        placeholder="https://api.example.com/endpoint"
                        className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:border-violet-500 focus:ring focus:ring-violet-500 focus:ring-opacity-50"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-300 mb-2">
                      Authentification
                    </label>
                    <select
                      value={newEndpoint.authentication}
                      onChange={(e) => setNewEndpoint({...newEndpoint, authentication: e.target.value as any})}
                      className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:border-violet-500 focus:ring focus:ring-violet-500 focus:ring-opacity-50"
                    >
                      <option value="none">Aucune</option>
                      <option value="basic">Basic Auth</option>
                      <option value="bearer">Bearer Token</option>
                      <option value="api-key">API Key</option>
                      <option value="oauth2">OAuth 2.0</option>
                    </select>
                  </div>
                  
                  {newEndpoint.authentication === 'basic' && (
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">
                          Nom d'utilisateur
                        </label>
                        <input
                          type="text"
                          value={newEndpoint.authDetails?.username || ''}
                          onChange={(e) => setNewEndpoint({
                            ...newEndpoint, 
                            authDetails: {...(newEndpoint.authDetails || {}), username: e.target.value}
                          })}
                          className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:border-violet-500 focus:ring focus:ring-violet-500 focus:ring-opacity-50"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">
                          Mot de passe
                        </label>
                        <input
                          type="password"
                          value={newEndpoint.authDetails?.password || ''}
                          onChange={(e) => setNewEndpoint({
                            ...newEndpoint, 
                            authDetails: {...(newEndpoint.authDetails || {}), password: e.target.value}
                          })}
                          className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:border-violet-500 focus:ring focus:ring-violet-500 focus:ring-opacity-50"
                        />
                      </div>
                    </div>
                  )}
                  
                  {newEndpoint.authentication === 'bearer' && (
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Token
                      </label>
                      <input
                        type="text"
                        value={newEndpoint.authDetails?.token || ''}
                        onChange={(e) => setNewEndpoint({
                          ...newEndpoint, 
                          authDetails: {...(newEndpoint.authDetails || {}), token: e.target.value}
                        })}
                        placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6..."
                        className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:border-violet-500 focus:ring focus:ring-violet-500 focus:ring-opacity-50"
                      />
                    </div>
                  )}
                  
                  {newEndpoint.authentication === 'api-key' && (
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">
                          Clé API
                        </label>
                        <input
                          type="text"
                          value={newEndpoint.authDetails?.apiKey || ''}
                          onChange={(e) => setNewEndpoint({
                            ...newEndpoint, 
                            authDetails: {...(newEndpoint.authDetails || {}), apiKey: e.target.value}
                          })}
                          className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:border-violet-500 focus:ring focus:ring-violet-500 focus:ring-opacity-50"
                        />
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-300 mb-2">
                            Emplacement
                          </label>
                          <select
                            value={newEndpoint.authDetails?.keyLocation || 'header'}
                            onChange={(e) => setNewEndpoint({
                              ...newEndpoint, 
                              authDetails: {...(newEndpoint.authDetails || {}), keyLocation: e.target.value as 'header' | 'query'}
                            })}
                            className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:border-violet-500 focus:ring focus:ring-violet-500 focus:ring-opacity-50"
                          >
                            <option value="header">Header</option>
                            <option value="query">Query Parameter</option>
                          </select>
                        </div>
                        
                        <div>
                          <label className="block text-sm font-medium text-gray-300 mb-2">
                            Nom du paramètre
                          </label>
                          <input
                            type="text"
                            value={newEndpoint.authDetails?.keyName || ''}
                            onChange={(e) => setNewEndpoint({
                              ...newEndpoint, 
                              authDetails: {...(newEndpoint.authDetails || {}), keyName: e.target.value}
                            })}
                            placeholder={newEndpoint.authDetails?.keyLocation === 'header' ? 'X-API-Key' : 'api_key'}
                            className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:border-violet-500 focus:ring focus:ring-violet-500 focus:ring-opacity-50"
                          />
                        </div>
                      </div>
                    </div>
                  )}
                  
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="block text-sm font-medium text-gray-300">
                        Headers
                      </label>
                      <button
                        onClick={handleAddHeader}
                        className="text-xs text-violet-400 hover:text-violet-300 flex items-center"
                      >
                        <Plus size={14} className="mr-1" />
                        Ajouter
                      </button>
                    </div>
                    
                    {Object.keys(newEndpoint.headers || {}).length > 0 ? (
                      <div className="space-y-2">
                        {Object.entries(newEndpoint.headers || {}).map(([key, value], index) => (
                          <div key={index} className="flex space-x-2">
                            <input
                              type="text"
                              value={key}
                              onChange={(e) => handleUpdateHeader(key, e.target.value, value)}
                              placeholder="Nom"
                              className="w-1/3 bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white text-sm focus:border-violet-500 focus:ring focus:ring-violet-500 focus:ring-opacity-50"
                            />
                            <input
                              type="text"
                              value={value}
                              onChange={(e) => handleUpdateHeader(key, key, e.target.value)}
                              placeholder="Valeur"
                              className="flex-1 bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white text-sm focus:border-violet-500 focus:ring focus:ring-violet-500 focus:ring-opacity-50"
                            />
                            <button
                              onClick={() => handleRemoveHeader(key)}
                              className="p-2 bg-gray-700 text-gray-400 hover:text-red-400 rounded-md"
                            >
                              <X size={16} />
                            </button>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-sm text-gray-500 italic bg-gray-700/50 p-3 rounded-md">
                        Aucun header configuré
                      </div>
                    )}
                  </div>
                  
                  {(newEndpoint.method === 'POST' || newEndpoint.method === 'PUT' || newEndpoint.method === 'PATCH') && (
                    <div>
                      <label className="block text-sm font-medium text-gray-300 mb-2">
                        Body (JSON)
                      </label>
                      <textarea
                        value={newEndpoint.body || ''}
                        onChange={(e) => setNewEndpoint({...newEndpoint, body: e.target.value})}
                        rows={5}
                        placeholder='{\n  "key": "value"\n}'
                        className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:border-violet-500 focus:ring focus:ring-violet-500 focus:ring-opacity-50 font-mono text-sm"
                      />
                    </div>
                  )}
                  
                  <div className="flex justify-end">
                    <button
                      onClick={() => setShowNewEndpointForm(false)}
                      className="px-4 py-2 bg-gray-700 text-gray-300 rounded-md mr-2 hover:bg-gray-600"
                    >
                      Annuler
                    </button>
                    <button
                      onClick={handleSaveEndpoint}
                      className="px-4 py-2 bg-violet-600 text-white rounded-md hover:bg-violet-700 flex items-center"
                      disabled={!newEndpoint.name || !newEndpoint.url}
                    >
                      <Save size={16} className="mr-2" />
                      Enregistrer
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div>
                <div className="bg-gray-800 rounded-lg p-4 mb-4 border border-violet-900/50">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center">
                      <Code size={20} className="mr-2 text-violet-400" />
                      <h3 className="text-xl font-semibold text-violet-100">
                        {getEndpointById(activeCollection, activeEndpoint)?.name}
                      </h3>
                    </div>
                    
                    <div className="flex space-x-2">
                      {!isRunning ? (
                        <button
                          onClick={() => handleRunApi(activeCollection, activeEndpoint)}
                          className="px-3 py-1 bg-violet-600 hover:bg-violet-700 text-white rounded-md text-sm flex items-center"
                        >
                          <Play size={14} className="mr-1" />
                          Exécuter
                        </button>
                      ) : (
                        <button
                          disabled
                          className="px-3 py-1 bg-gray-600 text-gray-300 rounded-md text-sm flex items-center cursor-not-allowed"
                        >
                          <div className="mr-1 w-3 h-3 border-2 border-gray-300 border-t-white rounded-full animate-spin"></div>
                          Exécution...
                        </button>
                      )}
                      
                      <button
                        onClick={() => setIsEditing(!isEditing)}
                        className="px-3 py-1 bg-gray-700 hover:bg-gray-600 text-white rounded-md text-sm flex items-center"
                      >
                        <Settings size={14} className="mr-1" />
                        {isEditing ? 'Aperçu' : 'Éditer'}
                      </button>
                    </div>
                  </div>
                  
                  {isEditing ? (
                    <div className="space-y-4">
                      <div className="flex space-x-2">
                        <div className="w-1/4">
                          <label className="block text-sm font-medium text-gray-300 mb-2">
                            Méthode
                          </label>
                          <div className="bg-gray-700 rounded-md py-2 px-3 text-white">
                            {getEndpointById(activeCollection, activeEndpoint)?.method}
                          </div>
                        </div>
                        
                        <div className="w-3/4">
                          <label className="block text-sm font-medium text-gray-300 mb-2">
                            URL
                          </label>
                          <div className="bg-gray-700 rounded-md py-2 px-3 text-white font-mono text-sm break-all">
                            {getEndpointById(activeCollection, activeEndpoint)?.url}
                          </div>
                        </div>
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">
                          Authentification
                        </label>
                        <div className="bg-gray-700 rounded-md p-3">
                          {getEndpointById(activeCollection, activeEndpoint)?.authentication === 'none' ? (
                            <span className="text-gray-400">Aucune authentification</span>
                          ) : getEndpointById(activeCollection, activeEndpoint)?.authentication === 'basic' ? (
                            <div className="space-y-2">
                              <div className="flex items-center">
                                <span className="text-gray-400 mr-2">Type:</span>
                                <span className="text-white">Basic Auth</span>
                              </div>
                              <div className="flex items-center">
                                <span className="text-gray-400 mr-2">Utilisateur:</span>
                                <span className="text-white">{getEndpointById(activeCollection, activeEndpoint)?.authDetails?.username}</span>
                              </div>
                              <div className="flex items-center">
                                <span className="text-gray-400 mr-2">Mot de passe:</span>
                                <span className="text-white">••••••••</span>
                              </div>
                            </div>
                          ) : getEndpointById(activeCollection, activeEndpoint)?.authentication === 'bearer' ? (
                            <div className="space-y-2">
                              <div className="flex items-center">
                                <span className="text-gray-400 mr-2">Type:</span>
                                <span className="text-white">Bearer Token</span>
                              </div>
                              <div className="flex items-center">
                                <span className="text-gray-400 mr-2">Token:</span>
                                <span className="text-white font-mono text-sm">
                                  {getEndpointById(activeCollection, activeEndpoint)?.authDetails?.token?.substring(0, 25)}...
                                </span>
                              </div>
                            </div>
                          ) : getEndpointById(activeCollection, activeEndpoint)?.authentication === 'api-key' ? (
                            <div className="space-y-2">
                              <div className="flex items-center">
                                <span className="text-gray-400 mr-2">Type:</span>
                                <span className="text-white">API Key</span>
                              </div>
                              <div className="flex items-center">
                                <span className="text-gray-400 mr-2">Emplacement:</span>
                                <span className="text-white">
                                  {getEndpointById(activeCollection, activeEndpoint)?.authDetails?.keyLocation === 'header' ? 'Header' : 'Query Parameter'}
                                </span>
                              </div>
                              <div className="flex items-center">
                                <span className="text-gray-400 mr-2">Nom:</span>
                                <span className="text-white">
                                  {getEndpointById(activeCollection, activeEndpoint)?.authDetails?.keyName}
                                </span>
                              </div>
                              <div className="flex items-center">
                                <span className="text-gray-400 mr-2">Valeur:</span>
                                <span className="text-white">••••••••</span>
                              </div>
                            </div>
                          ) : (
                            <div className="space-y-2">
                              <div className="flex items-center">
                                <span className="text-gray-400 mr-2">Type:</span>
                                <span className="text-white">OAuth 2.0</span>
                              </div>
                              <div className="flex items-center">
                                <span className="text-gray-400 mr-2">Token:</span>
                                <span className="text-white">••••••••</span>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-gray-300 mb-2">
                          Headers
                        </label>
                        {Object.keys(getEndpointById(activeCollection, activeEndpoint)?.headers || {}).length > 0 ? (
                          <div className="bg-gray-700 rounded-md p-3 font-mono text-sm">
                            {Object.entries(getEndpointById(activeCollection, activeEndpoint)?.headers || {}).map(([key, value], index) => (
                              <div key={index} className="flex items-start">
                                <span className="text-violet-400 mr-2">{key}:</span>
                                <span className="text-white">{value}</span>
                              </div>
                            ))}
                          </div>
                        ) : (
                          <div className="text-sm text-gray-500 italic bg-gray-700/50 p-3 rounded-md">
                            Aucun header configuré
                          </div>
                        )}
                      </div>
                      
                      {(getEndpointById(activeCollection, activeEndpoint)?.method === 'POST' || 
                        getEndpointById(activeCollection, activeEndpoint)?.method === 'PUT' || 
                        getEndpointById(activeCollection, activeEndpoint)?.method === 'PATCH') && 
                        getEndpointById(activeCollection, activeEndpoint)?.body && (
                        <div>
                          <label className="block text-sm font-medium text-gray-300 mb-2">
                            Body
                          </label>
                          <div className="bg-gray-700 rounded-md p-3 font-mono text-sm whitespace-pre">
                            {getEndpointById(activeCollection, activeEndpoint)?.body}
                          </div>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="flex space-x-4">
                        <div className="flex flex-col items-center justify-center bg-gray-700 rounded-md p-3 w-32">
                          <div className="text-sm text-gray-400 mb-1">Statut</div>
                          <div>
                            {renderStatusBadge(getEndpointById(activeCollection, activeEndpoint)?.status || 'idle')}
                          </div>
                        </div>
                        
                        <div className="flex flex-col items-center justify-center bg-gray-700 rounded-md p-3 w-32">
                          <div className="text-sm text-gray-400 mb-1">Méthode</div>
                          <div>
                            {renderMethodBadge(getEndpointById(activeCollection, activeEndpoint)?.method || 'GET')}
                          </div>
                        </div>
                        
                        <div className="flex flex-col items-center justify-center bg-gray-700 rounded-md p-3 flex-1">
                          <div className="text-sm text-gray-400 mb-1">Dernière exécution</div>
                          <div className="text-violet-300">
                            {formatDate(getEndpointById(activeCollection, activeEndpoint)?.lastUsed)}
                          </div>
                        </div>
                        
                        <div className="flex flex-col items-center justify-center bg-gray-700 rounded-md p-3 w-32">
                          <div className="text-sm text-gray-400 mb-1">Sécurité</div>
                          <div>
                            {renderAuthBadge(getEndpointById(activeCollection, activeEndpoint)?.authentication || 'none') || (
                              <span className="text-gray-400">Aucune</span>
                            )}
                          </div>
                        </div>
                      </div>
                      
                      <div className="p-3 bg-gray-700 rounded-md">
                        <div className="flex items-center text-sm text-gray-400 mb-2">
                          <Code size={16} className="mr-1" />
                          Requête
                        </div>
                        <div className="font-mono text-sm whitespace-pre overflow-x-auto text-white bg-gray-800 p-3 rounded-md border border-gray-700">
{`${getEndpointById(activeCollection, activeEndpoint)?.method} ${getEndpointById(activeCollection, activeEndpoint)?.url}
${Object.entries(getEndpointById(activeCollection, activeEndpoint)?.headers || {}).map(([key, value]) => `${key}: ${value}`).join('\n')}
${getEndpointById(activeCollection, activeEndpoint)?.authentication === 'bearer' ? 
  `Authorization: Bearer ${getEndpointById(activeCollection, activeEndpoint)?.authDetails?.token?.substring(0, 10)}...` : 
  getEndpointById(activeCollection, activeEndpoint)?.authentication === 'basic' ? 
  `Authorization: Basic {encoded-credentials}` : 
  getEndpointById(activeCollection, activeEndpoint)?.authentication === 'api-key' && getEndpointById(activeCollection, activeEndpoint)?.authDetails?.keyLocation === 'header' ? 
  `${getEndpointById(activeCollection, activeEndpoint)?.authDetails?.keyName}: ${getEndpointById(activeCollection, activeEndpoint)?.authDetails?.apiKey?.substring(0, 5)}...` : 
  ''
}${(getEndpointById(activeCollection, activeEndpoint)?.method === 'POST' || 
    getEndpointById(activeCollection, activeEndpoint)?.method === 'PUT' || 
    getEndpointById(activeCollection, activeEndpoint)?.method === 'PATCH') && 
    getEndpointById(activeCollection, activeEndpoint)?.body ? 
  `\n\n${getEndpointById(activeCollection, activeEndpoint)?.body}` : ''}`}
                        </div>
                      </div>
                      
                      {responseData !== null && (
                        <div className="p-3 bg-gray-700 rounded-md">
                          <div className="flex items-center justify-between text-sm mb-2">
                            <div className="flex items-center text-gray-400">
                              <FileJson size={16} className="mr-1" />
                              Réponse
                            </div>
                            <div className="flex items-center space-x-2">
                              {responseStatus !== null && renderStatusCode(responseStatus)}
                              {responseDuration !== null && (
                                <span className="text-xs text-gray-400">
                                  {responseDuration} ms
                                </span>
                              )}
                            </div>
                          </div>
                          <div className="font-mono text-sm whitespace-pre overflow-x-auto text-white bg-gray-800 p-3 rounded-md border border-gray-700">
                            {responseData}
                          </div>
                        </div>
                      )}
                      
                      {getEndpointById(activeCollection, activeEndpoint)?.responses && getEndpointById(activeCollection, activeEndpoint)?.responses?.length > 0 && (
                        <div className="p-3 bg-gray-700 rounded-md">
                          <div className="flex items-center text-sm text-gray-400 mb-2">
                            <Clock size={16} className="mr-1" />
                            Historique des réponses
                          </div>
                          
                          <div className="space-y-2">
                            {getEndpointById(activeCollection, activeEndpoint)?.responses?.slice(0, 3).map((response, index) => (
                              <div key={index} className="flex items-center justify-between bg-gray-800 p-2 rounded-md">
                                <div className="flex items-center">
                                  {renderStatusCode(response.status)}
                                  <span className="ml-2 text-xs text-gray-400">{formatDate(response.timestamp)}</span>
                                </div>
                                <div className="flex items-center">
                                  <span className="text-xs text-gray-400 mr-2">{response.duration} ms</span>
                                  <button className="text-violet-400 hover:text-violet-300 text-xs">
                                    Voir détails
                                  </button>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-center">
            <Code size={64} className="text-violet-500/50 mb-4" />
            <h3 className="text-xl font-semibold mb-2 text-violet-100">Gestionnaire d'API</h3>
            <p className="text-gray-400 mb-4 max-w-md">
              Connectez-vous à différentes API et services pour envoyer des requêtes, tester des endpoints et automatiser vos flux de travail.
            </p>
            <p className="text-gray-400 max-w-md">
              Sélectionnez une collection puis un endpoint dans la liste à gauche pour commencer.
            </p>
            
            <div className="mt-6 grid grid-cols-3 gap-4 text-center">
              <div className="bg-gray-800 p-4 rounded-lg border border-violet-900/50">
                <Server size={24} className="text-violet-400 mx-auto mb-2" />
                <h4 className="font-semibold text-violet-100 mb-1">APIs RESTful</h4>
                <p className="text-xs text-gray-400">Connectez-vous à n'importe quelle API REST</p>
              </div>
              
              <div className="bg-gray-800 p-4 rounded-lg border border-violet-900/50">
                <Database size={24} className="text-violet-400 mx-auto mb-2" />
                <h4 className="font-semibold text-violet-100 mb-1">Bases de données</h4>
                <p className="text-xs text-gray-400">Exécutez des requêtes sur vos BDD</p>
              </div>
              
              <div className="bg-gray-800 p-4 rounded-lg border border-violet-900/50">
                <Lock size={24} className="text-violet-400 mx-auto mb-2" />
                <h4 className="font-semibold text-violet-100 mb-1">Sécurité {securityLevel}</h4>
                <p className="text-xs text-gray-400">Niveau de chiffrement avancé pour vos connexions</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};