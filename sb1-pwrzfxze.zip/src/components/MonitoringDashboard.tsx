import React, { useState, useEffect } from 'react';
import { Activity, AlertTriangle, Check, Download, RefreshCw, Search, Shield, Cpu, Server, BarChart, Clock, Filter, Save, Trash } from 'lucide-react';
import { getLogs, LogLevel, getLogCounts, LogEntry, clearLogs } from '../utils/logger';

type MonitoringDashboardProps = {
  securityLevel: 'standard' | 'high' | 'extreme';
};

export const MonitoringDashboard: React.FC<MonitoringDashboardProps> = ({ securityLevel }) => {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [filteredLogs, setFilteredLogs] = useState<LogEntry[]>([]);
  const [logCounts, setLogCounts] = useState<Record<LogLevel, number>>({
    [LogLevel.ERROR]: 0,
    [LogLevel.WARNING]: 0,
    [LogLevel.INFO]: 0,
    [LogLevel.DEBUG]: 0,
    [LogLevel.SUCCESS]: 0
  });
  const [filter, setFilter] = useState<{
    search: string;
    levels: LogLevel[];
    timeRange: '1h' | '24h' | '7d' | 'all';
    component?: string;
  }>({
    search: '',
    levels: [LogLevel.ERROR, LogLevel.WARNING, LogLevel.INFO, LogLevel.SUCCESS],
    timeRange: '24h'
  });
  const [systemStats, setSystemStats] = useState({
    cpuUsage: 25,
    memoryUsage: 512,
    totalMemory: 1024,
    uptime: 72, // hours
    activeRequests: 12,
    avgResponseTime: 85 // ms
  });
  const [refreshInterval, setRefreshInterval] = useState<number>(10); // seconds
  const [isAutoRefreshEnabled, setIsAutoRefreshEnabled] = useState<boolean>(true);
  const [isExporting, setIsExporting] = useState<boolean>(false);
  
  // Simulated system components
  const [components] = useState([
    { name: 'API Gateway', status: 'healthy', latency: 12 },
    { name: 'Terminal Service', status: 'healthy', latency: 15 },
    { name: 'Database', status: 'healthy', latency: 40 },
    { name: 'Authentication', status: 'healthy', latency: 20 },
    { name: 'File Storage', status: 'degraded', latency: 150 }
  ]);

  // Fetch logs initially and set up interval for auto-refresh
  useEffect(() => {
    refreshLogs();
    
    // Simulate changing system stats
    const statsInterval = setInterval(() => {
      setSystemStats(prev => ({
        ...prev,
        cpuUsage: Math.floor(Math.random() * 15) + 20, // 20-35%
        memoryUsage: Math.floor(Math.random() * 100) + 460, // 460-560 MB
        activeRequests: Math.floor(Math.random() * 10) + 8, // 8-18
        avgResponseTime: Math.floor(Math.random() * 20) + 75 // 75-95ms
      }));
    }, 5000);
    
    // Set up auto-refresh interval
    let refreshIntervalId: number;
    
    const updateRefreshInterval = () => {
      if (refreshIntervalId) {
        clearInterval(refreshIntervalId);
      }
      
      if (isAutoRefreshEnabled) {
        refreshIntervalId = window.setInterval(() => {
          refreshLogs();
        }, refreshInterval * 1000);
      }
    };
    
    updateRefreshInterval();
    
    // Clean up intervals on unmount
    return () => {
      clearInterval(statsInterval);
      clearInterval(refreshIntervalId);
    };
  }, [refreshInterval, isAutoRefreshEnabled]);
  
  // Apply filters when logs or filter criteria change
  useEffect(() => {
    applyFilters();
  }, [logs, filter]);
  
  // Refresh logs from the logger service
  const refreshLogs = () => {
    const allLogs = getLogs();
    setLogs(allLogs);
    setLogCounts(getLogCounts());
  };
  
  // Apply filters to the logs
  const applyFilters = () => {
    // Start with all logs
    let filtered = [...logs];
    
    // Apply level filter
    if (filter.levels.length > 0) {
      filtered = filtered.filter(log => filter.levels.includes(log.level));
    }
    
    // Apply time range filter
    if (filter.timeRange !== 'all') {
      const now = new Date();
      let cutoff = new Date();
      
      switch (filter.timeRange) {
        case '1h':
          cutoff.setHours(now.getHours() - 1);
          break;
        case '24h':
          cutoff.setHours(now.getHours() - 24);
          break;
        case '7d':
          cutoff.setDate(now.getDate() - 7);
          break;
      }
      
      filtered = filtered.filter(log => new Date(log.timestamp) >= cutoff);
    }
    
    // Apply component filter
    if (filter.component) {
      filtered = filtered.filter(log => log.component === filter.component);
    }
    
    // Apply search filter (case insensitive)
    if (filter.search.trim() !== '') {
      const searchLower = filter.search.toLowerCase();
      filtered = filtered.filter(log => 
        log.message.toLowerCase().includes(searchLower) || 
        (log.details && JSON.stringify(log.details).toLowerCase().includes(searchLower))
      );
    }
    
    setFilteredLogs(filtered);
  };
  
  // Toggle a log level in the filter
  const toggleLogLevel = (level: LogLevel) => {
    if (filter.levels.includes(level)) {
      // Remove the level if it's already in the filter
      setFilter({
        ...filter,
        levels: filter.levels.filter(l => l !== level)
      });
    } else {
      // Add the level if it's not in the filter
      setFilter({
        ...filter,
        levels: [...filter.levels, level]
      });
    }
  };
  
  // Export logs to JSON file
  const exportLogs = () => {
    setIsExporting(true);
    
    try {
      // Create a JSON blob
      const data = JSON.stringify(filteredLogs, null, 2);
      const blob = new Blob([data], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      
      // Create a link element and trigger download
      const link = document.createElement('a');
      link.href = url;
      link.download = `wmterminal_logs_${new Date().toISOString().slice(0, 10)}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      // Clean up
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error exporting logs:', error);
    } finally {
      setIsExporting(false);
    }
  };
  
  // Format date for display
  const formatDate = (dateStr: string) => {
    const date = new Date(dateStr);
    return date.toLocaleString();
  };
  
  // Get icon for log level
  const getLogLevelIcon = (level: LogLevel) => {
    switch (level) {
      case LogLevel.ERROR:
        return <AlertTriangle size={16} className="text-red-400" />;
      case LogLevel.WARNING:
        return <AlertTriangle size={16} className="text-yellow-400" />;
      case LogLevel.INFO:
        return <Activity size={16} className="text-blue-400" />;
      case LogLevel.DEBUG:
        return <Activity size={16} className="text-gray-400" />;
      case LogLevel.SUCCESS:
        return <Check size={16} className="text-green-400" />;
      default:
        return <Activity size={16} className="text-gray-400" />;
    }
  };
  
  // Clear all logs
  const handleClearLogs = () => {
    if (window.confirm('Êtes-vous sûr de vouloir effacer tous les logs ? Cette action est irréversible.')) {
      clearLogs();
      refreshLogs();
    }
  };
  
  return (
    <div className="flex-1 overflow-hidden flex flex-col bg-gray-900">
      <div className="bg-gray-800 p-4 border-b border-violet-900">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <Activity size={24} className="mr-2 text-violet-400" />
            <h2 className="text-xl font-semibold text-violet-100">Monitoring & Logs</h2>
          </div>
          
          <div className="flex items-center space-x-2">
            <button
              onClick={refreshLogs}
              className="px-3 py-1 bg-gray-700 hover:bg-gray-600 text-white rounded-md text-sm flex items-center"
            >
              <RefreshCw size={14} className="mr-1" />
              Actualiser
            </button>
            
            <button
              onClick={exportLogs}
              disabled={isExporting}
              className="px-3 py-1 bg-violet-600 hover:bg-violet-700 text-white rounded-md text-sm flex items-center disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isExporting ? (
                <>
                  <div className="mr-1 w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  Export...
                </>
              ) : (
                <>
                  <Download size={14} className="mr-1" />
                  Exporter
                </>
              )}
            </button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-gray-700 rounded-lg p-3 flex items-center">
            <div className="bg-violet-900/30 p-2 rounded-md mr-3">
              <Cpu size={20} className="text-violet-400" />
            </div>
            <div>
              <div className="text-sm text-gray-400 mb-1">Utilisation CPU</div>
              <div className="text-lg font-semibold flex items-center">
                {systemStats.cpuUsage}%
                <div className="ml-2 bg-gray-600 h-1.5 w-24 rounded-full overflow-hidden">
                  <div 
                    className={`h-full rounded-full ${
                      systemStats.cpuUsage > 70 ? 'bg-red-500' : 
                      systemStats.cpuUsage > 50 ? 'bg-yellow-500' : 
                      'bg-green-500'
                    }`}
                    style={{width: `${systemStats.cpuUsage}%`}}
                  ></div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-gray-700 rounded-lg p-3 flex items-center">
            <div className="bg-violet-900/30 p-2 rounded-md mr-3">
              <Server size={20} className="text-violet-400" />
            </div>
            <div>
              <div className="text-sm text-gray-400 mb-1">Mémoire</div>
              <div className="text-lg font-semibold flex items-center">
                {systemStats.memoryUsage} MB / {systemStats.totalMemory} MB
                <div className="ml-2 bg-gray-600 h-1.5 w-24 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-violet-500 rounded-full"
                    style={{width: `${(systemStats.memoryUsage / systemStats.totalMemory) * 100}%`}}
                  ></div>
                </div>
              </div>
            </div>
          </div>
          
          <div className="bg-gray-700 rounded-lg p-3 flex items-center">
            <div className="bg-violet-900/30 p-2 rounded-md mr-3">
              <BarChart size={20} className="text-violet-400" />
            </div>
            <div>
              <div className="text-sm text-gray-400 mb-1">Requêtes actives</div>
              <div className="text-lg font-semibold flex items-center">
                {systemStats.activeRequests}
                <span className="ml-2 text-xs text-gray-400">
                  (~{systemStats.avgResponseTime}ms)
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="p-4 bg-gray-800 border-b border-gray-700">
        <div className="flex flex-col md:flex-row space-y-3 md:space-y-0 md:space-x-4">
          <div className="flex-1">
            <div className="relative">
              <input
                type="text"
                value={filter.search}
                onChange={(e) => setFilter({ ...filter, search: e.target.value })}
                placeholder="Rechercher dans les logs..."
                className="w-full bg-gray-700 border border-gray-600 rounded-md py-2 pl-9 pr-3 text-white focus:border-violet-500 focus:ring focus:ring-violet-500 focus:ring-opacity-50"
              />
              <Search size={16} className="absolute left-3 top-3 text-gray-400" />
            </div>
          </div>
          
          <div className="flex space-x-2 md:space-x-4 items-center">
            <div>
              <select
                value={filter.timeRange}
                onChange={(e) => setFilter({ ...filter, timeRange: e.target.value as any })}
                className="bg-gray-700 border border-gray-600 rounded-md py-2 px-3 text-white focus:border-violet-500 focus:ring focus:ring-violet-500 focus:ring-opacity-50"
              >
                <option value="1h">1 heure</option>
                <option value="24h">24 heures</option>
                <option value="7d">7 jours</option>
                <option value="all">Tous</option>
              </select>
            </div>
            
            <div className="flex space-x-1">
              {Object.values(LogLevel).map(level => (
                <button
                  key={level}
                  onClick={() => toggleLogLevel(level)}
                  className={`px-2 py-1 rounded text-xs flex items-center ${
                    filter.levels.includes(level)
                      ? level === LogLevel.ERROR ? 'bg-red-900/50 text-red-300' :
                        level === LogLevel.WARNING ? 'bg-yellow-900/50 text-yellow-300' :
                        level === LogLevel.INFO ? 'bg-blue-900/50 text-blue-300' :
                        level === LogLevel.DEBUG ? 'bg-gray-700 text-gray-300' :
                        'bg-green-900/50 text-green-300'
                      : 'bg-gray-700/50 text-gray-500'
                  }`}
                >
                  {getLogLevelIcon(level)}
                  <span className="ml-1 uppercase">{level}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
        
        <div className="flex items-center justify-between mt-4">
          <div className="flex space-x-2">
            <div className="px-2 py-1 bg-gray-700 rounded-md text-sm text-gray-300 flex items-center">
              <Filter size={14} className="mr-1" />
              <span>{filteredLogs.length} entrées</span>
            </div>
            
            <button
              onClick={handleClearLogs}
              className="px-2 py-1 bg-red-900/20 text-red-400 hover:bg-red-900/30 rounded-md text-sm flex items-center"
            >
              <Trash size={14} className="mr-1" />
              Effacer les logs
            </button>
          </div>
          
          <div className="flex items-center space-x-2">
            <div className="text-sm text-gray-400">Actualisation:</div>
            <select
              value={refreshInterval}
              onChange={(e) => setRefreshInterval(Number(e.target.value))}
              disabled={!isAutoRefreshEnabled}
              className="bg-gray-700 border border-gray-600 rounded-md text-white text-sm py-1 px-2 disabled:opacity-50"
            >
              <option value="5">5s</option>
              <option value="10">10s</option>
              <option value="30">30s</option>
              <option value="60">60s</option>
            </select>
            
            <div className="flex items-center">
              <input 
                type="checkbox" 
                id="auto-refresh" 
                checked={isAutoRefreshEnabled}
                onChange={() => setIsAutoRefreshEnabled(!isAutoRefreshEnabled)}
                className="mr-2 accent-violet-600"
              />
              <label htmlFor="auto-refresh" className="text-sm text-gray-300">
                Auto
              </label>
            </div>
          </div>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto">
        <div className="grid grid-cols-1 md:grid-cols-5 h-full">
          <div className="col-span-3 overflow-y-auto border-r border-gray-700">
            <div className="p-4">
              <h3 className="text-md font-semibold text-violet-100 mb-4 flex items-center">
                <Activity size={18} className="mr-2 text-violet-400" />
                Journal d'événements
              </h3>
              
              {filteredLogs.length === 0 ? (
                <div className="text-center py-8">
                  <Activity size={48} className="text-gray-600 mx-auto mb-4" />
                  <p className="text-gray-400">Aucun log correspondant aux critères actuels</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {filteredLogs.map((log, index) => (
                    <div 
                      key={index}
                      className="bg-gray-800 rounded-md p-3 hover:bg-gray-750 cursor-pointer"
                    >
                      <div className="flex items-start">
                        <div className="mr-2 mt-0.5">
                          {getLogLevelIcon(log.level)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex justify-between items-start">
                            <p className="font-medium text-white truncate">{log.message}</p>
                            <span className="text-xs text-gray-400 whitespace-nowrap ml-2">
                              {formatDate(log.timestamp)}
                            </span>
                          </div>
                          {log.component && (
                            <div className="text-xs text-violet-400 mt-1">
                              {log.component}
                            </div>
                          )}
                          {log.details && Object.keys(log.details).length > 0 && (
                            <details className="mt-2">
                              <summary className="text-xs text-gray-400 cursor-pointer hover:text-gray-300">
                                Détails
                              </summary>
                              <pre className="mt-2 text-xs bg-gray-700 p-2 rounded-md overflow-x-auto text-gray-300">
                                {JSON.stringify(log.details, null, 2)}
                              </pre>
                            </details>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
          
          <div className="col-span-2 overflow-y-auto bg-gray-850">
            <div className="p-4">
              <h3 className="text-md font-semibold text-violet-100 mb-4 flex items-center">
                <Server size={18} className="mr-2 text-violet-400" />
                État du système
              </h3>
              
              <div className="bg-gray-800 rounded-md p-4 mb-4 border border-gray-700">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium text-white">Aperçu</h4>
                  <span className="text-xs text-gray-400 flex items-center">
                    <Clock size={12} className="mr-1" />
                    Uptime: {Math.floor(systemStats.uptime / 24)}j {systemStats.uptime % 24}h
                  </span>
                </div>
                
                <div className="grid grid-cols-2 gap-4 mt-4">
                  <div className="bg-gray-700 rounded p-2">
                    <div className="text-xs text-gray-400">Niveau de sécurité</div>
                    <div className="flex items-center mt-1">
                      <Shield size={14} className={`mr-1 ${
                        securityLevel === 'extreme' ? 'text-violet-400' :
                        securityLevel === 'high' ? 'text-purple-400' :
                        'text-blue-400'
                      }`} />
                      <span className="capitalize">
                        {securityLevel === 'extreme' ? 'Extrême' :
                         securityLevel === 'high' ? 'Haute' :
                         'Standard'}
                      </span>
                    </div>
                  </div>
                  
                  <div className="bg-gray-700 rounded p-2">
                    <div className="text-xs text-gray-400">Erreurs (24h)</div>
                    <div className="flex items-center mt-1">
                      <AlertTriangle size={14} className={`mr-1 ${
                        logCounts.error > 10 ? 'text-red-400' :
                        logCounts.error > 0 ? 'text-yellow-400' :
                        'text-green-400'
                      }`} />
                      <span>
                        {logCounts.error}
                        {logCounts.error > 0 && (
                          <span className="ml-1 text-xs text-gray-400">
                            ({logCounts.warning} avert.)
                          </span>
                        )}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
              
              <h4 className="font-medium text-white mb-3 mt-6">Composants du système</h4>
              
              <div className="space-y-3">
                {components.map((component) => (
                  <div key={component.name} className="bg-gray-800 rounded-md p-3 border border-gray-700 flex items-center justify-between">
                    <div className="flex items-center">
                      <div className={`w-2 h-2 rounded-full mr-2 ${
                        component.status === 'healthy' ? 'bg-green-500' :
                        component.status === 'degraded' ? 'bg-yellow-500' :
                        'bg-red-500'
                      }`}></div>
                      <span className="font-medium text-white">{component.name}</span>
                    </div>
                    <div className="flex items-center text-sm">
                      <span className={`mr-2 ${
                        component.latency < 50 ? 'text-green-400' :
                        component.latency < 100 ? 'text-blue-400' :
                        'text-yellow-400'
                      }`}>
                        {component.latency}ms
                      </span>
                      <span className={`uppercase text-xs px-1.5 py-0.5 rounded ${
                        component.status === 'healthy' ? 'bg-green-900/30 text-green-400' :
                        component.status === 'degraded' ? 'bg-yellow-900/30 text-yellow-400' :
                        'bg-red-900/30 text-red-400'
                      }`}>
                        {component.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
              
              <h4 className="font-medium text-white mb-3 mt-6">Statistiques des logs</h4>
              
              <div className="grid grid-cols-5 gap-2">
                {Object.entries(logCounts).map(([level, count]) => (
                  <div key={level} className={`p-3 rounded-md ${
                    level === 'error' ? 'bg-red-900/30' :
                    level === 'warning' ? 'bg-yellow-900/30' :
                    level === 'info' ? 'bg-blue-900/30' :
                    level === 'debug' ? 'bg-gray-700' :
                    'bg-green-900/30'
                  }`}>
                    <div className="text-xs text-gray-400 uppercase">{level}</div>
                    <div className={`text-lg font-semibold ${
                      level === 'error' ? 'text-red-300' :
                      level === 'warning' ? 'text-yellow-300' :
                      level === 'info' ? 'text-blue-300' :
                      level === 'debug' ? 'text-gray-300' :
                      'text-green-300'
                    }`}>
                      {count}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MonitoringDashboard;