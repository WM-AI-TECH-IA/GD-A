import React, { useState, useEffect } from 'react';
import { Shield, Check, AlertTriangle, Copy, Check as CheckIcon, Smartphone } from 'lucide-react';
import QRCode from 'qrcode';
import { authenticator } from 'otplib';
import { supabase } from '../utils/supabaseClient';
import { encryptData } from '../utils/security';
import { addLogEntry, LogLevel } from '../utils/logger';

type TwoFactorSetupProps = {
  userId: string;
  onComplete: (enabled: boolean) => void;
  securityLevel: 'standard' | 'high' | 'extreme';
};

export const TwoFactorSetup: React.FC<TwoFactorSetupProps> = ({ userId, onComplete, securityLevel }) => {
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [qrCodeUrl, setQrCodeUrl] = useState<string>('');
  const [secret, setSecret] = useState<string>('');
  const [token, setToken] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [isEnabled, setIsEnabled] = useState<boolean>(false);
  
  // Check if 2FA is already enabled
  useEffect(() => {
    const check2FAStatus = async () => {
      setLoading(true);
      try {
        // In a real app, this would check if 2FA is already enabled for the user
        // For demo purposes, we'll assume it's not enabled
        const { data, error } = await supabase
          .from('user_profiles')
          .select('two_factor_enabled')
          .eq('user_id', userId)
          .single();
          
        if (error) throw error;

        if (data && data.two_factor_enabled) {
          setIsEnabled(true);
          addLogEntry(LogLevel.INFO, '2FA is already enabled for user', { userId });
        }
      } catch (error) {
        console.error('Error checking 2FA status:', error);
        // For demo, we'll just continue with the flow
      } finally {
        setLoading(false);
      }
    };
    
    check2FAStatus();
  }, [userId]);
  
  // Generate secret and QR code when component mounts
  useEffect(() => {
    if (isEnabled) return;
    
    const generateSecret = () => {
      try {
        // Generate a random secret
        let newSecret: string;
        if (typeof window !== 'undefined' && window.crypto && window.crypto.getRandomValues) {
          // Browser environment
          newSecret = authenticator.generateSecret();
        } else {
          throw new Error("crypto.getRandomValues is not supported in this environment");
        }
        
        setSecret(newSecret);
        
        // Create the URI for the QR code
        const appName = 'WM Terminal Cloud';
        const accountName = `user@example.com`; // In real app, use user's email
        const otpauth = authenticator.keyuri(accountName, appName, newSecret);
        
        // Generate QR code
        QRCode.toDataURL(otpauth, { errorCorrectionLevel: 'M' })
          .then((url) => {
            setQrCodeUrl(url);
          })
          .catch((err) => {
            console.error('Error generating QR code:', err);
            setError('Erreur lors de la génération du QR code. Veuillez réessayer.');
          });
        
        addLogEntry(LogLevel.INFO, '2FA setup initiated', { userId });
      } catch (error) {
        console.error('Error generating 2FA secret:', error);
        setError('Erreur lors de la génération du secret 2FA. Veuillez réessayer.');
        addLogEntry(LogLevel.ERROR, 'Failed to generate 2FA secret', { 
          userId, 
          error: String(error) 
        });
      }
    };
    
    generateSecret();
  }, [userId, isEnabled]);
  
  const verifyToken = async () => {
    if (!token || token.length !== 6 || !/^\d+$/.test(token)) {
      setError('Veuillez entrer un code à 6 chiffres valide');
      return;
    }
    
    setLoading(true);
    setError(null);
    
    try {
      // Verify the token
      const isValid = authenticator.verify({ token, secret });
      
      if (isValid) {
        // In a real app, this would save the secret to the user's profile in the database
        // For demo purposes, we'll simulate the save
        
        // Encrypt the secret before storing it (in a real app)
        const encryptedSecret = await encryptData(secret);
        
        const { error } = await supabase
          .from('user_profiles')
          .upsert({
            user_id: userId,
            two_factor_enabled: true,
            two_factor_secret: 'dummy_secret_for_demo', // In real app, use encryptedSecret
            updated_at: new Date().toISOString()
          });
          
        if (error) throw error;
        
        setStep(3); // Success step
        setIsEnabled(true);
        onComplete(true); // Notify parent component that 2FA is enabled
        addLogEntry(LogLevel.SUCCESS, '2FA successfully enabled for user', { userId });
      } else {
        setError('Code invalide. Veuillez réessayer.');
        addLogEntry(LogLevel.WARNING, 'Invalid 2FA verification attempt', { userId });
      }
    } catch (error) {
      console.error('Error verifying token:', error);
      setError('Erreur lors de la vérification du code. Veuillez réessayer.');
      addLogEntry(LogLevel.ERROR, 'Error during 2FA verification', { 
        userId, 
        error: String(error) 
      });
    } finally {
      setLoading(false);
    }
  };
  
  const copySecretToClipboard = () => {
    navigator.clipboard.writeText(secret).then(() => {
      // Show a temporary tooltip or indicator
      const tempEl = document.getElementById('copy-success');
      if (tempEl) {
        tempEl.classList.remove('hidden');
        setTimeout(() => {
          tempEl.classList.add('hidden');
        }, 2000);
      }
    }).catch(err => {
      console.error('Failed to copy:', err);
    });
  };
  
  const disable2FA = async () => {
    if (!window.confirm('Êtes-vous sûr de vouloir désactiver l\'authentification à deux facteurs ? Cela réduira la sécurité de votre compte.')) {
      return;
    }
    
    setLoading(true);
    setError(null);
    
    try {
      // In a real app, this would disable 2FA in the database
      const { error } = await supabase
        .from('user_profiles')
        .update({
          two_factor_enabled: false,
          two_factor_secret: null,
          updated_at: new Date().toISOString()
        })
        .eq('user_id', userId);
        
      if (error) throw error;
      
      setIsEnabled(false);
      onComplete(false); // Notify parent component that 2FA is disabled
      addLogEntry(LogLevel.WARNING, '2FA disabled for user', { userId });
    } catch (error) {
      console.error('Error disabling 2FA:', error);
      setError('Erreur lors de la désactivation de l\'authentification à deux facteurs. Veuillez réessayer.');
      addLogEntry(LogLevel.ERROR, 'Error disabling 2FA', { 
        userId, 
        error: String(error) 
      });
    } finally {
      setLoading(false);
    }
  };
  
  if (loading && !qrCodeUrl) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-violet-500"></div>
      </div>
    );
  }
  
  if (isEnabled) {
    return (
      <div className="bg-gray-800 rounded-lg p-6 border border-violet-900/50 max-w-md mx-auto">
        <div className="flex items-center justify-center mb-6 text-green-400">
          <div className="bg-green-900/30 p-3 rounded-full">
            <Check size={24} />
          </div>
        </div>
        
        <h3 className="text-xl font-semibold mb-4 text-center text-violet-100">
          Authentification à deux facteurs activée
        </h3>
        
        <p className="text-gray-300 mb-6 text-center">
          Votre compte est protégé par l'authentification à deux facteurs. Lors de votre prochaine connexion, vous devrez entrer un code de vérification en plus de votre mot de passe.
        </p>
        
        <div className="space-y-4">
          <div className="bg-gray-700 p-4 rounded-md">
            <h4 className="font-medium text-white mb-2">Conseils de sécurité</h4>
            <ul className="text-sm text-gray-300 space-y-1 list-disc pl-5">
              <li>Conservez votre application d'authentification sur un appareil sécurisé.</li>
              <li>Enregistrez vos codes de récupération dans un endroit sûr.</li>
              <li>Ne partagez jamais vos codes d'authentification avec qui que ce soit.</li>
            </ul>
          </div>
          
          <button
            onClick={disable2FA}
            className="w-full py-2 bg-red-600/70 hover:bg-red-600 text-white rounded-md flex items-center justify-center"
          >
            Désactiver l'authentification à deux facteurs
          </button>
        </div>
      </div>
    );
  }
  
  return (
    <div className="bg-gray-800 rounded-lg p-6 border border-violet-900/50 max-w-md mx-auto">
      <div className="flex items-center justify-center mb-6">
        <Shield size={48} className={`
          ${securityLevel === 'extreme' ? 'text-violet-500' : 
            securityLevel === 'high' ? 'text-purple-500' : 
            'text-blue-500'}
        `} />
      </div>
      
      <h3 className="text-xl font-semibold mb-2 text-center text-violet-100">
        Configuration de l'authentification à deux facteurs
      </h3>
      
      <p className="text-gray-400 mb-6 text-center">
        Sécurisez votre compte avec une couche supplémentaire de protection
      </p>
      
      {error && (
        <div className="mb-4 p-3 bg-red-900/30 border border-red-700 rounded-md text-white flex items-start">
          <AlertTriangle size={18} className="mr-2 mt-0.5 flex-shrink-0" />
          <p>{error}</p>
        </div>
      )}
      
      <div className="space-y-6">
        {step === 1 && (
          <>
            <div className="space-y-4">
              <div className="p-4 bg-gray-700 rounded-md">
                <h4 className="font-medium text-white mb-2">Étape 1: Scanner le QR code</h4>
                <p className="text-sm text-gray-300 mb-4">
                  Utilisez une application d'authentification comme Google Authenticator, Authy ou Microsoft Authenticator pour scanner ce QR code.
                </p>
                
                <div className="flex justify-center bg-white p-4 rounded-md">
                  {qrCodeUrl && (
                    <img src={qrCodeUrl} alt="QR Code pour 2FA" className="w-48 h-48" />
                  )}
                </div>
                
                <div className="mt-4 text-center">
                  <p className="text-sm text-gray-400 mb-1">Ou entrez ce code manuellement:</p>
                  <div className="relative">
                    <div className="font-mono bg-gray-800 p-2 rounded text-violet-300 text-center">
                      {secret}
                    </div>
                    <button 
                      onClick={copySecretToClipboard}
                      className="absolute right-2 top-2 text-gray-400 hover:text-violet-400"
                    >
                      <Copy size={16} />
                    </button>
                    <div id="copy-success" className="hidden absolute right-8 top-2 text-green-400 text-xs">
                      <CheckIcon size={16} />
                    </div>
                  </div>
                </div>
              </div>
              
              <button
                onClick={() => setStep(2)}
                className="w-full py-2 bg-violet-600 hover:bg-violet-700 text-white rounded-md"
              >
                J'ai scanné le QR code
              </button>
            </div>
          </>
        )}
        
        {step === 2 && (
          <>
            <div className="space-y-4">
              <div className="p-4 bg-gray-700 rounded-md">
                <h4 className="font-medium text-white mb-2">Étape 2: Entrez le code</h4>
                <p className="text-sm text-gray-300 mb-4">
                  Entrez le code à 6 chiffres généré par votre application d'authentification.
                </p>
                
                <div className="flex items-center justify-center mb-2">
                  <Smartphone size={24} className="text-violet-400 mr-2" />
                  <input
                    type="text"
                    maxLength={6}
                    value={token}
                    onChange={(e) => setToken(e.target.value.replace(/[^0-9]/g, ''))}
                    placeholder="000000"
                    className="bg-gray-800 border border-gray-600 rounded-md py-2 px-3 text-center text-white text-xl tracking-widest font-mono w-40 focus:border-violet-500 focus:ring focus:ring-violet-500 focus:ring-opacity-50"
                  />
                </div>
                <p className="text-xs text-gray-400 text-center">
                  Le code expire dans quelques secondes
                </p>
              </div>
              
              <div className="flex space-x-2">
                <button
                  onClick={() => setStep(1)}
                  className="flex-1 py-2 bg-gray-700 hover:bg-gray-600 text-white rounded-md"
                >
                  Retour
                </button>
                <button
                  onClick={verifyToken}
                  disabled={loading || !token || token.length !== 6}
                  className="flex-1 py-2 bg-violet-600 hover:bg-violet-700 text-white rounded-md disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
                >
                  {loading ? (
                    <>
                      <div className="mr-2 w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      Vérification...
                    </>
                  ) : (
                    'Vérifier'
                  )}
                </button>
              </div>
            </div>
          </>
        )}
        
        {step === 3 && (
          <>
            <div className="flex items-center justify-center mb-4 text-green-400">
              <div className="bg-green-900/30 p-3 rounded-full">
                <Check size={24} />
              </div>
            </div>
            
            <h4 className="text-lg font-medium text-center text-green-400 mb-4">
              Authentification à deux facteurs activée avec succès!
            </h4>
            
            <p className="text-gray-300 mb-6 text-center">
              Votre compte est maintenant protégé par une couche supplémentaire de sécurité. Lors de votre prochaine connexion, vous devrez entrer un code de vérification en plus de votre mot de passe.
            </p>
            
            <button
              onClick={() => onComplete(true)}
              className="w-full py-2 bg-violet-600 hover:bg-violet-700 text-white rounded-md"
            >
              Terminer
            </button>
          </>
        )}
      </div>
    </div>
  );
};