import React, { useState, useRef, useEffect } from 'react';
import { Terminal } from './components/Terminal';
import { Sidebar } from './components/Sidebar';
import { Settings } from './components/Settings';
import { CloudConnection } from './components/CloudConnection';
import { ApiManager } from './components/ApiManager';
import { Repository } from './components/Repository';
import { ApiGateway } from './components/ApiGateway';
import { UpdateManager } from './components/UpdateManager';
import { BackupManager } from './components/BackupManager';
import { MonitoringDashboard } from './components/MonitoringDashboard';
import { Login } from './components/Login';
import { Terminal as TerminalIcon, Cloud, Settings as SettingsIcon, Shield, Download, Code, Archive, Key, RefreshCw, Database, Activity } from 'lucide-react';
import { setupAntiDebugging, setupAntiTampering } from './utils/security';
import { setSystemSecurityLevel } from './services/updateService';
import { addLogEntry, LogLevel } from './utils/logger';

function App() {
  const [authenticated, setAuthenticated] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'terminal' | 'cloud' | 'settings' | 'api' | 'repository' | 'gateway' | 'updates' | 'backup' | 'monitoring'>('terminal');
  const [isMobile, setIsMobile] = useState<boolean>(false);
  const [securityLevel, setSecurityLevel] = useState<'standard' | 'high' | 'extreme'>('high');
  const [connectionStatus, setConnectionStatus] = useState<'disconnected' | 'connecting' | 'connected'>('disconnected');
  const [userId, setUserId] = useState<string>('');

  // Set up security measures
  useEffect(() => {
    if (process.env.NODE_ENV === 'production') {
      setupAntiDebugging();
      setupAntiTampering();
    }
    
    // Initialize logger
    addLogEntry(LogLevel.INFO, 'Application initialized', { securityLevel });
  }, []);

  // Check if device is mobile
  useEffect(() => {
    const checkIfMobile = () => {
      setIsMobile(window.innerWidth <= 768);
    };
    
    checkIfMobile();
    window.addEventListener('resize', checkIfMobile);
    
    return () => window.removeEventListener('resize', checkIfMobile);
  }, []);

  // Update security level in the update service when changed
  useEffect(() => {
    setSystemSecurityLevel(securityLevel);
    addLogEntry(LogLevel.INFO, 'Security level changed', { level: securityLevel });
  }, [securityLevel]);

  // Handle successful authentication
  const handleAuthenticated = () => {
    setAuthenticated(true);
    addLogEntry(LogLevel.SUCCESS, 'User authenticated successfully');
    
    // In a real app, we would get the actual user ID here
    setUserId(crypto.randomUUID());
  };

  // Function to refresh logs
  const refreshLogs = () => {
    console.log("Refreshing logs...");
    // In a real app with the MonitoringDashboard component, we would call its refreshLogs method
    addLogEntry(LogLevel.INFO, 'Logs refreshed manually');
  };
  
  // Handle security level change
  const handleSecurityLevelChange = (level: 'standard' | 'high' | 'extreme') => {
    setSecurityLevel(level);
  };

  return (
    <div className="flex flex-col h-screen bg-gray-900 text-white">
      {!authenticated ? (
        <Login onAuthenticated={handleAuthenticated} securityLevel={securityLevel} />
      ) : (
        <>
          <header className="bg-gray-800 p-3 flex items-center justify-between border-b border-violet-800">
            <div className="flex items-center space-x-2">
              <TerminalIcon size={24} className="text-violet-400" />
              <h1 className="text-xl font-bold text-violet-100">WM Terminal Cloud</h1>
            </div>
            <div className="flex items-center space-x-2">
              <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                securityLevel === 'extreme' ? 'bg-violet-900 text-violet-300' : 
                securityLevel === 'high' ? 'bg-purple-900 text-purple-300' : 
                'bg-red-900 text-red-300'
              }`}>
                <Shield size={14} className="mr-1" />
                {securityLevel === 'extreme' ? 'Sécurité Extrême' : 
                 securityLevel === 'high' ? 'Haute Sécurité' : 'Sécurité Standard'}
              </span>
              <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                connectionStatus === 'connected' ? 'bg-violet-900 text-violet-300' : 
                connectionStatus === 'connecting' ? 'bg-purple-900 text-purple-300' : 
                'bg-gray-700 text-gray-300'
              }`}>
                <Cloud size={14} className="mr-1" />
                {connectionStatus === 'connected' ? 'Connecté' : 
                 connectionStatus === 'connecting' ? 'Connexion...' : 'Déconnecté'}
              </span>
            </div>
          </header>
          
          <div className="flex flex-1 overflow-hidden">
            {!isMobile && (
              <Sidebar 
                activeTab={activeTab} 
                setActiveTab={setActiveTab} 
                securityLevel={securityLevel}
                connectionStatus={connectionStatus}
              />
            )}
            
            <main className="flex-1 flex flex-col overflow-hidden">
              {activeTab === 'terminal' && (
                <Terminal 
                  isMobile={isMobile}
                  securityLevel={securityLevel}
                />
              )}
              {activeTab === 'cloud' && (
                <CloudConnection 
                  setConnectionStatus={setConnectionStatus}
                  securityLevel={securityLevel}
                />
              )}
              {activeTab === 'api' && (
                <ApiManager 
                  securityLevel={securityLevel}
                />
              )}
              {activeTab === 'repository' && (
                <Repository 
                  securityLevel={securityLevel}
                />
              )}
              {activeTab === 'gateway' && (
                <ApiGateway 
                  securityLevel={securityLevel}
                  refreshLogs={refreshLogs}
                />
              )}
              {activeTab === 'updates' && (
                <UpdateManager 
                  securityLevel={securityLevel}
                />
              )}
              {activeTab === 'backup' && (
                <BackupManager 
                  securityLevel={securityLevel}
                />
              )}
              {activeTab === 'monitoring' && (
                <MonitoringDashboard 
                  securityLevel={securityLevel}
                />
              )}
              {activeTab === 'settings' && (
                <Settings 
                  securityLevel={securityLevel} 
                  setSecurityLevel={handleSecurityLevelChange}
                  isMobile={isMobile}
                />
              )}
            </main>
          </div>
          
          {isMobile && (
            <div className="bg-gray-800 border-t border-violet-900 p-2">
              <div className="flex justify-around">
                <button
                  onClick={() => setActiveTab('terminal')}
                  className={`p-2 rounded-lg ${activeTab === 'terminal' ? 'bg-violet-900' : ''}`}
                >
                  <TerminalIcon size={24} className={activeTab === 'terminal' ? 'text-violet-400' : 'text-gray-400'} />
                </button>
                <button
                  onClick={() => setActiveTab('cloud')}
                  className={`p-2 rounded-lg ${activeTab === 'cloud' ? 'bg-violet-900' : ''}`}
                >
                  <Cloud size={24} className={activeTab === 'cloud' ? 'text-violet-400' : 'text-gray-400'} />
                </button>
                <button
                  onClick={() => setActiveTab('api')}
                  className={`p-2 rounded-lg ${activeTab === 'api' ? 'bg-violet-900' : ''}`}
                >
                  <Code size={24} className={activeTab === 'api' ? 'text-violet-400' : 'text-gray-400'} />
                </button>
                <button
                  onClick={() => setActiveTab('repository')}
                  className={`p-2 rounded-lg ${activeTab === 'repository' ? 'bg-violet-900' : ''}`}
                >
                  <Archive size={24} className={activeTab === 'repository' ? 'text-violet-400' : 'text-gray-400'} />
                </button>
                <button
                  onClick={() => setActiveTab('gateway')}
                  className={`p-2 rounded-lg ${activeTab === 'gateway' ? 'bg-violet-900' : ''}`}
                >
                  <Key size={24} className={activeTab === 'gateway' ? 'text-violet-400' : 'text-gray-400'} />
                </button>
                <button
                  onClick={() => setActiveTab('updates')}
                  className={`p-2 rounded-lg ${activeTab === 'updates' ? 'bg-violet-900' : ''}`}
                >
                  <RefreshCw size={24} className={activeTab === 'updates' ? 'text-violet-400' : 'text-gray-400'} />
                </button>
                <button
                  onClick={() => setActiveTab('settings')}
                  className={`p-2 rounded-lg ${activeTab === 'settings' ? 'bg-violet-900' : ''}`}
                >
                  <SettingsIcon size={24} className={activeTab === 'settings' ? 'text-violet-400' : 'text-gray-400'} />
                </button>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

export default App;