import { addLogEntry, LogLevel } from './logger';

/**
 * Interface for scheduled job configuration
 */
interface JobConfig {
  id: string;
  name: string;
  description?: string;
  cronExpression: string;
  enabled: boolean;
  lastRun?: Date;
  nextRun?: Date;
  handler: () => Promise<any>;
}

/**
 * Simple job scheduler for background tasks
 */
class JobScheduler {
  private jobs: Map<string, JobConfig> = new Map();
  private intervals: Map<string, number> = new Map();
  private isRunning: boolean = false;
  
  /**
   * Initialize the job scheduler
   */
  constructor() {
    // Start the scheduler automatically
    this.start();
    
    // Log initialization
    addLogEntry(LogLevel.INFO, 'Job scheduler initialized');
  }
  
  /**
   * Schedule a new job
   * @param job Job configuration
   * @returns The job ID
   */
  schedule(job: JobConfig): string {
    if (this.jobs.has(job.id)) {
      throw new Error(`Job with ID ${job.id} already exists`);
    }
    
    // Calculate next run time based on cron expression
    job.nextRun = this.calculateNextRun(job.cronExpression);
    
    this.jobs.set(job.id, job);
    
    // If scheduler is running, set up the interval for this job
    if (this.isRunning && job.enabled) {
      this.setupJobInterval(job);
    }
    
    addLogEntry(LogLevel.INFO, 'Job scheduled', {
      jobId: job.id,
      jobName: job.name,
      nextRun: job.nextRun?.toISOString()
    });
    
    return job.id;
  }
  
  /**
   * Start the job scheduler
   */
  start(): void {
    if (this.isRunning) return;
    
    this.isRunning = true;
    
    // Set up intervals for all enabled jobs
    for (const job of this.jobs.values()) {
      if (job.enabled) {
        this.setupJobInterval(job);
      }
    }
    
    addLogEntry(LogLevel.INFO, 'Job scheduler started');
  }
  
  /**
   * Stop the job scheduler
   */
  stop(): void {
    if (!this.isRunning) return;
    
    // Clear all intervals
    for (const intervalId of this.intervals.values()) {
      clearInterval(intervalId);
    }
    
    this.intervals.clear();
    this.isRunning = false;
    
    addLogEntry(LogLevel.INFO, 'Job scheduler stopped');
  }
  
  /**
   * Enable a job
   * @param jobId Job ID
   */
  enableJob(jobId: string): void {
    const job = this.jobs.get(jobId);
    if (!job) {
      throw new Error(`Job with ID ${jobId} not found`);
    }
    
    job.enabled = true;
    
    // If scheduler is running, set up the interval for this job
    if (this.isRunning) {
      this.setupJobInterval(job);
    }
    
    addLogEntry(LogLevel.INFO, 'Job enabled', { jobId, jobName: job.name });
  }
  
  /**
   * Disable a job
   * @param jobId Job ID
   */
  disableJob(jobId: string): void {
    const job = this.jobs.get(jobId);
    if (!job) {
      throw new Error(`Job with ID ${jobId} not found`);
    }
    
    job.enabled = false;
    
    // Clear the interval for this job
    const intervalId = this.intervals.get(jobId);
    if (intervalId) {
      clearInterval(intervalId);
      this.intervals.delete(jobId);
    }
    
    addLogEntry(LogLevel.INFO, 'Job disabled', { jobId, jobName: job.name });
  }
  
  /**
   * Run a job immediately
   * @param jobId Job ID
   * @returns Promise that resolves when the job completes
   */
  async runJobNow(jobId: string): Promise<any> {
    const job = this.jobs.get(jobId);
    if (!job) {
      throw new Error(`Job with ID ${jobId} not found`);
    }
    
    addLogEntry(LogLevel.INFO, 'Running job manually', { jobId, jobName: job.name });
    
    try {
      const result = await job.handler();
      
      // Update last run time
      job.lastRun = new Date();
      
      // Recalculate next run time
      job.nextRun = this.calculateNextRun(job.cronExpression);
      
      addLogEntry(LogLevel.SUCCESS, 'Job completed successfully', { 
        jobId, 
        jobName: job.name,
        nextRun: job.nextRun?.toISOString() 
      });
      
      return result;
    } catch (error) {
      addLogEntry(LogLevel.ERROR, 'Job failed', { 
        jobId, 
        jobName: job.name,
        error: String(error)
      });
      throw error;
    }
  }
  
  /**
   * Get all scheduled jobs
   * @returns Array of job configurations
   */
  getJobs(): JobConfig[] {
    return Array.from(this.jobs.values());
  }
  
  /**
   * Get a specific job
   * @param jobId Job ID
   * @returns Job configuration or undefined if not found
   */
  getJob(jobId: string): JobConfig | undefined {
    return this.jobs.get(jobId);
  }
  
  /**
   * Remove a job
   * @param jobId Job ID
   */
  removeJob(jobId: string): void {
    // Disable the job first to clear any intervals
    if (this.jobs.has(jobId)) {
      this.disableJob(jobId);
    }
    
    this.jobs.delete(jobId);
    
    addLogEntry(LogLevel.INFO, 'Job removed', { jobId });
  }
  
  /**
   * Calculate the next run time based on a cron expression
   * @param cronExpression Cron expression 
   * @returns Date representing the next run time
   */
  private calculateNextRun(cronExpression: string): Date {
    // This is a simplified implementation
    // In a real app, you would use a proper cron parser
    
    // For now, we'll just support basic intervals
    const now = new Date();
    const nextRun = new Date(now);
    
    if (cronExpression === '* * * * *') {
      // Every minute
      nextRun.setMinutes(nextRun.getMinutes() + 1);
    } else if (cronExpression === '0 * * * *') {
      // Every hour
      nextRun.setHours(nextRun.getHours() + 1);
      nextRun.setMinutes(0);
    } else if (cronExpression === '0 0 * * *') {
      // Every day at midnight
      nextRun.setDate(nextRun.getDate() + 1);
      nextRun.setHours(0);
      nextRun.setMinutes(0);
    } else if (cronExpression === '0 0 * * 0') {
      // Every week on Sunday
      nextRun.setDate(nextRun.getDate() + (7 - nextRun.getDay()));
      nextRun.setHours(0);
      nextRun.setMinutes(0);
    } else if (cronExpression === '0 0 1 * *') {
      // Every month on the 1st
      nextRun.setMonth(nextRun.getMonth() + 1);
      nextRun.setDate(1);
      nextRun.setHours(0);
      nextRun.setMinutes(0);
    } else {
      // Default to hourly
      nextRun.setHours(nextRun.getHours() + 1);
    }
    
    return nextRun;
  }
  
  /**
   * Set up the interval for a job
   * @param job Job configuration
   */
  private setupJobInterval(job: JobConfig): void {
    // Clear any existing interval
    const existingInterval = this.intervals.get(job.id);
    if (existingInterval) {
      clearInterval(existingInterval);
    }
    
    // For simplicity, we'll use a polling approach that checks every minute
    // In a real app, you would calculate the exact time to wait until the next run
    const intervalId = window.setInterval(async () => {
      const now = new Date();
      
      // If the job is due to run
      if (job.nextRun && now >= job.nextRun) {
        try {
          addLogEntry(LogLevel.INFO, 'Running scheduled job', { 
            jobId: job.id, 
            jobName: job.name 
          });
          
          // Run the job
          await job.handler();
          
          // Update last run time
          job.lastRun = new Date();
          
          // Recalculate next run time
          job.nextRun = this.calculateNextRun(job.cronExpression);
          
          addLogEntry(LogLevel.SUCCESS, 'Scheduled job completed', { 
            jobId: job.id, 
            jobName: job.name,
            nextRun: job.nextRun.toISOString()
          });
        } catch (error) {
          addLogEntry(LogLevel.ERROR, 'Scheduled job failed', { 
            jobId: job.id, 
            jobName: job.name,
            error: String(error)
          });
        }
      }
    }, 60000); // Check every minute
    
    this.intervals.set(job.id, intervalId);
  }
}

// Create and export a single instance of the scheduler
export const jobScheduler = new JobScheduler();

/**
 * Schedule a backup job
 * @param interval Backup interval ('hourly', 'daily', 'weekly')
 * @param backupFn Function to execute for backup
 * @returns Job ID
 */
export const scheduleBackup = (
  interval: 'hourly' | 'daily' | 'weekly',
  backupFn: () => Promise<any>
): string => {
  let cronExpression: string;
  
  switch (interval) {
    case 'hourly':
      cronExpression = '0 * * * *';
      break;
    case 'daily':
      cronExpression = '0 0 * * *';
      break;
    case 'weekly':
      cronExpression = '0 0 * * 0';
      break;
    default:
      cronExpression = '0 0 * * *'; // Default to daily
  }
  
  const jobId = `backup_${interval}_${Date.now()}`;
  
  jobScheduler.schedule({
    id: jobId,
    name: `${interval.charAt(0).toUpperCase() + interval.slice(1)} Backup`,
    description: `Automatic ${interval} backup`,
    cronExpression,
    enabled: true,
    handler: backupFn
  });
  
  return jobId;
}