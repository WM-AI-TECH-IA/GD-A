import { createClient } from '@supabase/supabase-js';
import { encryptData } from './security';

// Enum for log levels
export enum LogLevel {
  ERROR = 'error',
  WARNING = 'warning',
  INFO = 'info',
  DEBUG = 'debug',
  SUCCESS = 'success'
}

// Log entry interface
export interface LogEntry {
  timestamp: string;
  level: LogLevel;
  message: string;
  userId?: string;
  component?: string;
  details?: Record<string, any>;
}

// Maximum log entries to keep in memory
const MAX_LOG_ENTRIES = 1000;

// In-memory log storage for quick access
let logEntries: LogEntry[] = [];

// Initialize Supabase client
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

let supabase: any = null;

// Flag to indicate if logging to Supabase is enabled
let logToSupabaseEnabled = false;

/**
 * Initialize the logger system
 * @param userId Optional user ID to associate with logs
 * @param enableSupabaseLogging Whether to log to Supabase (requires valid credentials)
 */
export const initializeLogger = (userId?: string, enableSupabaseLogging = false) => {
  try {
    if (enableSupabaseLogging && supabaseUrl && supabaseAnonKey) {
      supabase = createClient(supabaseUrl, supabaseAnonKey);
      logToSupabaseEnabled = true;
      
      // Log the initialization
      addLogEntry(LogLevel.INFO, 'Logger initialized with Supabase integration', {
        supabaseEnabled: true,
        userId
      });
    } else {
      // Log the initialization with only local storage
      addLogEntry(LogLevel.INFO, 'Logger initialized with local storage only', {
        supabaseEnabled: false,
        reason: !enableSupabaseLogging 
          ? 'Supabase logging disabled by configuration' 
          : 'Missing Supabase credentials'
      });
    }
  } catch (error) {
    console.error('Failed to initialize logger:', error);
    
    // Still add a local log entry
    const logEntry: LogEntry = {
      timestamp: new Date().toISOString(),
      level: LogLevel.ERROR,
      message: 'Failed to initialize logger',
      details: { error: String(error) }
    };
    
    logEntries.unshift(logEntry);
  }
};

/**
 * Add a log entry to both memory and Supabase if enabled
 * @param level Log level
 * @param message Log message
 * @param details Optional additional details
 * @param userId Optional user ID
 * @param component Optional component name
 */
export const addLogEntry = async (
  level: LogLevel, 
  message: string, 
  details?: Record<string, any>,
  userId?: string, 
  component?: string
): Promise<void> => {
  try {
    // Create the log entry
    const logEntry: LogEntry = {
      timestamp: new Date().toISOString(),
      level,
      message,
      userId,
      component,
      details
    };
    
    // Add to in-memory log
    logEntries.unshift(logEntry);
    
    // Trim the log if it gets too large
    if (logEntries.length > MAX_LOG_ENTRIES) {
      logEntries = logEntries.slice(0, MAX_LOG_ENTRIES);
    }
    
    // Output to console based on level
    const consoleMethod = level === LogLevel.ERROR
      ? console.error
      : level === LogLevel.WARNING
      ? console.warn
      : level === LogLevel.DEBUG
      ? console.debug
      : console.log;
      
    consoleMethod(
      `[${new Date().toLocaleTimeString()}] [${level.toUpperCase()}]${component ? ` [${component}]` : ''}: ${message}`, 
      details || ''
    );
    
    // Log to Supabase if enabled
    if (logToSupabaseEnabled && supabase) {
      // Don't await this to avoid blocking
      try {
        // In a real app, encrypt sensitive details before sending
        const encryptedDetails = details ? await encryptData(JSON.stringify(details)) : null;
        
        supabase.from('system_logs').insert([
          {
            level,
            message,
            user_id: userId,
            component,
            details: encryptedDetails
          }
        ]).then((result: any) => {
          if (result.error) {
            console.error('Failed to log to Supabase:', result.error);
          }
        });
      } catch (error) {
        console.error('Error logging to Supabase:', error);
      }
    }
  } catch (error) {
    // Last resort - log using basic console
    console.error('Error in logger:', error);
    console.error('Original log message:', level, message, details);
  }
};

/**
 * Get all log entries, optionally filtered by level
 * @param level Optional log level to filter by
 * @returns Array of log entries
 */
export const getLogs = (level?: LogLevel): LogEntry[] => {
  if (level) {
    return logEntries.filter(entry => entry.level === level);
  }
  return logEntries;
};

/**
 * Clear all log entries from memory
 */
export const clearLogs = (): void => {
  logEntries = [];
  addLogEntry(LogLevel.INFO, 'Logs cleared');
};

/**
 * Get the number of log entries by level
 * @returns Object with counts for each log level
 */
export const getLogCounts = (): Record<LogLevel, number> => {
  const counts = {
    [LogLevel.ERROR]: 0,
    [LogLevel.WARNING]: 0,
    [LogLevel.INFO]: 0,
    [LogLevel.DEBUG]: 0,
    [LogLevel.SUCCESS]: 0
  };
  
  logEntries.forEach(entry => {
    if (entry.level in counts) {
      counts[entry.level]++;
    }
  });
  
  return counts;
};

// Initialize logger by default without Supabase integration
// This will be properly initialized when the app starts
initializeLogger(undefined, false);