import { addLogEntry, LogLevel } from './logger';

// Interface for rate limit configuration
interface RateLimitConfig {
  windowMs: number;   // Time window in milliseconds
  maxRequests: number; // Maximum number of requests in the time window
  message?: string;   // Optional custom error message
}

// Rate limiter class for API endpoints
export class RateLimiter {
  private windowMs: number;
  private maxRequests: number;
  private message: string;
  private requests: Map<string, { count: number, resetTime: number }>;
  
  /**
   * Create a new rate limiter
   * @param config Rate limit configuration
   */
  constructor(config: RateLimitConfig) {
    this.windowMs = config.windowMs;
    this.maxRequests = config.maxRequests;
    this.message = config.message || 'Too many requests, please try again later';
    this.requests = new Map();
    
    // Periodically clean up expired entries to prevent memory leaks
    setInterval(() => this.cleanup(), Math.min(this.windowMs, 60000));
  }
  
  /**
   * Check if a request is allowed based on the IP and API key
   * @param ip IP address of the requester
   * @param apiKey Optional API key for more granular control
   * @returns Object indicating if the request is allowed and remaining quota
   */
  check(ip: string, apiKey?: string): { 
    allowed: boolean; 
    remaining: number; 
    resetTime: number;
  } {
    const now = Date.now();
    const key = apiKey ? `${ip}:${apiKey}` : ip;
    
    let record = this.requests.get(key);
    
    if (!record || now > record.resetTime) {
      // If no record exists or the window has reset
      record = {
        count: 0,
        resetTime: now + this.windowMs
      };
    }
    
    // Increment the counter
    record.count++;
    this.requests.set(key, record);
    
    // Check if allowed
    const allowed = record.count <= this.maxRequests;
    const remaining = Math.max(0, this.maxRequests - record.count);
    
    // Log rate limit hits
    if (!allowed) {
      addLogEntry(LogLevel.WARNING, 'Rate limit exceeded', {
        ip,
        apiKey: apiKey ? '****' + apiKey.slice(-4) : undefined,
        limit: this.maxRequests,
        window: this.windowMs,
      });
    }
    
    return {
      allowed,
      remaining,
      resetTime: record.resetTime
    };
  }
  
  /**
   * Clean up expired entries to prevent memory leaks
   */
  private cleanup(): void {
    const now = Date.now();
    for (const [key, record] of this.requests.entries()) {
      if (now > record.resetTime) {
        this.requests.delete(key);
      }
    }
  }
}

// Factory method to create rate limiters with common configurations
export const createRateLimiter = (
  requestsPerMinute: number, 
  message?: string
): RateLimiter => {
  return new RateLimiter({
    windowMs: 60 * 1000, // 1 minute
    maxRequests: requestsPerMinute,
    message
  });
};

// Create common rate limiters for different scenarios
export const commonRateLimiters = {
  // For authentication endpoints
  auth: new RateLimiter({
    windowMs: 15 * 60 * 1000, // 15 minutes
    maxRequests: 10,
    message: 'Trop de tentatives de connexion, veuillez réessayer plus tard'
  }),
  
  // For API requests
  api: new RateLimiter({
    windowMs: 60 * 1000, // 1 minute
    maxRequests: 100,
    message: 'Taux de requêtes API dépassé, veuillez réduire la fréquence des appels'
  }),
  
  // For public endpoints
  public: new RateLimiter({
    windowMs: 60 * 1000, // 1 minute
    maxRequests: 60,
    message: 'Trop de requêtes, veuillez réessayer plus tard'
  })
};