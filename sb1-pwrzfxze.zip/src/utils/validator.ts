import { addLogEntry, LogLevel } from './logger';

// Types of validation
type ValidationType = 
  | 'email' 
  | 'url' 
  | 'phone' 
  | 'ip' 
  | 'creditCard' 
  | 'alphanumeric' 
  | 'numeric' 
  | 'integer'
  | 'float'
  | 'password'
  | 'json';

// Options for validation
interface ValidationOptions {
  required?: boolean;
  minLength?: number;
  maxLength?: number;
  pattern?: RegExp;
  custom?: (value: any) => boolean | string;
}

// Interface for validation results
interface ValidationResult {
  valid: boolean;
  message?: string;
  sanitized?: any;
}

/**
 * Sanitize user input to prevent XSS attacks
 * @param input String to sanitize
 * @returns Sanitized string
 */
export const sanitizeInput = (input: string): string => {
  if (typeof input !== 'string') {
    return '';
  }
  
  // Replace dangerous HTML entities
  return input
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/\//g, '&#x2F;');
};

/**
 * Sanitize HTML to allow only safe tags
 * @param html HTML string to sanitize
 * @returns Sanitized HTML
 */
export const sanitizeHtml = (html: string): string => {
  // This is a simple implementation
  // In a production application, use a proper HTML sanitizer library
  
  // Strip out script, iframe, object, embed, and style tags completely
  let sanitized = html.replace(/<(script|iframe|object|embed|style)[^>]*>[\s\S]*?<\/\1>|<(script|iframe|object|embed|style)[^>]*\/>/gi, '');
  
  // Remove event handlers and javascript: protocols
  sanitized = sanitized.replace(/\son\w+\s*=\s*(?:(['"])[\s\S]*?\1|[^\s>]*)/gi, '');
  sanitized = sanitized.replace(/\s+(?:href|src)\s*=\s*(?:(['"])javascript:[\s\S]*?\1)/gi, ' href="#"');
  
  return sanitized;
};

/**
 * Validate data according to specified rules
 * @param value Value to validate
 * @param type Type of validation to perform
 * @param options Additional validation options
 * @returns Validation result
 */
export const validate = (
  value: any, 
  type: ValidationType,
  options: ValidationOptions = {}
): ValidationResult => {
  // Check if required and empty
  if (options.required && (value === undefined || value === null || value === '')) {
    return {
      valid: false,
      message: 'Ce champ est requis'
    };
  }
  
  // If not required and empty, it's valid
  if (!options.required && (value === undefined || value === null || value === '')) {
    return { valid: true };
  }
  
  // Convert to string for string validations
  const stringValue = String(value);
  
  // Check min/max length for string values
  if (typeof value === 'string') {
    if (options.minLength !== undefined && stringValue.length < options.minLength) {
      return {
        valid: false,
        message: `Ce champ doit contenir au moins ${options.minLength} caractères`
      };
    }
    
    if (options.maxLength !== undefined && stringValue.length > options.maxLength) {
      return {
        valid: false,
        message: `Ce champ ne peut pas dépasser ${options.maxLength} caractères`
      };
    }
  }
  
  // Check custom pattern if provided
  if (options.pattern && !options.pattern.test(stringValue)) {
    return {
      valid: false,
      message: 'Format invalide'
    };
  }
  
  // Type-specific validations
  let valid = true;
  let message = '';
  let sanitized = value;
  
  switch (type) {
    case 'email':
      // RFC 5322 compliant email regex
      const emailRegex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
      valid = emailRegex.test(stringValue);
      message = valid ? '' : 'Email invalide';
      sanitized = sanitizeInput(stringValue);
      break;
      
    case 'url':
      try {
        new URL(stringValue);
        valid = true;
        sanitized = sanitizeInput(stringValue);
      } catch {
        valid = false;
        message = 'URL invalide';
      }
      break;
      
    case 'phone':
      // Simple phone regex - adapt for your specific requirements
      const phoneRegex = /^\+?[0-9]{10,15}$/;
      valid = phoneRegex.test(stringValue.replace(/[\s-]/g, ''));
      message = valid ? '' : 'Numéro de téléphone invalide';
      sanitized = stringValue.replace(/[^\d+\s-]/g, '');
      break;
      
    case 'ip':
      // IPv4 regex
      const ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
      valid = ipv4Regex.test(stringValue);
      message = valid ? '' : 'Adresse IP invalide';
      break;
      
    case 'creditCard':
      // Remove spaces and dashes
      const cardNum = stringValue.replace(/[\s-]/g, '');
      
      // Check for only digits and length between 13-19
      const ccRegex = /^[0-9]{13,19}$/;
      valid = ccRegex.test(cardNum);
      
      // Luhn algorithm for additional validation
      if (valid) {
        let sum = 0;
        let double = false;
        
        for (let i = cardNum.length - 1; i >= 0; i--) {
          let digit = parseInt(cardNum.charAt(i));
          
          if (double) {
            digit *= 2;
            if (digit > 9) digit -= 9;
          }
          
          sum += digit;
          double = !double;
        }
        
        valid = sum % 10 === 0;
      }
      
      message = valid ? '' : 'Numéro de carte de crédit invalide';
      
      // Only return last 4 digits for security
      if (valid) {
        sanitized = '****' + cardNum.slice(-4);
      }
      break;
      
    case 'alphanumeric':
      valid = /^[a-zA-Z0-9]+$/.test(stringValue);
      message = valid ? '' : 'Seuls les caractères alphanumériques sont autorisés';
      sanitized = sanitizeInput(stringValue);
      break;
      
    case 'numeric':
      valid = /^[0-9]+$/.test(stringValue);
      message = valid ? '' : 'Seuls les chiffres sont autorisés';
      break;
      
    case 'integer':
      valid = /^-?\d+$/.test(stringValue);
      message = valid ? '' : 'Veuillez entrer un nombre entier valide';
      if (valid) sanitized = parseInt(stringValue);
      break;
      
    case 'float':
      valid = /^-?\d+(\.\d+)?$/.test(stringValue);
      message = valid ? '' : 'Veuillez entrer un nombre décimal valide';
      if (valid) sanitized = parseFloat(stringValue);
      break;
      
    case 'password':
      // At least 8 characters, 1 uppercase, 1 lowercase, 1 number
      const strongPasswordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,}$/;
      valid = strongPasswordRegex.test(stringValue);
      message = valid ? '' : 'Le mot de passe doit contenir au moins 8 caractères, dont une majuscule, une minuscule et un chiffre';
      break;
      
    case 'json':
      try {
        JSON.parse(stringValue);
        valid = true;
      } catch {
        valid = false;
        message = 'JSON invalide';
      }
      break;
  }
  
  // Run custom validation if provided
  if (valid && options.custom) {
    const customResult = options.custom(value);
    if (typeof customResult === 'string') {
      valid = false;
      message = customResult;
    } else {
      valid = Boolean(customResult);
      if (!valid) {
        message = 'Validation personnalisée échouée';
      }
    }
  }
  
  // If validation fails, log it (but only for important validations)
  if (!valid && ['email', 'url', 'creditCard', 'json', 'password'].includes(type)) {
    addLogEntry(LogLevel.WARNING, `Validation failed for ${type}`, {
      messageShown: message
    });
  }
  
  return {
    valid,
    message: valid ? undefined : message,
    sanitized
  };
};

/**
 * Validate an object against a validation schema
 * @param data Object to validate
 * @param schema Validation schema
 * @returns Object with validation results for each field
 */
export const validateObject = <T extends Record<string, any>>(
  data: T,
  schema: Record<keyof T, {
    type: ValidationType;
    options?: ValidationOptions;
  }>
): Record<keyof T, ValidationResult> => {
  const result: Record<string, ValidationResult> = {};
  
  for (const key in schema) {
    if (Object.prototype.hasOwnProperty.call(schema, key)) {
      const field = schema[key];
      result[key] = validate(data[key], field.type, field.options);
    }
  }
  
  return result as Record<keyof T, ValidationResult>;
};