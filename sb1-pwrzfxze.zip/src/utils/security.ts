/**
 * Security utilities for WM Terminal Cloud
 * 
 * This file contains anti-analysis measures and obfuscated code to resist reverse engineering.
 * Do not modify unless you understand the security implications.
 */

import CryptoJS from 'crypto-js';

// Obfuscated verification for the authentication code
export const verifyAuthCode = (input: string): boolean => {
  // Multiple nested functions and decoys to make analysis harder
  const _0xc48a = ['substring', 'length', 'charAt', 'charCodeAt'];
  const _0x5e7f = function(_0x3d8a2e: string) {
    const _0x1f4b76 = '16091609164';
    return _0x3d8a2e === _0x1f4b76;
  };
  
  // Decoy function that's never called but makes static analysis harder
  const _0x3f7a = function(_0x2c1a4f: string) {
    let _0x5b4c1e = '';
    for (let _0x37e8a2 = 0; _0x37e8a2 < _0x2c1a4f[_0xc48a[1]]; _0x37e8a2++) {
      _0x5b4c1e += String.fromCharCode(_0x2c1a4f[_0xc48a[3]](_0x37e8a2) ^ 42);
    }
    return _0x5b4c1e;
  };
  
  // Another layer of indirection
  const _0x4e2d = function(_0x1c9b7f: string) {
    return _0x5e7f(_0x1c9b7f);
  };
  
  return _0x4e2d(input);
};

// Anti-debugging tools
export const setupAntiDebugging = () => {
  // Only run in production
  if (process.env.NODE_ENV !== 'production') return;
  
  // Detect devtools
  const checkDevTools = () => {
    const widthThreshold = window.outerWidth - window.innerWidth > 160;
    const heightThreshold = window.outerHeight - window.innerHeight > 160;
    
    if (widthThreshold || heightThreshold) {
      // Potential devtools detected
      console.clear();
      document.body.innerHTML = '';
      window.location.reload();
    }
  };
  
  // Check for console tampering
  const originalConsole = { 
    log: console.log,
    warn: console.warn,
    error: console.error,
    debug: console.debug,
    info: console.info
  };
  
  // Override console methods to detect tampering
  console.log = function() {
    originalConsole.log.apply(console, arguments);
    checkConsoleUsage();
  };
  
  console.warn = function() {
    originalConsole.warn.apply(console, arguments);
    checkConsoleUsage();
  };
  
  console.error = function() {
    originalConsole.error.apply(console, arguments);
    checkConsoleUsage();
  };
  
  console.debug = function() {
    originalConsole.debug.apply(console, arguments);
    checkConsoleUsage();
  };
  
  console.info = function() {
    originalConsole.info.apply(console, arguments);
    checkConsoleUsage();
  };
  
  // Count console usage and take action if excessive
  let consoleUseCount = 0;
  const checkConsoleUsage = () => {
    consoleUseCount++;
    if (consoleUseCount > 10) {
      // Potential analysis happening
      window.location.reload();
    }
  };
  
  // Set up timer-based checks
  setInterval(checkDevTools, 1000);
  
  // Debugger detection
  setInterval(() => {
    const startTime = new Date().getTime();
    debugger; // This will pause execution if dev tools are open
    const endTime = new Date().getTime();
    
    if (endTime - startTime > 100) {
      // Debugger likely detected
      console.clear();
      window.location.reload();
    }
  }, 1000);
  
  // Make it harder to analyze DOM
  document.addEventListener('contextmenu', (e) => {
    e.preventDefault();
    return false;
  });
  
  // Disable keyboard shortcuts often used for debugging
  document.addEventListener('keydown', (e) => {
    // Ctrl+Shift+I, Ctrl+Shift+J, Ctrl+Shift+C, F12
    if (
      (e.ctrlKey && e.shiftKey && (e.key === 'I' || e.key === 'i' || e.key === 'J' || e.key === 'j' || e.key === 'C' || e.key === 'c')) ||
      e.key === 'F12'
    ) {
      e.preventDefault();
      return false;
    }
  });
  
  // Set up mutation observer to detect DOM inspector
  const observer = new MutationObserver((mutations) => {
    if (mutations.length > 20) {
      // Possible DOM analysis happening
      observer.disconnect();
      window.location.reload();
    }
  });
  
  observer.observe(document.body, {
    childList: true,
    attributes: true,
    characterData: true,
    subtree: true
  });
};

/**
 * Encrypt data using AES-GCM with PBKDF2 key derivation
 * Much more secure than previous XOR implementation
 * 
 * @param data String data to encrypt
 * @param password Optional password, defaults to application-specific secure key
 * @returns Encrypted string in format salt$iv+ciphertext (base64)
 */
export const encryptData = async (data: string, password?: string): Promise<string> => {
  try {
    // Use provided password or generate a secure one from environment/application info
    const securePassword = password || getSecureAppPassword();
    
    // Generate a random salt for PBKDF2
    const salt = CryptoJS.lib.WordArray.random(16); // 128-bit salt
    
    // Derive the key using PBKDF2
    const key = await deriveKey(securePassword, salt);
    
    // Generate a random IV (Initialization Vector)
    const iv = CryptoJS.lib.WordArray.random(12); // 96-bit IV for GCM mode
    
    // Encrypt the data using AES-GCM
    const encrypted = CryptoJS.AES.encrypt(data, key, {
      iv: iv,
      mode: CryptoJS.mode.GCM,
      padding: CryptoJS.pad.NoPadding
    });
    
    // Combine IV and ciphertext for storage
    const ivAndCiphertext = iv.concat(encrypted.ciphertext);
    
    // Format: salt$iv+ciphertext in base64
    const result = CryptoJS.enc.Base64.stringify(salt) + 
      "$" + 
      CryptoJS.enc.Base64.stringify(ivAndCiphertext);
    
    return result;
  } catch (error) {
    console.error("Encryption error:", error);
    // Fallback to a simpler method in case of error
    return fallbackEncrypt(data);
  }
};

/**
 * Decrypt data that was encrypted with encryptData
 * 
 * @param encryptedData Encrypted string from encryptData
 * @param password Optional password, must match the one used for encryption
 * @returns Decrypted string data or empty string if decryption fails
 */
export const decryptData = async (encryptedData: string, password?: string): Promise<string> => {
  try {
    // Use provided password or generate a secure one from environment/application info
    const securePassword = password || getSecureAppPassword();
    
    // Split the encrypted data into salt and iv+ciphertext
    const parts = encryptedData.split('$');
    if (parts.length !== 2) {
      throw new Error("Invalid encrypted data format");
    }
    
    const saltString = parts[0];
    const ivAndCiphertextString = parts[1];
    
    // Parse the salt and iv+ciphertext
    const salt = CryptoJS.enc.Base64.parse(saltString);
    const ivAndCiphertextBytes = CryptoJS.enc.Base64.parse(ivAndCiphertextString);
    
    // Derive the key using PBKDF2 with the same salt
    const key = await deriveKey(securePassword, salt);
    
    // Extract IV (first 12 bytes) and ciphertext (remaining bytes)
    const iv = CryptoJS.lib.WordArray.create(
      ivAndCiphertextBytes.words.slice(0, 3)
    );
    
    const ciphertext = CryptoJS.lib.WordArray.create(
      ivAndCiphertextBytes.words.slice(3),
      ivAndCiphertextBytes.sigBytes - 12
    );
    
    // Decrypt the data
    const decrypted = CryptoJS.AES.decrypt(
      { ciphertext: ciphertext },
      key,
      {
        iv: iv,
        mode: CryptoJS.mode.GCM,
        padding: CryptoJS.pad.NoPadding
      }
    );
    
    // Convert to string
    return decrypted.toString(CryptoJS.enc.Utf8);
  } catch (error) {
    console.error("Decryption error:", error);
    // Try fallback decryption for backward compatibility
    return fallbackDecrypt(encryptedData);
  }
};

/**
 * Derives a cryptographic key from a password and salt using PBKDF2
 * 
 * @param password Password to derive key from
 * @param salt Salt to use for key derivation
 * @returns Derived key as WordArray
 */
const deriveKey = async (password: string, salt: CryptoJS.lib.WordArray): Promise<CryptoJS.lib.WordArray> => {
  return CryptoJS.PBKDF2(
    password, 
    salt, 
    { 
      keySize: 256/32, // 256-bit key
      iterations: 10000, // Higher iteration count for better security
      hasher: CryptoJS.algo.SHA256 
    }
  );
};

/**
 * Gets a secure password for encryption based on application context
 * This creates a more secure default than hardcoding a password
 */
const getSecureAppPassword = (): string => {
  // Base password on origin, user agent hash, and other browser-specific info
  const browserInfo = navigator.userAgent + navigator.language + navigator.platform;
  const originInfo = window.location.origin;
  
  // Get timestamp to the nearest day (so it doesn't change too frequently)
  const dayTimestamp = Math.floor(Date.now() / (1000 * 60 * 60 * 24));
  
  // Combine with any environment variables if available
  const envInfo = import.meta.env.VITE_APP_SECRET || '';
  
  // Create a hash of all this information
  const combinedInfo = browserInfo + originInfo + dayTimestamp.toString() + envInfo;
  const securePassword = CryptoJS.SHA256(combinedInfo).toString();
  
  return securePassword;
};

/**
 * Fallback encryption method for compatibility
 * Uses a simple XOR encryption if the main method fails
 */
const fallbackEncrypt = (data: string): string => {
  const key = 'WMTerminalSecureKey2025';
  let encrypted = '';
  
  for (let i = 0; i < data.length; i++) {
    const charCode = data.charCodeAt(i) ^ key.charCodeAt(i % key.length);
    encrypted += String.fromCharCode(charCode);
  }
  
  return btoa(encrypted);
};

/**
 * Fallback decryption method for compatibility
 * Uses a simple XOR decryption if the main method fails
 */
const fallbackDecrypt = (encrypted: string): string => {
  try {
    const key = 'WMTerminalSecureKey2025';
    const data = atob(encrypted);
    let decrypted = '';
    
    for (let i = 0; i < data.length; i++) {
      const charCode = data.charCodeAt(i) ^ key.charCodeAt(i % key.length);
      decrypted += String.fromCharCode(charCode);
    }
    
    return decrypted;
  } catch (err) {
    console.error('Fallback decryption failed');
    return '';
  }
};

// Set up anti-tampering measures
export const setupAntiTampering = () => {
  // Only run in production
  if (process.env.NODE_ENV !== 'production') return;
  
  // Check for script modifications
  const originalScripts: {[key: string]: string} = {};
  
  // Store original scripts
  Array.from(document.scripts).forEach((script, index) => {
    if (script.src) {
      originalScripts[`src_${index}`] = script.src;
    } else if (script.textContent) {
      originalScripts[`content_${index}`] = script.textContent;
    }
  });
  
  // Periodically check for script modifications
  setInterval(() => {
    let modified = false;
    
    Array.from(document.scripts).forEach((script, index) => {
      if (script.src && originalScripts[`src_${index}`] && script.src !== originalScripts[`src_${index}`]) {
        modified = true;
      } else if (script.textContent && originalScripts[`content_${index}`] && script.textContent !== originalScripts[`content_${index}`]) {
        modified = true;
      }
    });
    
    if (modified) {
      // Possible tampering detected
      console.clear();
      window.location.reload();
    }
  }, 2000);
};