import { createClient } from '@supabase/supabase-js';
import { v4 as uuidv4 } from 'uuid';
import { addLogEntry, LogLevel } from './logger';

// Types for database tables
export type ApiGatewaySettings = {
  id?: string;
  base_url: string;
  security_level: 'standard' | 'high' | 'extreme';
  default_rate_limit: number;
  authentication_required_by_default: boolean;
  cors_origins: string;
  created_at?: string;
  updated_at?: string;
  user_id?: string;
};

export type ApiKey = {
  id: string;
  name: string;
  key: string;
  scopes: string[];
  status: 'active' | 'revoked' | 'expired';
  created_at?: string;
  last_used?: string;
  user_id?: string;
};

export type ApiRoute = {
  id: string;
  path: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  authenticated: boolean;
  rate_limit: number;
  status: 'active' | 'inactive';
  secured: boolean;
  created_at?: string;
  updated_at?: string;
  user_id?: string;
};

// Supabase client
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

// Check if Supabase credentials are properly configured
if (!supabaseUrl || supabaseUrl === 'https://your-project-id.supabase.co') {
  console.error('VITE_SUPABASE_URL is not set or is using default value. Please set it in your .env file.');
}

if (!supabaseAnonKey || supabaseAnonKey === 'your-anon-key-here') {
  console.error('VITE_SUPABASE_ANON_KEY is not set or is using default value. Please set it in your .env file.');
}

export const supabase = createClient(
  supabaseUrl || '', 
  supabaseAnonKey || ''
);

// Authentication functions
export const getCurrentUser = async () => {
  try {
    const { data: { user }, error } = await supabase.auth.getUser();
    
    // Handle the case where there's an error but it's just that there's no session
    if (error) {
      if (error.message === 'Auth session missing!') {
        // This is a normal state when not logged in, not an error
        return null;
      }
      throw error;
    }
    
    return user;
  } catch (error) {
    console.error('Error getting current user:', error);
    return null;
  }
};

export const signInWithEmail = async (email: string, password: string) => {
  try {
    const response = await supabase.auth.signInWithPassword({ email, password });
    return response;
  } catch (error) {
    console.error('Error signing in:', error);
    throw error;
  }
};

export const signUpWithEmail = async (email: string, password: string) => {
  try {
    const response = await supabase.auth.signUp({ email, password });
    return response;
  } catch (error) {
    console.error('Error signing up:', error);
    throw error;
  }
};

export const signOut = async () => {
  return supabase.auth.signOut();
};

// API Gateway Settings functions
export const getApiGatewaySettings = async (): Promise<ApiGatewaySettings | null> => {
  try {
    const { data: userData, error: userError } = await supabase.auth.getUser();
    
    if (userError || !userData.user) {
      console.error("Erreur de récupération de l'utilisateur:", userError);
      return null;
    }
    
    // Try to get existing settings
    const { data, error } = await supabase
      .from('api_gateway_settings')
      .select('*')
      .eq('user_id', userData.user.id);

    // Handle the case where no settings exist
    if (error) {
      console.error("Erreur lors de la récupération des paramètres de l'API Gateway:", error);
      return null;
    }

    // If no settings exist for this user, create default settings
    if (!data || data.length === 0) {
      console.log("Aucun paramètre trouvé, création des paramètres par défaut...");
      
      const defaultSettings: ApiGatewaySettings = {
        base_url: 'https://api.wmterminal.com',
        security_level: 'high',
        default_rate_limit: 100,
        authentication_required_by_default: true,
        cors_origins: 'https://wmterminal.com, https://admin.wmterminal.com',
        user_id: userData.user.id
      };
      
      try {
        const { data: newSettings, error: createError } = await supabase
          .from('api_gateway_settings')
          .insert([defaultSettings])
          .select('*')
          .single();
        
        if (createError) throw createError;
        
        return newSettings;
      } catch (createError) {
        console.error("Erreur lors de la création des paramètres par défaut:", createError);
        // Return the default settings even if we couldn't save them
        return defaultSettings;
      }
    }
    
    // Return the first settings object if multiple exist
    return data[0];
  } catch (error) {
    console.error("Erreur globale lors de la récupération/création des paramètres:", error);
    // Return default settings as a fallback
    return {
      base_url: 'https://api.wmterminal.com',
      security_level: 'high',
      default_rate_limit: 100,
      authentication_required_by_default: true,
      cors_origins: 'https://wmterminal.com, https://admin.wmterminal.com'
    };
  }
};

export const updateApiGatewaySettings = async (settings: Partial<ApiGatewaySettings>): Promise<ApiGatewaySettings | null> => {
  const { data: userData, error: userError } = await supabase.auth.getUser();
  
  if (userError || !userData.user) {
    console.error("Erreur de récupération de l'utilisateur:", userError);
    throw new Error("Utilisateur non authentifié");
  }
  
  try {
    // Get existing settings first
    const existingSettings = await getApiGatewaySettings();
    
    const updatedSettings = {
      ...settings,
      user_id: userData.user.id,
      updated_at: new Date().toISOString()
    };
    
    let result;
    
    if (existingSettings && existingSettings.id) {
      // Update existing settings
      const { data, error } = await supabase
        .from('api_gateway_settings')
        .update(updatedSettings)
        .eq('id', existingSettings.id)
        .select('*')
        .single();
      
      if (error) throw error;
      result = data;
    } else {
      // Create new settings
      const { data, error } = await supabase
        .from('api_gateway_settings')
        .insert([updatedSettings])
        .select('*')
        .single();
      
      if (error) throw error;
      result = data;
    }
    
    // Log settings update
    addLogEntry(LogLevel.INFO, 'API Gateway settings updated', {
      base_url: updatedSettings.base_url,
      security_level: updatedSettings.security_level
    });
    
    return result;
  } catch (error) {
    console.error("Erreur lors de la mise à jour des paramètres:", error);
    throw error;
  }
};

// API Keys functions
export const getApiKeys = async (): Promise<ApiKey[]> => {
  const { data: userData, error: userError } = await supabase.auth.getUser();
  
  if (userError || !userData.user) {
    console.error("Erreur de récupération de l'utilisateur:", userError);
    return [];
  }
  
  const { data, error } = await supabase
    .from('api_keys')
    .select('*')
    .eq('user_id', userData.user.id)
    .order('created_at', { ascending: false });

  if (error) {
    console.error("Erreur lors de la récupération des clés API:", error);
    return [];
  }

  return data || [];
};

/**
 * Creates a new API key with cryptographically secure random generation
 * @param keyData Object containing API key metadata (excluding the key itself)
 * @returns Created API key with the generated secure key
 */
export const createApiKey = async (keyData: Omit<ApiKey, 'id' | 'user_id' | 'created_at' | 'key'>): Promise<{ apiKey: ApiKey; plainTextKey: string } | null> => {
  const { data: userData, error: userError } = await supabase.auth.getUser();
  
  if (userError || !userData.user) {
    console.error("Erreur de récupération de l'utilisateur:", userError);
    throw new Error("Utilisateur non authentifié");
  }
  
  try {
    // Generate a secure API key with proper prefix
    const keyPrefix = 'wm_';
    
    // Create a cryptographically secure random key using Web Crypto API
    const randomBytes = new Uint8Array(32); // 256 bits of randomness
    window.crypto.getRandomValues(randomBytes);
    
    // Convert to a hex string and format with prefix
    const plainTextKey = keyPrefix + Array.from(randomBytes)
      .map(byte => byte.toString(16).padStart(2, '0'))
      .join('')
      .substring(0, 32); // Limit to a reasonable length
    
    const newKey = {
      ...keyData,
      id: uuidv4(),
      user_id: userData.user.id,
      key: plainTextKey
    };
    
    const { data, error } = await supabase
      .from('api_keys')
      .insert([newKey])
      .select('*')
      .single();
    
    if (error) {
      console.error("Erreur lors de la création de la clé API:", error);
      throw error;
    }
    
    // Log the key creation (without the actual key)
    addLogEntry(LogLevel.INFO, 'New API key created', {
      keyId: data.id,
      keyName: data.name,
      scopes: data.scopes
    });
    
    return {
      apiKey: data,
      plainTextKey
    };
  } catch (error) {
    console.error("Error generating secure API key:", error);
    throw new Error(`Failed to generate secure API key: ${error instanceof Error ? error.message : String(error)}`);
  }
};

export const updateApiKey = async (id: string, status: 'active' | 'revoked' | 'expired'): Promise<ApiKey | null> => {
  const { data: userData, error: userError } = await supabase.auth.getUser();
  
  if (userError || !userData.user) {
    console.error("Erreur de récupération de l'utilisateur:", userError);
    throw new Error("Utilisateur non authentifié");
  }
  
  const { data, error } = await supabase
    .from('api_keys')
    .update({ status })
    .eq('id', id)
    .eq('user_id', userData.user.id)
    .select('*')
    .single();
  
  if (error) {
    console.error("Erreur lors de la mise à jour de la clé API:", error);
    throw error;
  }
  
  // Log key status change
  addLogEntry(LogLevel.INFO, `API key ${status === 'revoked' ? 'revoked' : 'status updated'}`, {
    keyId: data.id,
    newStatus: status
  });
  
  return data;
};

// API Routes functions
export const getApiRoutes = async (): Promise<ApiRoute[]> => {
  const { data: userData, error: userError } = await supabase.auth.getUser();
  
  if (userError || !userData.user) {
    console.error("Erreur de récupération de l'utilisateur:", userError);
    return [];
  }
  
  const { data, error } = await supabase
    .from('api_routes')
    .select('*')
    .eq('user_id', userData.user.id)
    .order('path', { ascending: true });

  if (error) {
    console.error("Erreur lors de la récupération des routes API:", error);
    return [];
  }

  return data || [];
};

export const updateApiRouteStatus = async (id: string, status: 'active' | 'inactive'): Promise<ApiRoute | null> => {
  const { data: userData, error: userError } = await supabase.auth.getUser();
  
  if (userError || !userData.user) {
    console.error("Erreur de récupération de l'utilisateur:", userError);
    throw new Error("Utilisateur non authentifié");
  }
  
  const { data, error } = await supabase
    .from('api_routes')
    .update({ 
      status,
      updated_at: new Date().toISOString()
    })
    .eq('id', id)
    .eq('user_id', userData.user.id)
    .select('*')
    .single();
  
  if (error) {
    console.error("Erreur lors de la mise à jour de la route API:", error);
    throw error;
  }
  
  // Log route status change
  addLogEntry(LogLevel.INFO, `API route ${status === 'active' ? 'activated' : 'deactivated'}`, {
    routeId: data.id,
    path: data.path,
    method: data.method
  });
  
  return data;
};

export const createApiRoute = async (routeData: Omit<ApiRoute, 'id' | 'user_id' | 'created_at' | 'updated_at'>): Promise<ApiRoute | null> => {
  const { data: userData, error: userError } = await supabase.auth.getUser();
  
  if (userError || !userData.user) {
    console.error("Erreur de récupération de l'utilisateur:", userError);
    throw new Error("Utilisateur non authentifié");
  }
  
  const newRoute = {
    ...routeData,
    user_id: userData.user.id
  };
  
  const { data, error } = await supabase
    .from('api_routes')
    .insert([newRoute])
    .select('*')
    .single();
  
  if (error) {
    console.error("Erreur lors de la création de la route API:", error);
    throw error;
  }
  
  // Log route creation
  addLogEntry(LogLevel.INFO, 'New API route created', {
    routeId: data.id,
    path: data.path,
    method: data.method
  });
  
  return data;
};

// Functions for testing the API gateway
export const testApiGateway = async (apiKey: string, path: string, method: string, body?: any): Promise<any> => {
  try {
    const { data: userData, error: userError } = await supabase.auth.getUser();
    
    if (userError || !userData.user) {
      console.error("Erreur de récupération de l'utilisateur:", userError);
      throw new Error("Utilisateur non authentifié");
    }

    // Get the gateway settings to determine the base URL
    const settings = await getApiGatewaySettings();
    if (!settings) {
      throw new Error("Gateway settings not found");
    }

    // Construct request options
    const options: RequestInit = {
      method,
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey
      }
    };

    // Add body for POST, PUT requests
    if (body && ['POST', 'PUT', 'PATCH'].includes(method)) {
      options.body = JSON.stringify(body);
    }

    // In a real app, this would call your deployed API Gateway
    // For now, we'll construct a URL to the Edge Function
    const edgeFunctionUrl = `${supabaseUrl}/functions/v1/api-gateway${path}`;
    
    // Add log entry for the test request
    addLogEntry(LogLevel.INFO, `Testing API gateway request: ${method} ${path}`, {
      method,
      path,
      userId: userData.user.id
    });

    // Make the request
    const response = await fetch(edgeFunctionUrl, options);
    const responseData = await response.json();

    return {
      status: response.status,
      statusText: response.statusText,
      data: responseData,
      headers: Object.fromEntries(response.headers)
    };

  } catch (error) {
    console.error("Error testing API gateway:", error);
    addLogEntry(LogLevel.ERROR, 'API gateway test failed', {
      error: String(error),
      path,
      method
    });
    
    throw error;
  }
};