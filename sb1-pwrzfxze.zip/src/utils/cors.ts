// Define allowed origins for CORS
const allowedOrigins = [
  'http://localhost:3000',
  'http://localhost:5173',
  'https://wmterminal.com',
  'https://admin.wmterminal.com',
  'https://api.wmterminal.com'
];

/**
 * Configuration for CORS middleware
 * @param customOrigins Additional origins to allow
 * @returns CORS middleware configuration
 */
export const corsConfig = (customOrigins: string[] = []) => {
  // Combine default and custom origins
  const origins = [...allowedOrigins, ...customOrigins];
  
  return {
    origin: (origin: string | undefined, callback: (err: Error | null, allow?: boolean) => void) => {
      // Allow requests with no origin (like mobile apps or curl requests)
      if (!origin) {
        return callback(null, true);
      }
      
      if (origins.indexOf(origin) !== -1 || process.env.NODE_ENV === 'development') {
        callback(null, true);
      } else {
        callback(new Error('Not allowed by CORS'));
      }
    },
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS', 'PATCH'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'X-API-Key'],
    credentials: true, // Allow cookies to be sent
    maxAge: 86400, // Cache preflight request results for 24 hours
  };
};

/**
 * Get CORS headers for serverless functions
 * @param customOrigins Additional origins to allow
 * @returns CORS headers object
 */
export const getCorsHeaders = (customOrigins: string[] = []) => {
  // Combine default and custom origins
  const origins = [...allowedOrigins, ...customOrigins];
  
  return {
    'Access-Control-Allow-Origin': origins.join(', '),
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS, PATCH',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Requested-With, X-API-Key',
    'Access-Control-Allow-Credentials': 'true',
    'Access-Control-Max-Age': '86400' // 24 hours in seconds
  };
};

/**
 * Parse comma-separated origins string into an array
 * @param originsString Comma-separated string of origins
 * @returns Array of origins
 */
export const parseOrigins = (originsString: string): string[] => {
  if (!originsString) return [];
  
  return originsString
    .split(',')
    .map(origin => origin.trim())
    .filter(origin => origin !== '');
};

/**
 * Validate if an origin is properly formatted
 * @param origin Origin to validate
 * @returns True if valid, false otherwise
 */
export const isValidOrigin = (origin: string): boolean => {
  try {
    const url = new URL(origin);
    return url.protocol === 'http:' || url.protocol === 'https:';
  } catch (error) {
    return false;
  }
};