/**
 * Simple rate limiter for API Gateway requests
 */
export class RateLimiter {
  private requestCounts: Map<string, { count: number, resetTime: number }> = new Map();
  private maxRequests: number;
  private windowMs: number;

  /**
   * Create a new rate limiter
   * @param maxRequests Maximum requests allowed in the time window
   * @param windowMs Time window in milliseconds
   */
  constructor(maxRequests: number, windowMs: number) {
    this.maxRequests = maxRequests;
    this.windowMs = windowMs;

    // Clean up expired records periodically
    setInterval(() => this.cleanup(), windowMs);
  }

  /**
   * Check if a request is allowed based on rate limiting
   * @param key Unique key for the request (e.g., user ID + IP)
   * @returns True if the request is allowed, false if rate limit exceeded
   */
  isAllowed(key: string): boolean {
    const now = Date.now();
    
    // Get or create record
    let record = this.requestCounts.get(key);
    
    if (!record || now > record.resetTime) {
      // Reset if window expired
      record = { count: 0, resetTime: now + this.windowMs };
    }
    
    // Check if over limit
    if (record.count >= this.maxRequests) {
      return false;
    }
    
    // Increment count and update
    record.count++;
    this.requestCounts.set(key, record);
    
    return true;
  }

  /**
   * Clean up expired records to prevent memory leaks
   */
  private cleanup(): void {
    const now = Date.now();
    
    for (const [key, record] of this.requestCounts.entries()) {
      if (now > record.resetTime) {
        this.requestCounts.delete(key);
      }
    }
  }
}