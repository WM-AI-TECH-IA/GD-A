import { createClient } from 'npm:@supabase/supabase-js@2.39.8';

// Interface for API key information
interface ApiKeyInfo {
  id: string;
  userId: string;
  scopes: string[];
}

/**
 * Verify an API key and return info about it if valid
 * @param supabase Supabase client instance
 * @param apiKey The API key to verify
 * @returns API key info if valid, null otherwise
 */
export async function verifyApiKey(
  supabase: ReturnType<typeof createClient>, 
  apiKey: string
): Promise<ApiKeyInfo | null> {
  try {
    // Fetch the API key from the database
    const { data, error } = await supabase
      .from('api_keys')
      .select('id, user_id, scopes')
      .eq('key', apiKey)
      .eq('status', 'active')
      .single();
    
    if (error || !data) {
      console.error('API key validation error:', error);
      return null;
    }
    
    return {
      id: data.id,
      userId: data.user_id,
      scopes: data.scopes || ['read']
    };
  } catch (error) {
    console.error('Error verifying API key:', error);
    return null;
  }
}