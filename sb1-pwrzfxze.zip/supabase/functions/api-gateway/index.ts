import { createClient } from 'npm:@supabase/supabase-js@2.39.8';
import { corsHeaders } from '../_shared/cors.ts';
import { verifyApiKey } from './lib/auth.ts';
import { RateLimiter } from './lib/rate-limit.ts';

// Constants for security levels
const SECURITY_LEVELS = {
  standard: 'standard',
  high: 'high',
  extreme: 'extreme'
};

// Initialize the Supabase client
const supabaseUrl = Deno.env.get('SUPABASE_URL') || '';
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') || '';
const supabase = createClient(supabaseUrl, supabaseServiceKey);

// Initialize rate limiters - one per security level
const rateLimiters = {
  [SECURITY_LEVELS.standard]: new RateLimiter(100, 60000), // 100 requests per minute
  [SECURITY_LEVELS.high]: new RateLimiter(60, 60000),      // 60 requests per minute
  [SECURITY_LEVELS.extreme]: new RateLimiter(30, 60000)    // 30 requests per minute
};

// Fetch API gateway settings for a user
async function getGatewaySettings(userId: string) {
  const { data, error } = await supabase
    .from('api_gateway_settings')
    .select('*')
    .eq('user_id', userId)
    .single();
  
  if (error) {
    console.error('Error fetching gateway settings:', error);
    return null;
  }
  
  return data;
}

// Fetch API route from database
async function getApiRoute(userId: string, path: string, method: string) {
  const { data, error } = await supabase
    .from('api_routes')
    .select('*')
    .eq('user_id', userId)
    .eq('path', path)
    .eq('method', method)
    .eq('status', 'active')
    .single();
  
  if (error) {
    console.error('Error fetching API route:', error);
    return null;
  }
  
  return data;
}

// Handle preflight requests
function handlePreflight(req: Request) {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      headers: corsHeaders
    });
  }
  return null;
}

// Main API gateway handler
Deno.serve(async (req) => {
  try {
    // Handle CORS preflight requests
    const preflightResponse = handlePreflight(req);
    if (preflightResponse) return preflightResponse;

    const url = new URL(req.url);
    const path = url.pathname.replace('/api-gateway', '');
    const method = req.method;

    // Extract API key from the request
    const apiKeyHeader = req.headers.get('x-api-key');
    if (!apiKeyHeader) {
      return new Response(
        JSON.stringify({ 
          error: 'API key is required' 
        }), 
        { 
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    // Verify API key
    const apiKeyInfo = await verifyApiKey(supabase, apiKeyHeader);
    if (!apiKeyInfo) {
      return new Response(
        JSON.stringify({ 
          error: 'Invalid API key' 
        }), 
        { 
          status: 401,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    // Get user's gateway settings
    const gatewaySettings = await getGatewaySettings(apiKeyInfo.userId);
    if (!gatewaySettings) {
      return new Response(
        JSON.stringify({ 
          error: 'Gateway not configured' 
        }), 
        { 
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    // Check if route exists
    const route = await getApiRoute(apiKeyInfo.userId, path, method);
    if (!route) {
      return new Response(
        JSON.stringify({ 
          error: 'Route not found or inactive' 
        }), 
        { 
          status: 404,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        }
      );
    }

    // Check if route requires authentication
    if (route.authenticated) {
      // Check if API key has necessary scopes
      if (!apiKeyInfo.scopes.some(scope => ['admin', 'write'].includes(scope)) && method !== 'GET') {
        return new Response(
          JSON.stringify({ 
            error: 'Insufficient permissions' 
          }), 
          { 
            status: 403,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' }
          }
        );
      }
    }

    // Apply rate limiting based on security level
    const rateLimiter = rateLimiters[gatewaySettings.security_level] || rateLimiters[SECURITY_LEVELS.high];
    const clientIp = req.headers.get('x-forwarded-for') || 'unknown';
    const rateLimitKey = `${apiKeyInfo.userId}:${clientIp}:${path}`;
    
    if (!rateLimiter.isAllowed(rateLimitKey)) {
      return new Response(
        JSON.stringify({ 
          error: 'Rate limit exceeded' 
        }), 
        { 
          status: 429,
          headers: { 
            ...corsHeaders, 
            'Content-Type': 'application/json',
            'Retry-After': '60'
          }
        }
      );
    }

    // Update API key last_used timestamp
    await supabase
      .from('api_keys')
      .update({ last_used: new Date().toISOString() })
      .eq('id', apiKeyInfo.id);

    // Forward the request to the actual API endpoint
    // In a real implementation, this would forward to the actual backend service
    // For this demo, we'll just return a mock response
    const responseData = {
      success: true,
      route: path,
      method: method,
      timestamp: new Date().toISOString(),
      gateway: {
        version: '1.0.0',
        securityLevel: gatewaySettings.security_level
      },
      data: {
        message: `Mock response from API Gateway for ${method} ${path}`,
        id: crypto.randomUUID()
      }
    };

    // Log the successful request to system_logs
    await supabase.from('system_logs').insert([
      {
        level: 'info',
        message: `API Gateway request: ${method} ${path}`,
        component: 'API Gateway',
        user_id: apiKeyInfo.userId,
        details: JSON.stringify({
          apiKeyId: apiKeyInfo.id,
          path,
          method,
          ip: clientIp
        })
      }
    ]);

    return new Response(
      JSON.stringify(responseData),
      {
        status: 200,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      }
    );
  } catch (error) {
    console.error('API Gateway error:', error);
    
    // Log error to system_logs if we have access to supabase
    if (supabase) {
      try {
        await supabase.from('system_logs').insert([
          {
            level: 'error',
            message: `API Gateway error: ${error.message || 'Unknown error'}`,
            component: 'API Gateway',
            details: JSON.stringify({
              error: error.message,
              stack: error.stack
            })
          }
        ]);
      } catch (logError) {
        console.error('Failed to log error:', logError);
      }
    }
    
    return new Response(
      JSON.stringify({
        error: 'Internal server error',
        message: error.message
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json'
        }
      }
    );
  }
});