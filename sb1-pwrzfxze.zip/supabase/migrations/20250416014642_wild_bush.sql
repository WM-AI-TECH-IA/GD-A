/*
  # Create API Keys Table

  1. New Tables
    - `api_keys`
      - `id` (uuid, primary key)
      - `name` (text, description of the key)
      - `key` (text, the actual API key value)
      - `scopes` (text[], permissions for this key)
      - `status` (text, enum-like: 'active', 'revoked', 'expired')
      - `created_at` (timestamptz, default: now())
      - `last_used` (timestamptz, nullable)
      - `user_id` (uuid, reference to auth.users)
      
  2. Security
    - Enable RLS on `api_keys` table
    - Add policy for authenticated users to manage their own keys
*/

-- Create API Keys Table
CREATE TABLE IF NOT EXISTS api_keys (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  key text NOT NULL UNIQUE,
  scopes text[] NOT NULL DEFAULT '{read}',
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'revoked', 'expired')),
  created_at timestamptz NOT NULL DEFAULT now(),
  last_used timestamptz,
  user_id uuid REFERENCES auth.users(id) NOT NULL
);

-- Enable Row Level Security
ALTER TABLE api_keys ENABLE ROW LEVEL SECURITY;

-- Create Policy for reading keys
CREATE POLICY "Users can read their own API keys"
  ON api_keys
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Create Policy for inserting keys
CREATE POLICY "Users can insert their own API keys"
  ON api_keys
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Create Policy for updating keys
CREATE POLICY "Users can update their own API keys"
  ON api_keys
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create Policy for deleting keys
CREATE POLICY "Users can delete their own API keys"
  ON api_keys
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);