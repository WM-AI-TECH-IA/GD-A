/*
  # Create API Gateway Settings Table

  1. New Tables
    - `api_gateway_settings`
      - `id` (uuid, primary key)
      - `base_url` (text, default: "https://api.wmterminal.com")
      - `security_level` (text, enum-like, default: "high")
      - `default_rate_limit` (integer, default: 100)
      - `authentication_required_by_default` (boolean, default: true)
      - `cors_origins` (text, default: "https://wmterminal.com, https://admin.wmterminal.com")
      - `created_at` (timestamptz, default: now())
      - `updated_at` (timestamptz, default: now())
      
  2. Security
    - Enable RLS on `api_gateway_settings` table
    - Add policy for authenticated users to read/write their own data
*/

-- Create API Gateway Settings Table
CREATE TABLE IF NOT EXISTS api_gateway_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  base_url text NOT NULL DEFAULT 'https://api.wmterminal.com',
  security_level text NOT NULL DEFAULT 'high' CHECK (security_level IN ('standard', 'high', 'extreme')),
  default_rate_limit integer NOT NULL DEFAULT 100,
  authentication_required_by_default boolean NOT NULL DEFAULT true,
  cors_origins text NOT NULL DEFAULT 'https://wmterminal.com, https://admin.wmterminal.com',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  user_id uuid REFERENCES auth.users(id)
);

-- Enable Row Level Security
ALTER TABLE api_gateway_settings ENABLE ROW LEVEL SECURITY;

-- Create Policy for reading settings
CREATE POLICY "Users can read their own settings"
  ON api_gateway_settings
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Create Policy for inserting settings
CREATE POLICY "Users can insert their own settings"
  ON api_gateway_settings
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Create Policy for updating settings
CREATE POLICY "Users can update their own settings"
  ON api_gateway_settings
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- Insert default settings for each new user
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.api_gateway_settings (user_id)
  VALUES (NEW.id);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger for new user creation
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();