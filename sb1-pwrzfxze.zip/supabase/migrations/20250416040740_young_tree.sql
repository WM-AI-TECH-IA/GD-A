/*
  # Create System Logs Table

  1. New Tables
    - `system_logs`
      - `id` (uuid, primary key)
      - `level` (text, log level: 'error', 'warning', 'info', 'debug', 'success')
      - `message` (text, the log message)
      - `component` (text, source component, optional)
      - `user_id` (uuid, reference to auth.users, optional)
      - `details` (text, encrypted JSON details, optional)
      - `created_at` (timestamptz, default: now())
      
  2. Security
    - Enable RLS on `system_logs` table
    - Add policy for authenticated users to read/write their own logs
*/

-- Create System Logs Table
CREATE TABLE IF NOT EXISTS system_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  level text NOT NULL CHECK (level IN ('error', 'warning', 'info', 'debug', 'success')),
  message text NOT NULL,
  component text,
  user_id uuid REFERENCES auth.users(id),
  details text,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE system_logs ENABLE ROW LEVEL SECURITY;

-- Create Policy for reading logs
CREATE POLICY "Users can read their own logs"
  ON system_logs
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id OR user_id IS NULL);

-- Create Policy for inserting logs
CREATE POLICY "Users can insert logs"
  ON system_logs
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id OR user_id IS NULL);

-- Note: We're removing the policy that was causing the error because
-- user_profiles table will be created in a later migration.
-- We'll add this policy back once the user_profiles table exists.