/*
  # Create API Routes Table

  1. New Tables
    - `api_routes`
      - `id` (uuid, primary key)
      - `path` (text, the API endpoint path)
      - `method` (text, HTTP method: GET, POST, PUT, DELETE)
      - `authenticated` (boolean, whether authentication is required)
      - `rate_limit` (integer, rate limit per minute)
      - `status` (text, enum-like: 'active', 'inactive')
      - `secured` (boolean, whether additional security measures are applied)
      - `created_at` (timestamptz, default: now())
      - `updated_at` (timestamptz, default: now())
      - `user_id` (uuid, reference to auth.users)
      
  2. Security
    - Enable RLS on `api_routes` table
    - Add policy for authenticated users to manage their own routes
*/

-- Create API Routes Table
CREATE TABLE IF NOT EXISTS api_routes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  path text NOT NULL,
  method text NOT NULL CHECK (method IN ('GET', 'POST', 'PUT', 'DELETE')),
  authenticated boolean NOT NULL DEFAULT true,
  rate_limit integer NOT NULL DEFAULT 100,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
  secured boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  user_id uuid REFERENCES auth.users(id) NOT NULL
);

-- Enable Row Level Security
ALTER TABLE api_routes ENABLE ROW LEVEL SECURITY;

-- Create Policy for reading routes
CREATE POLICY "Users can read their own API routes"
  ON api_routes
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Create Policy for inserting routes
CREATE POLICY "Users can insert their own API routes"
  ON api_routes
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Create Policy for updating routes
CREATE POLICY "Users can update their own API routes"
  ON api_routes
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create Policy for deleting routes
CREATE POLICY "Users can delete their own API routes"
  ON api_routes
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Insert default routes for new users
CREATE OR REPLACE FUNCTION public.insert_default_routes()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.api_routes (path, method, authenticated, rate_limit, status, secured, user_id)
  VALUES 
    ('/api/v1/projects', 'GET', true, 100, 'active', true, NEW.id),
    ('/api/v1/projects', 'POST', true, 50, 'active', true, NEW.id),
    ('/api/v1/users', 'GET', true, 100, 'active', true, NEW.id),
    ('/api/v1/status', 'GET', false, 500, 'active', false, NEW.id);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger for new user creation
CREATE TRIGGER on_auth_user_created_routes
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.insert_default_routes();