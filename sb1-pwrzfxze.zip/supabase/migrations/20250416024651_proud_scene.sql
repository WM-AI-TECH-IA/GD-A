/*
  # Create User Profiles Table

  1. New Tables
    - `user_profiles`
      - `id` (uuid, primary key)
      - `user_id` (uuid, reference to auth.users)
      - `display_name` (text, optional)
      - `avatar_url` (text, optional)
      - `two_factor_enabled` (boolean, default: false)
      - `two_factor_secret` (text, encrypted 2FA secret, optional)
      - `security_level` (text, enum-like)
      - `is_admin` (boolean, default: false)
      - `last_login` (timestamptz, optional)
      - `created_at` (timestamptz, default: now())
      - `updated_at` (timestamptz, default: now())
      
  2. Security
    - Enable RLS on `user_profiles` table
    - Add policy for authenticated users to read/write their own profile
*/

-- Create User Profiles Table
CREATE TABLE IF NOT EXISTS user_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid UNIQUE REFERENCES auth.users(id) NOT NULL,
  display_name text,
  avatar_url text,
  two_factor_enabled boolean NOT NULL DEFAULT false,
  two_factor_secret text,
  security_level text NOT NULL DEFAULT 'high' CHECK (security_level IN ('standard', 'high', 'extreme')),
  is_admin boolean NOT NULL DEFAULT false,
  last_login timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;

-- Create Policy for reading profiles
CREATE POLICY "Users can read their own profile"
  ON user_profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Create Policy for inserting profiles
CREATE POLICY "Users can insert their own profile"
  ON user_profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Create Policy for updating profiles
CREATE POLICY "Users can update their own profile"
  ON user_profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- Insert profile for new users
CREATE OR REPLACE FUNCTION public.handle_new_user_profile()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.user_profiles (user_id, security_level)
  VALUES (NEW.id, 'high');
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger for new user creation
CREATE TRIGGER on_auth_user_created_profile
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user_profile();