// Global variables
let pyodideReady = false;
let pyodide = null;
let fractalMem = [];
let fractalDepths = [64, 32, 16, 8, 4, 2, 1];

// Initialize Pyodide and the fractal station
async function initializePyodide() {
  try {
    pyodide = await loadPyodide();
    await pyodide.runPythonAsync(`
import xml.etree.ElementTree as ET
import re
import copy

class StationFractalXML:
    def __init__(self, xml_string):
        self.xml_string = xml_string
        self.anomalies = []
        try:
            self.tree = ET.ElementTree(ET.fromstring(xml_string))
            self.root = self.tree.getroot()
            self.ok = True
        except Exception as e:
            self.ok = False
            self.anomalies.append(f"Erreur parsing: {e}")

    def detect_anomalies(self):
        anomalies = []
        if not self.ok:
            return anomalies
        
        for elem in self.root.iter():
            # Check for potentially dangerous patterns
            if elem.text and re.search(r'<script>|<!ENTITY|javascript:|data:|vbscript:', elem.text, re.I):
                anomalies.append((elem.tag, elem.text[:100]))
            
            # Check attributes for suspicious content
            for attr_name, attr_value in elem.attrib.items():
                if re.search(r'<script>|<!ENTITY|javascript:|data:|vbscript:', attr_value, re.I):
                    anomalies.append((f"{elem.tag}@{attr_name}", attr_value[:100]))
        
        self.anomalies.extend(anomalies)
        return anomalies

    def mutate(self, depth):
        if not self.ok: 
            return self.xml_string
        
        newroot = copy.deepcopy(self.root)
        
        # Apply fractal mutations based on depth
        for elem in newroot.iter():
            # Modify tag names with fractal depth
            elem.tag = f"{elem.tag}_F{depth}"
            
            # Add fractal attributes
            elem.set('fractal_depth', str(depth))
            elem.set('fractal_id', f"f_{depth}_{hash(elem.tag) % 1000}")
            
            # Modify text content if present
            if elem.text and elem.text.strip():
                elem.text = f"[F{depth}] {elem.text}"
        
        return ET.tostring(newroot, encoding="unicode")

    def summary(self):
        if not self.ok:
            return {"root": None, "children": [], "attrs": {}, "total_nodes": 0}
        
        children = [child.tag for child in self.root]
        total_nodes = len(list(self.root.iter()))
        
        return {
            "root": self.root.tag,
            "children": children,
            "attrs": self.root.attrib,
            "total_nodes": total_nodes
        }

    def get_nodes(self):
        if not self.ok: 
            return []
        
        nodes = []
        for elem in self.root.iter():
            nodes.append({
                "tag": elem.tag,
                "text": (elem.text or "").strip()[:50],
                "attrib": dict(elem.attrib),
                "children_count": len(list(elem))
            })
        return nodes

    def export_xml(self):
        return self.xml_string
    `);
    
    pyodideReady = true;
    logMessage(" Pyodide prêt, Station fractale active.");
    loadFractalMemory();
  } catch (error) {
    logMessage(`❌ Erreur initialisation Pyodide: ${error.message}`);
  }
}

// Utility functions
function logMessage(msg) {
  const logElement = document.getElementById('log');
  logElement.textContent = msg;
  logElement.classList.add('loading');
  setTimeout(() => logElement.classList.remove('loading'), 1000);
}

function logAnomaly(msg) {
  const anomalyElement = document.getElementById('anomalies');
  anomalyElement.textContent = msg;
}

function logFractalMemory() {
  const fractalElement = document.getElementById('fractalmem');
  if (fractalMem.length === 0) {
    fractalElement.innerHTML = "Mémoire fractale : <em>vide</em>";
    return;
  }
  
  const memoryDisplay = fractalMem.map((f, i) => 
    `<span class='vortex'>[${f.depth}]</span>`
  ).join(' ⟐ ');
  
  fractalElement.innerHTML = `Mémoire fractale : ${memoryDisplay}`;
}

// Fractal memory persistence
function saveFractalMemory() {
  try {
    localStorage.setItem('fractalmem', JSON.stringify(fractalMem));
    logFractalMemory();
  } catch (error) {
    logMessage(`⚠️ Erreur sauvegarde mémoire: ${error.message}`);
  }
}

function loadFractalMemory() {
  try {
    const mem = localStorage.getItem('fractalmem');
    fractalMem = mem ? JSON.parse(mem) : [];
    logFractalMemory();
  } catch (error) {
    fractalMem = [];
    logMessage(`⚠️ Erreur chargement mémoire: ${error.message}`);
  }
}

// File handling
function setupFileHandler() {
  document.getElementById('xmlfile').addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = function(evt) {
        document.getElementById('xmlcontent').value = evt.target.result;
        logMessage(`📁 XML importé: ${file.name}`);
      };
      reader.onerror = function() {
        logMessage("❌ Erreur lecture fichier");
      };
      reader.readAsText(file);
    }
  });
}

// XML scanning functionality
async function scanXML() {
  if (!pyodideReady) {
    logMessage("⏳ Pyodide non prêt.");
    return;
  }
  
  const xmlstr = document.getElementById('xmlcontent').value.trim();
  if (!xmlstr) {
    logMessage("⚠️ Aucun XML à scanner.");
    return;
  }
  
  try {
    pyodide.globals.set("xml_string", xmlstr);
    await pyodide.runPythonAsync(`
station = StationFractalXML(xml_string)
anomalies = station.detect_anomalies()
summary = station.summary()
nodes = station.get_nodes()
    `);
    
    const anomalies = pyodide.globals.get('anomalies').toJs();
    const summary = pyodide.globals.get('summary').toJs();
    const nodes = pyodide.globals.get('nodes').toJs();
    
    logMessage(`📊 Root: ${summary.root} | Enfants: ${summary.children.length} | Nœuds: ${summary.total_nodes}`);
    
    if (anomalies && anomalies.length > 0) {
      logAnomaly(`🚨 Anomalies détectées: ${anomalies.map(a => `[${a[0]}] ${a[1]}`).join(" | ")}`);
    } else {
      logAnomaly("✅ Aucune anomalie détectée");
    }
    
    renderSVG(nodes);
  } catch (error) {
    logMessage(`❌ Erreur analyse: ${error.message}`);
    logAnomaly("");
    renderSVG([]);
  }
}

// Fractal replication
async function fractaleReplicate() {
  if (!pyodideReady) {
    logMessage("⏳ Pyodide non prêt.");
    return;
  }
  
  const xmlstr = document.getElementById('xmlcontent').value.trim();
  if (!xmlstr) {
    logMessage("⚠️ Aucun XML source.");
    return;
  }
  
  const depth = fractalDepths[fractalMem.length % fractalDepths.length];
  
  try {
    pyodide.globals.set("xml_string", xmlstr);
    await pyodide.runPythonAsync(`
station = StationFractalXML(xml_string)
xml_fractal = station.mutate(${depth})
    `);
    
    const xmlFractal = pyodide.globals.get('xml_fractal');
    
    // Add to fractal memory
    fractalMem.push({
      depth,
      xml: xmlFractal,
      timestamp: new Date().toISOString()
    });
    
    saveFractalMemory();
    document.getElementById('xmlcontent').value = xmlFractal;
    await scanXML();
    
    if (depth === 1) {
      logMessage("🌀 VORTEX : Cycle complet, retour à l'origine fractale !");
      setTimeout(() => {
        fractalMem = [];
        saveFractalMemory();
      }, 2000);
    } else {
      logMessage(`🔄 Réplication fractale depth ${depth} complétée`);
    }
  } catch (error) {
    logMessage(`❌ Erreur réplication: ${error.message}`);
  }
}

// SVG visualization
function renderSVG(nodes) {
  const svg = document.getElementById('svgout');
  svg.innerHTML = '';
  
  if (!nodes || nodes.length === 0) {
    svg.innerHTML = '<text x="210" y="210" fill="#ffd95c" font-size="16" text-anchor="middle">Aucun nœud fractal à afficher</text>';
    return;
  }
  
  const centerX = 210;
  const centerY = 210;
  const radius = 150;
  const angleStep = (2 * Math.PI) / nodes.length;
  
  // Create a circular layout for better visualization
  nodes.forEach((node, i) => {
    const angle = i * angleStep;
    const x = centerX + Math.cos(angle) * radius;
    const y = centerY + Math.sin(angle) * radius;
    
    // Node circle
    const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
    circle.setAttribute('cx', x);
    circle.setAttribute('cy', y);
    circle.setAttribute('r', '20');
    circle.setAttribute('fill', '#ffd95c');
    circle.setAttribute('stroke', '#333');
    circle.setAttribute('stroke-width', '2');
    svg.appendChild(circle);
    
    // Node label
    const text = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    text.setAttribute('x', x);
    text.setAttribute('y', y + 5);
    text.setAttribute('font-size', '12');
    text.setAttribute('fill', '#181c24');
    text.setAttribute('text-anchor', 'middle');
    text.textContent = node.tag.length > 8 ? node.tag.substring(0, 8) + '...' : node.tag;
    svg.appendChild(text);
    
    // Connection to center
    const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
    line.setAttribute('x1', centerX);
    line.setAttribute('y1', centerY);
    line.setAttribute('x2', x);
    line.setAttribute('y2', y);
    line.setAttribute('stroke', '#77eaff');
    line.setAttribute('stroke-width', '1');
    line.setAttribute('opacity', '0.5');
    svg.appendChild(line);
  });
  
  // Center node
  const centerCircle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
  centerCircle.setAttribute('cx', centerX);
  centerCircle.setAttribute('cy', centerY);
  centerCircle.setAttribute('r', '15');
  centerCircle.setAttribute('fill', '#a8a6ff');
  centerCircle.setAttribute('stroke', '#333');
  centerCircle.setAttribute('stroke-width', '2');
  svg.appendChild(centerCircle);
}

// Export functionality
function exportXML() {
  const xmlstr = document.getElementById('xmlcontent').value;
  if (!xmlstr.trim()) {
    logMessage("⚠️ Aucun XML à exporter");
    return;
  }
  
  const blob = new Blob([xmlstr], { type: "text/xml" });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = `station_fractal_${new Date().toISOString().slice(0, 19).replace(/:/g, '-')}.xml`;
  a.click();
  logMessage("💾 XML exporté.");
}

// API functionality
async function postXML() {
  const xmlstr = document.getElementById('xmlcontent').value;
  if (!xmlstr.trim()) {
    logMessage("⚠️ Aucun XML à envoyer");
    return;
  }
  
  try {
    const response = await fetch("http://localhost:3000/api/xml", {
      method: "POST",
      headers: { "Content-Type": "application/xml" },
      body: xmlstr
    });
    
    if (response.ok) {
      const result = await response.text();
      logMessage(`📤 POST XML OK: ${result}`);
    } else {
      throw new Error(`HTTP ${response.status}`);
    }
  } catch (error) {
    logMessage("📤 POST XML simulé (Backend non actif)");
  }
}

async function getXML() {
  try {
    const response = await fetch("http://localhost:3000/api/xml");
    if (response.ok) {
      const xml = await response.text();
      document.getElementById('xmlcontent').value = xml;
      await scanXML();
      logMessage("📥 GET XML backend reçu");
    } else {
      throw new Error(`HTTP ${response.status}`);
    }
  } catch (error) {
    // Fallback to fractal memory
    if (fractalMem.length > 0) {
      const last = fractalMem[fractalMem.length - 1];
      document.getElementById('xmlcontent').value = last.xml;
      await scanXML();
      logMessage("📥 GET XML simulé (mémoire fractale locale)");
    } else {
      logMessage("⚠️ Aucune fractale mémorisée");
    }
  }
}

function resetAll() {
  document.getElementById('xmlcontent').value = "";
  document.getElementById('svgout').innerHTML = "";
  document.getElementById('log').textContent = "";
  document.getElementById('anomalies').textContent = "";
  fractalMem = [];
  saveFractalMemory();
  logMessage("🧹 Station réinitialisée");
}

// Make functions globally available
window.scanXML = scanXML;
window.fractaleReplicate = fractaleReplicate;
window.exportXML = exportXML;
window.postXML = postXML;
window.getXML = getXML;
window.resetAll = resetAll;

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
  setupFileHandler();
  initializePyodide();
});