#!/bin/bash

set -e

echo "🚀 Déploiement de l'architecture microservices Station Fractale"

# Vérification des prérequis
command -v docker >/dev/null 2>&1 || { echo "❌ Docker requis mais non installé." >&2; exit 1; }
command -v docker-compose >/dev/null 2>&1 || { echo "❌ Docker Compose requis mais non installé." >&2; exit 1; }

# Configuration de l'environnement
export COMPOSE_PROJECT_NAME=fractal-station
export DOCKER_BUILDKIT=1
export COMPOSE_DOCKER_CLI_BUILD=1

# Nettoyage des anciens conteneurs
echo "🧹 Nettoyage des anciens conteneurs..."
docker-compose down --remove-orphans --volumes

# Construction des images
echo "🔨 Construction des images Docker..."
docker-compose build --parallel --no-cache

# Initialisation de la base de données
echo "🗄️ Initialisation de la base de données..."
docker-compose up -d postgres redis elasticsearch
sleep 30

# Création des tables
docker-compose exec -T postgres psql -U postgres -d fractal_db << EOF
CREATE TABLE IF NOT EXISTS xml_processing_history (
    id UUID PRIMARY KEY,
    original_xml TEXT NOT NULL,
    processed_xml TEXT NOT NULL,
    operations JSONB NOT NULL,
    metadata JSONB NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS fractal_memory (
    id UUID PRIMARY KEY,
    depth INTEGER NOT NULL,
    xml_content TEXT NOT NULL,
    parent_id UUID REFERENCES fractal_memory(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    metadata JSONB
);

CREATE TABLE IF NOT EXISTS security_scans (
    id UUID PRIMARY KEY,
    xml_hash VARCHAR(64) NOT NULL,
    threats JSONB NOT NULL,
    risk_score INTEGER NOT NULL,
    scan_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    metadata JSONB
);

CREATE TABLE IF NOT EXISTS analytics_events (
    id UUID PRIMARY KEY,
    event_type VARCHAR(100) NOT NULL,
    event_data JSONB NOT NULL,
    user_id VARCHAR(100),
    session_id VARCHAR(100),
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_xml_processing_created_at ON xml_processing_history(created_at);
CREATE INDEX IF NOT EXISTS idx_fractal_memory_depth ON fractal_memory(depth);
CREATE INDEX IF NOT EXISTS idx_security_scans_hash ON security_scans(xml_hash);
CREATE INDEX IF NOT EXISTS idx_analytics_events_type ON analytics_events(event_type);
CREATE INDEX IF NOT EXISTS idx_analytics_events_timestamp ON analytics_events(timestamp);
EOF

echo "✅ Base de données initialisée"

# Démarrage des services
echo "🚀 Démarrage des services..."
docker-compose up -d

# Attente que tous les services soient prêts
echo "⏳ Attente de la disponibilité des services..."
sleep 60

# Vérification de la santé des services
echo "🏥 Vérification de la santé des services..."

services=("api-gateway:8080" "xml-core-service:3001")
for service in "${services[@]}"; do
    IFS=':' read -r name port <<< "$service"
    if curl -f "http://localhost:$port/health" > /dev/null 2>&1; then
        echo "✅ $name est opérationnel"
    else
        echo "❌ $name n'est pas accessible"
    fi
done

# Configuration des dashboards Grafana
echo "📊 Configuration des dashboards Grafana..."
sleep 10

# Affichage des informations de connexion
echo ""
echo "🎉 Déploiement terminé avec succès!"
echo ""
echo "📋 Services disponibles:"
echo "   🌐 API Gateway:      http://localhost:8080"
echo "   🔍 Consul:           http://localhost:8500"
echo "   📊 Grafana:          http://localhost:3000 (admin/fractal)"
echo "   🔍 Kibana:           http://localhost:5601"
echo "   📈 Prometheus:       http://localhost:9090"
echo "   🔍 Jaeger:           http://localhost:16686"
echo ""
echo "🔧 Commandes utiles:"
echo "   docker-compose logs -f [service]  # Voir les logs"
echo "   docker-compose ps                 # État des services"
echo "   docker-compose down               # Arrêter tous les services"
echo ""
echo "📖 Documentation API: http://localhost:8080/docs"