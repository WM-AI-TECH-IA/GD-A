import express from 'express';
import cors from 'cors';
import multer from 'multer';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const port = 3000;

// Middleware
app.use(cors());
app.use(express.text({ type: 'application/xml' }));
app.use(express.json());

// In-memory storage for XML data
let xmlStorage = `<?xml version="1.0" encoding="UTF-8"?>
<fractal_station>
  <metadata>
    <created>2024-01-01T00:00:00Z</created>
    <version>1.0</version>
  </metadata>
  <nodes>
    <node id="1" type="root">Station Fractale</node>
    <node id="2" type="branch">Vortex Infini</node>
  </nodes>
</fractal_station>`;

// Configure multer for file uploads
const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
});

// API Routes
app.get('/api/xml', (req, res) => {
  res.set('Content-Type', 'application/xml');
  res.send(xmlStorage);
});

app.post('/api/xml', (req, res) => {
  try {
    const xmlData = req.body;
    
    // Basic XML validation
    if (!xmlData || typeof xmlData !== 'string') {
      return res.status(400).json({ error: 'Invalid XML data' });
    }
    
    // Store the XML
    xmlStorage = xmlData;
    
    res.json({ 
      message: 'XML stored successfully',
      timestamp: new Date().toISOString(),
      size: xmlData.length
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to store XML' });
  }
});

app.post('/api/upload', upload.single('xmlfile'), (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }
    
    const xmlData = req.file.buffer.toString('utf8');
    xmlStorage = xmlData;
    
    res.json({
      message: 'File uploaded successfully',
      filename: req.file.originalname,
      size: req.file.size,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    res.status(500).json({ error: 'Failed to upload file' });
  }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime()
  });
});

// Fractal memory endpoint
app.get('/api/fractal-memory', (req, res) => {
  // This would typically connect to a database
  res.json({
    message: 'Fractal memory endpoint',
    timestamp: new Date().toISOString()
  });
});

// Error handling middleware
app.use((error, req, res, next) => {
  console.error('Server error:', error);
  res.status(500).json({ 
    error: 'Internal server error',
    timestamp: new Date().toISOString()
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ 
    error: 'Endpoint not found',
    path: req.path,
    timestamp: new Date().toISOString()
  });
});

app.listen(port, () => {
  console.log(`🚀 XML Fractal Station API server running on http://localhost:${port}`);
  console.log(`📊 Health check: http://localhost:${port}/api/health`);
  console.log(`🔄 XML API: http://localhost:${port}/api/xml`);
});

export default app;