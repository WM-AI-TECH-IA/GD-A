const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const Redis = require('redis');
const { Pool } = require('pg');
const winston = require('winston');
const { initTracer } = require('jaeger-client');
const consul = require('consul')();
const { v4: uuidv4 } = require('uuid');

const XMLProcessor = require('./lib/XMLProcessor');
const XMLValidator = require('./lib/XMLValidator');
const XMLTransformer = require('./lib/XMLTransformer');

// Configuration du logger
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    winston.format.json()
  ),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: 'logs/xml-core.log' })
  ]
});

// Configuration du tracing
const tracer = initTracer({
  serviceName: 'xml-core-service',
  sampler: { type: 'const', param: 1 }
});

const app = express();
const PORT = process.env.PORT || 3001;

// Connexions aux services externes
const redisClient = Redis.createClient({
  url: process.env.REDIS_URL || 'redis://localhost:6379'
});

const pgPool = new Pool({
  connectionString: process.env.DATABASE_URL || 'postgresql://postgres:fractal@localhost:5432/fractal_db',
  max: 20,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 2000,
});

// Middleware de base
app.use(helmet());
app.use(cors());
app.use(compression());
app.use(express.json({ limit: '50mb' }));
app.use(express.text({ type: 'application/xml', limit: '50mb' }));

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 1000, // limite par IP
  message: 'Trop de requêtes depuis cette IP',
  standardHeaders: true,
  legacyHeaders: false,
});

app.use(limiter);

// Initialisation des services
let xmlProcessor, xmlValidator, xmlTransformer;

async function initializeServices() {
  try {
    await redisClient.connect();
    
    xmlProcessor = new XMLProcessor(redisClient, pgPool, logger);
    xmlValidator = new XMLValidator(logger);
    xmlTransformer = new XMLTransformer(logger);
    
    // Enregistrement du service dans Consul
    await consul.agent.service.register({
      name: 'xml-core-service',
      id: `xml-core-${process.pid}`,
      address: process.env.SERVICE_HOST || 'localhost',
      port: PORT,
      tags: ['xml', 'core', 'processing'],
      check: {
        http: `http://${process.env.SERVICE_HOST || 'localhost'}:${PORT}/health`,
        interval: '30s',
        timeout: '10s'
      }
    });
    
    logger.info('Service XML Core initialisé avec succès');
  } catch (error) {
    logger.error('Erreur initialisation service:', error);
    process.exit(1);
  }
}

// Middleware de tracing
app.use((req, res, next) => {
  const span = tracer.startSpan(`${req.method} ${req.path}`);
  span.setTag('http.method', req.method);
  span.setTag('http.url', req.url);
  
  req.span = span;
  
  res.on('finish', () => {
    span.setTag('http.status_code', res.statusCode);
    span.finish();
  });
  
  next();
});

// Routes principales

// Validation XML
app.post('/validate', async (req, res) => {
  try {
    const { xml, schema, options = {} } = req.body;
    
    if (!xml) {
      return res.status(400).json({ error: 'XML content required' });
    }
    
    const validationResult = await xmlValidator.validate(xml, schema, options);
    
    // Cache du résultat
    const cacheKey = `validation:${Buffer.from(xml).toString('base64').slice(0, 32)}`;
    await redisClient.setEx(cacheKey, 3600, JSON.stringify(validationResult));
    
    res.json(validationResult);
  } catch (error) {
    logger.error('Erreur validation XML:', error);
    res.status(500).json({ error: 'Erreur validation XML', details: error.message });
  }
});

// Traitement XML
app.post('/process', async (req, res) => {
  try {
    const { xml, operations = [], metadata = {} } = req.body;
    
    if (!xml) {
      return res.status(400).json({ error: 'XML content required' });
    }
    
    const processingId = uuidv4();
    const result = await xmlProcessor.process(xml, operations, {
      ...metadata,
      processingId,
      timestamp: new Date().toISOString()
    });
    
    // Sauvegarde en base
    await pgPool.query(
      'INSERT INTO xml_processing_history (id, original_xml, processed_xml, operations, metadata, created_at) VALUES ($1, $2, $3, $4, $5, $6)',
      [processingId, xml, result.processedXml, JSON.stringify(operations), JSON.stringify(metadata), new Date()]
    );
    
    res.json({
      processingId,
      ...result
    });
  } catch (error) {
    logger.error('Erreur traitement XML:', error);
    res.status(500).json({ error: 'Erreur traitement XML', details: error.message });
  }
});

// Transformation XML
app.post('/transform', async (req, res) => {
  try {
    const { xml, transformations, outputFormat = 'xml' } = req.body;
    
    if (!xml) {
      return res.status(400).json({ error: 'XML content required' });
    }
    
    const result = await xmlTransformer.transform(xml, transformations, outputFormat);
    
    res.json(result);
  } catch (error) {
    logger.error('Erreur transformation XML:', error);
    res.status(500).json({ error: 'Erreur transformation XML', details: error.message });
  }
});

// Analyse de structure XML
app.post('/analyze', async (req, res) => {
  try {
    const { xml } = req.body;
    
    if (!xml) {
      return res.status(400).json({ error: 'XML content required' });
    }
    
    const analysis = await xmlProcessor.analyze(xml);
    
    res.json(analysis);
  } catch (error) {
    logger.error('Erreur analyse XML:', error);
    res.status(500).json({ error: 'Erreur analyse XML', details: error.message });
  }
});

// Récupération de l'historique
app.get('/history/:processingId', async (req, res) => {
  try {
    const { processingId } = req.params;
    
    const result = await pgPool.query(
      'SELECT * FROM xml_processing_history WHERE id = $1',
      [processingId]
    );
    
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Processing record not found' });
    }
    
    res.json(result.rows[0]);
  } catch (error) {
    logger.error('Erreur récupération historique:', error);
    res.status(500).json({ error: 'Erreur récupération historique' });
  }
});

// Health check
app.get('/health', async (req, res) => {
  const health = {
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    memory: process.memoryUsage(),
    connections: {
      redis: 'unknown',
      postgres: 'unknown'
    }
  };
  
  try {
    // Test Redis
    await redisClient.ping();
    health.connections.redis = 'connected';
  } catch (error) {
    health.connections.redis = 'disconnected';
    health.status = 'degraded';
  }
  
  try {
    // Test PostgreSQL
    await pgPool.query('SELECT 1');
    health.connections.postgres = 'connected';
  } catch (error) {
    health.connections.postgres = 'disconnected';
    health.status = 'degraded';
  }
  
  const statusCode = health.status === 'healthy' ? 200 : 503;
  res.status(statusCode).json(health);
});

// Métriques
app.get('/metrics', (req, res) => {
  // Les métriques Prometheus seront exposées ici
  res.set('Content-Type', 'text/plain');
  res.send('# Métriques XML Core Service\n');
});

// Gestion des erreurs
app.use((error, req, res, next) => {
  logger.error('Erreur non gérée:', error);
  
  if (req.span) {
    req.span.setTag('error', true);
    req.span.log({ event: 'error', message: error.message });
  }
  
  res.status(500).json({
    error: 'Erreur interne du service',
    timestamp: new Date().toISOString()
  });
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  logger.info('Arrêt gracieux du service XML Core...');
  
  try {
    await consul.agent.service.deregister(`xml-core-${process.pid}`);
    await redisClient.quit();
    await pgPool.end();
    process.exit(0);
  } catch (error) {
    logger.error('Erreur lors de l\'arrêt:', error);
    process.exit(1);
  }
});

// Initialisation et démarrage
initializeServices().then(() => {
  app.listen(PORT, () => {
    logger.info(`🚀 Service XML Core démarré sur le port ${PORT}`);
  });
});

module.exports = app;