const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('rate-limiter-flexible');
const Redis = require('redis');
const consul = require('consul')();
const winston = require('winston');
const promMiddleware = require('express-prometheus-middleware');
const { initTracer } = require('jaeger-client');
const jwt = require('jsonwebtoken');

// Configuration du logger
const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    winston.format.json()
  ),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: 'logs/gateway.log' })
  ]
});

// Configuration du tracing
const tracer = initTracer({
  serviceName: 'api-gateway',
  sampler: { type: 'const', param: 1 }
});

const app = express();
const PORT = process.env.PORT || 8080;

// Redis client pour cache et rate limiting
const redisClient = Redis.createClient({
  url: process.env.REDIS_URL || 'redis://localhost:6379'
});

redisClient.connect().catch(console.error);

// Rate limiting avancé
const rateLimiter = new rateLimit.RateLimiterRedis({
  storeClient: redisClient,
  keyPrefix: 'rl_gateway',
  points: 100, // Nombre de requêtes
  duration: 60, // Par minute
  blockDuration: 60 * 5, // Blocage 5 minutes
});

// Middleware de sécurité
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'", "'unsafe-inline'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", "data:", "https:"],
    },
  },
  hsts: {
    maxAge: 31536000,
    includeSubDomains: true,
    preload: true
  }
}));

app.use(cors({
  origin: process.env.ALLOWED_ORIGINS?.split(',') || ['http://localhost:5173'],
  credentials: true
}));

// Métriques Prometheus
app.use(promMiddleware({
  metricsPath: '/metrics',
  collectDefaultMetrics: true,
  requestDurationBuckets: [0.1, 0.5, 1, 1.5, 2, 3, 5, 10]
}));

app.use(express.json({ limit: '10mb' }));

// Middleware d'authentification JWT
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token && req.path.startsWith('/api/protected')) {
    return res.status(401).json({ error: 'Token d\'accès requis' });
  }

  if (token) {
    jwt.verify(token, process.env.JWT_SECRET || 'fractal-secret', (err, user) => {
      if (err) return res.status(403).json({ error: 'Token invalide' });
      req.user = user;
    });
  }

  next();
};

// Middleware de rate limiting
const rateLimitMiddleware = async (req, res, next) => {
  try {
    const key = req.ip + ':' + (req.user?.id || 'anonymous');
    await rateLimiter.consume(key);
    next();
  } catch (rejRes) {
    const remainingPoints = rejRes.remainingPoints || 0;
    const msBeforeNext = rejRes.msBeforeNext || 1000;
    
    res.set('Retry-After', Math.round(msBeforeNext / 1000) || 1);
    res.status(429).json({
      error: 'Trop de requêtes',
      retryAfter: msBeforeNext
    });
  }
};

app.use(rateLimitMiddleware);
app.use(authenticateToken);

// Service Discovery avec Consul
class ServiceRegistry {
  constructor() {
    this.services = new Map();
    this.healthCheckInterval = 30000; // 30 secondes
    this.startHealthChecks();
  }

  async discoverServices() {
    try {
      const services = await consul.health.service({
        service: 'fractal-service',
        passing: true
      });

      const serviceMap = new Map();
      services.forEach(service => {
        const serviceName = service.Service.Service;
        if (!serviceMap.has(serviceName)) {
          serviceMap.set(serviceName, []);
        }
        serviceMap.get(serviceName).push({
          host: service.Service.Address,
          port: service.Service.Port,
          health: 'healthy'
        });
      });

      this.services = serviceMap;
      logger.info('Services découverts:', Object.fromEntries(serviceMap));
    } catch (error) {
      logger.error('Erreur découverte services:', error);
    }
  }

  getServiceUrl(serviceName) {
    const instances = this.services.get(serviceName);
    if (!instances || instances.length === 0) {
      return null;
    }

    // Load balancing round-robin simple
    const instance = instances[Math.floor(Math.random() * instances.length)];
    return `http://${instance.host}:${instance.port}`;
  }

  startHealthChecks() {
    setInterval(() => {
      this.discoverServices();
    }, this.healthCheckInterval);

    // Découverte initiale
    this.discoverServices();
  }
}

const serviceRegistry = new ServiceRegistry();

// Configuration des proxies avec circuit breaker
const createProxy = (serviceName, pathRewrite = {}) => {
  return createProxyMiddleware({
    target: () => serviceRegistry.getServiceUrl(serviceName),
    changeOrigin: true,
    pathRewrite,
    onError: (err, req, res) => {
      logger.error(`Erreur proxy ${serviceName}:`, err);
      res.status(503).json({
        error: 'Service temporairement indisponible',
        service: serviceName,
        timestamp: new Date().toISOString()
      });
    },
    onProxyReq: (proxyReq, req, res) => {
      // Ajout du tracing
      const span = tracer.startSpan(`proxy-${serviceName}`);
      span.setTag('http.method', req.method);
      span.setTag('http.url', req.url);
      span.setTag('service.name', serviceName);
      
      req.span = span;
      
      // Ajout des headers de sécurité
      proxyReq.setHeader('X-Request-ID', req.headers['x-request-id'] || generateRequestId());
      proxyReq.setHeader('X-User-ID', req.user?.id || 'anonymous');
    },
    onProxyRes: (proxyRes, req, res) => {
      if (req.span) {
        req.span.setTag('http.status_code', proxyRes.statusCode);
        req.span.finish();
      }
    }
  });
};

// Routes des microservices
app.use('/api/xml', createProxy('xml-core-service', { '^/api/xml': '' }));
app.use('/api/fractal', createProxy('fractal-engine', { '^/api/fractal': '' }));
app.use('/api/security', createProxy('security-scanner', { '^/api/security': '' }));
app.use('/api/analytics', createProxy('analytics-service', { '^/api/analytics': '' }));
app.use('/api/visualization', createProxy('visualization-service', { '^/api/visualization': '' }));

// Health check endpoint
app.get('/health', async (req, res) => {
  const health = {
    status: 'healthy',
    timestamp: new Date().toISOString(),
    services: {},
    uptime: process.uptime(),
    memory: process.memoryUsage(),
    version: process.env.npm_package_version || '1.0.0'
  };

  // Vérification des services
  for (const [serviceName, instances] of serviceRegistry.services) {
    health.services[serviceName] = {
      instances: instances.length,
      status: instances.length > 0 ? 'available' : 'unavailable'
    };
  }

  // Vérification Redis
  try {
    await redisClient.ping();
    health.redis = 'connected';
  } catch (error) {
    health.redis = 'disconnected';
    health.status = 'degraded';
  }

  const statusCode = health.status === 'healthy' ? 200 : 503;
  res.status(statusCode).json(health);
});

// Endpoint de métriques personnalisées
app.get('/api/gateway/metrics', async (req, res) => {
  try {
    const metrics = {
      totalRequests: await redisClient.get('total_requests') || 0,
      activeConnections: await redisClient.get('active_connections') || 0,
      errorRate: await redisClient.get('error_rate') || 0,
      avgResponseTime: await redisClient.get('avg_response_time') || 0,
      services: Object.fromEntries(serviceRegistry.services)
    };

    res.json(metrics);
  } catch (error) {
    logger.error('Erreur métriques:', error);
    res.status(500).json({ error: 'Erreur récupération métriques' });
  }
});

// Middleware de logging des requêtes
app.use((req, res, next) => {
  const start = Date.now();
  
  res.on('finish', () => {
    const duration = Date.now() - start;
    logger.info({
      method: req.method,
      url: req.url,
      status: res.statusCode,
      duration,
      ip: req.ip,
      userAgent: req.get('User-Agent'),
      userId: req.user?.id
    });

    // Mise à jour des métriques Redis
    redisClient.incr('total_requests');
    redisClient.set('avg_response_time', duration, { EX: 300 }); // TTL 5 minutes
  });

  next();
});

// Gestion des erreurs globales
app.use((error, req, res, next) => {
  logger.error('Erreur non gérée:', error);
  
  res.status(500).json({
    error: 'Erreur interne du serveur',
    requestId: req.headers['x-request-id'],
    timestamp: new Date().toISOString()
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    error: 'Endpoint non trouvé',
    path: req.path,
    method: req.method,
    timestamp: new Date().toISOString()
  });
});

function generateRequestId() {
  return Math.random().toString(36).substring(2, 15) + 
         Math.random().toString(36).substring(2, 15);
}

// Graceful shutdown
process.on('SIGTERM', async () => {
  logger.info('Arrêt gracieux du gateway...');
  
  try {
    await redisClient.quit();
    process.exit(0);
  } catch (error) {
    logger.error('Erreur lors de l\'arrêt:', error);
    process.exit(1);
  }
});

app.listen(PORT, () => {
  logger.info(`🚀 API Gateway démarré sur le port ${PORT}`);
  logger.info(`📊 Métriques disponibles sur http://localhost:${PORT}/metrics`);
  logger.info(`🏥 Health check sur http://localhost:${PORT}/health`);
});

module.exports = app;