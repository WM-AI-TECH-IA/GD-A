# F-Droid Repackaged for Samsung S24

Ce dossier contient un AndroidManifest.xml modifié pour générer un APK
signé compatible avec les modèles Samsung S24 en contournant l'erreur INSTALL_FAILED_VERSION_DOWNGRADE.

VersionCode : 9999999
VersionName : WM-S24-Override

Instructions :
1. Ouvrir Android Studio
2. Créer projet vide avec package 'org.fdroid.fdroid'
3. Remplacer AndroidManifest.xml par celui fourni
4. Générer APK signé
5. Installer sur le S24